#ifndef __IMG_H
#define __IMG_H 
#include "common.h"
#include "include.h"

#define White 255
#define Black 0

#define IMG_H 120
#define IMG_W 160
extern uint8 Error[5];
extern uint8 imgbuff[CAMERA_SIZE];                             //����洢����ͼ�������
extern uint8 image[CAMERA_H][CAMERA_W];
extern int16 g_iTurn_Set;
extern uint8 DianJi_STOP;
extern uint32 ALL_TIME;
extern uint32 Distance_All;
void IMG_Extract(uint8* imgbuff); 
void IMG_Handle(void);
void IMG_Correct(void);
void IMG_Find_Lines(void);
void Middle_Line_Find(void);
void Find_Lines_Oppose(void);
void Find_Obstacle(void);//Ѱ���ϰ�  
void Find_StopLine(void);
void Obstacle_Handle(void);
void Annular_Handle(void);
void Annular_Find(void);
extern uint32 Distance_All;
extern uint32 Distance_Little;
extern double Out_Data[4];
extern uint32 Distance_All;
extern uint32 Distance_Little;

extern unsigned char Shut_Down;
void Find_END_Line(void);
void Annular_Find1(void);
void Annular_Find2(void);
void Annular_Find3(void);
void Annular_Find4(void);


void Side_Run(void);
void Annular_Handle_Right(void);
void Annular_Handle_Left(void);
void img_extract(uint8 *dst, uint8 *src, uint32 srclen);
void IMG_FIND_1(void);
void Variance_Calculate(void);

#endif
