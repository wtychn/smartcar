#ifndef __FUNCTION_H__
#define __FUNCTION_H__

void init();
void Para_Init();
void OLED_Draw_camera();
float Slope_Calculate(uint8 begin,uint8 end,float *p);

#endif