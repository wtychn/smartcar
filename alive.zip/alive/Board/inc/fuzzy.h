#ifndef _FUZZY_H_
#define _FUZZY_H_


float Fuzzy(float P,float D);

#endif
