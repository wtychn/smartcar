#ifndef __SEARCH_H__
#define __SEARCH_H__
extern uint8  RoadType,RoadStyle,Slow_Down_Flag,Search_Endline;

void Search();
void get_edge();
void sendimg();
#endif