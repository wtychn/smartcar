#ifndef _PWM_H_
#define _PWM_H_

#define MOTOR_FTM   FTM0
#define MOTOR1_PWM  FTM_CH0
#define MOTOR2_PWM  FTM_CH1

#define STEERING_FTM   FTM1
#define STEERING_CH    FTM_CH1
#define STEERING_HZ    (300)

#define MOTOR_HZ    24000//(20*1000)
#define MOTOR_DUTY  80

extern void PWM_init();

extern void MOTOR_duty(signed char Duty);
extern void SHEER_duty(signed char angle);
extern void Speed();

#endif