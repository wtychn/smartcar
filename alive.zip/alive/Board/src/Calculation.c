#include "common.h"
#include "include.h"

# define WIDTH(y) (0.7 * (y)  + 18)
# define WIDTH_HALF(y) (0.35* (y) + 9)
# define WIDTH_Annular(y) (0.7 * (y) - 6)

int16 Right_Line[IMG_H] = {0};
int16 Left_Line[IMG_H] = {160};
int16 Middle_Line[IMG_H] = {80};
uint16 White_Line_Max = 0;  //����е�ֵ
uint16 White_Line_MPos = 80;	//����е�λ��

 int16 g_iTurn_Set;
 uint8 DianJi_STOP;
 uint32 ALL_TIME;
 unsigned char Shut_Down;
int straight_Flag,turn_Flag,sharpturn_Flag;

int8 width_50 = 0;
int8 width_100 = 0;

uint8 Start_Line = IMG_H - 5;

uint8 Annular_Num = 0;
uint8 Annular_Find_Num = 0;
uint8 Annular_Direction[10] = {0, 1, 1, 1, 1, 1, 1, 1, 1, 1};

uint8 Annular = 0;  //���ν���־
uint8 Annular_Out = 0;  //���γ���־

uint32 Annular_Time = 0;
uint32 Annular_Distance = 0;
uint32 Annular_Out_Distance = 0;

uint8 Side_Run_Mode = 0;

uint8 Right_Obstacle = 0;
uint8 Left_Obstacle = 0;



uint16 STOP_Line = 50;

uint8 Lost_Line = 0;
uint8 Lost_sj_Line = 0;
uint8 Obstacle = 0;



uint16 left_inflection_point = 0 ;
uint16 right_inflection_point = 0;                          
uint8  Roundaboutle = 0 ;
uint8  Roundaboutri = 0 ;
uint8  Roundabout_Set1 = 0;
uint8  Roundabout_Set2 = 0;

uint8  l_side = 0;
uint8  r_side = 0;

uint16 rb_count = 0;
uint16 count = 0;
uint16 lcount = 0;
uint16 rcount = 0;



float speed_s,speed_t,speed_st,steer_p;
int prospect;

extern uint8 IMG[CAMERA_H][CAMERA_W];
/*!  ͼ��˵��
��һ��
�ڶ���
******************************
------------------------------
������������Ҫ�ģ��ҳ��������У��ͻ����ҳ��˱��ߡ�����������������С�����
------------------------------
******************************

*/

/*!
-----------------------------------------------------
*  @brief      ͼ����
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void IMG_Handle(void)
{
    int16 y;
  
    Lost_Line = 0;
    Lost_sj_Line = 0;
    
//    Speed_select();

      if(Annular == 1)
    {
      //  Start_Line = IMG_H - 20;
        Annular_Handle();
      //  PTE6_OUT = 0;
      //  Find_StopLine();
    }
    if(Roundaboutle == 1)
    {
        
       Roundabout_Handle_Left2();
        
        Find_StopLine();
    }
    
    else if(Roundaboutri == 1)
    {
      
        
        Roundabout_Handle_Right2();
        
        Find_StopLine();
    } 
      
    else
   {
        Find_StopLine();
        
        Find_END_Line();
        
        
        
        //����5000������������ ��  ��ֹ�����ߡ��ϰ�����
//        if(Distance_All > 5000)
//            Annular_Find();     //�����������
             Roundabout_Pre();                                                     
            Roundabout_Find2();
        
        
            IMG_Find_Lines();
            
            if(Lost_Line == 1)
            {
                Find_Lines_Oppose();//�������
            }
            else
            {
                
                if(STOP_Line < 45)
                {
                   Find_Obstacle();//Ѱ���ϰ�
                    
                    if(Right_Obstacle == 1 || Left_Obstacle == 1)
                    {
                        Obstacle_Handle();
                        PTE7_OUT = 0;
                        Obstacle = 1;
                    }
                    else
                    {
                        PTE7_OUT = 1;
                    }
                }
            }
            //Find_StopLine();
         
        
    }
    //���������ܣ����ϰ�
//    if(Distance_All < 4000 && (Side_Run_Mode != 0))
//    {
//        Side_Run();
//    }
    //���߻��ܣ���ƫ��
    Middle_Line_Find();
    Road_Identity();
    
    for(y = IMG_H; y > 0; y--)    //���ߺڣ����߻�
    {   
      IMG[y][ Middle_Line[y]] = Black;
      IMG[y][ Right_Line[y]] = 0x64;
      IMG[y][ Left_Line[y]] = 0x64;
//       IMG[y][ 73] = Black;
    }

    //����Ϊ�����������ȱ仯
    width_50 = Right_Line[50] - Left_Line[50];
    width_100 = Right_Line[99] - Left_Line[99];
    
} 


/*!
-----------------------------------------------------
*  @brief      Ѱ�ҽ�ֹ�С�������
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Find_END_Line(void)
{
    int16 x, y, i, j = 0,temp;
    White_Line_Max = 0;  //����е�ֵ
    White_Line_MPos = 80;	//����е�λ��
    uint16 White_Line[10] = {0}; //ֻ���м�Ϊ׼���м�40���е�10��
    uint16 White_Line_Pos[10] = {0};//��¼���е�λ�� ��������
    for(x = 40; x < IMG_W - 40; x += 8, j++)
    {
        White_Line_Pos[j] = x;
        for(y = IMG_H - 1; y > 0; y--)
        {
            White_Line[j] = y; //��¼������  yֵԽС˵��  ����Խ��
            if(IMG[y][x] == Black)
            {
                break;
            }
        }
    }
    
    /********************  �����н�������   *************************************/
    //���Ż���������Ϊ�ṹ������
    uint16 White_Line_Sec = 0;      //�ڶ���
    uint16 White_Line_SPos = 0;
    //���Ϊ  �����һ��Ϊ�����
    for(i = 0; i < 10; i++)
    {
        for(j = i + 1; j < 10; j++)
        {
            if(White_Line[i] > White_Line[j])
            {
                temp = White_Line[j];
                White_Line[j] = White_Line[i];
                White_Line[i] = temp;
                
                temp = White_Line_Pos[j];
                White_Line_Pos[j] = White_Line_Pos[i];
                White_Line_Pos[i] = temp;
            }
        }
    }
    
    White_Line_Max = White_Line[0]; //������е�ֵ����������ֵ��
    White_Line_MPos = White_Line_Pos[0]; //������е�λ�ø�ֵ  ��������λ��
    White_Line_Sec = White_Line[1]; //������е�ֵ����������ֵ��
    White_Line_SPos = White_Line_Pos[1]; //������е�λ�ø�ֵ  ��������λ��
    
    //�ѿ����м�40�İ��е���������
    if((White_Line_Sec - White_Line_Max < 4) && 
        ((ABS(White_Line_MPos - 80) > ABS(White_Line_SPos - 80))))
    {
        White_Line_Max = White_Line_Sec; //������е�ֵ����������ֵ��
        White_Line_MPos = White_Line_SPos; //������е�λ�ø�ֵ  ��������λ��
    }
    
    //������С���������� �� Ѱ�ұ�����������
    STOP_Line = White_Line_Max;
    
    
}

/*!
-----------------------------------------------------
*  @brief      ͼ���� ->Ѱ�ұ��� �����������
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void IMG_Find_Lines(void)
{
    /**************************        �� �� �� ��   **********************************/

    
    int16 x, y, i, j, temp,p;
    int16 L = 0, R = 0;  //������߲��ҷ�Χ

    
    /************************ �Ȳ��� ǰ���� *******************************/
    for(y = IMG_H - 1; y > IMG_H - 3; y--)
    {
        Left_Line[y] = IMG_W;
        Right_Line[y] = 0;
        //���������
        for(x = White_Line_MPos; x > 0; x--)        //  -3 
        {
            if((Black == IMG[y][x]) && (White == IMG[y][x + 1]))
            {
                Left_Line[y] = x;
                break;
            }
        }
        //�����ұ���
        for(x = White_Line_MPos; x < IMG_W; x++)// 
        {
            if((Black == IMG[y][x]) && (White == IMG[y][x - 1]))
            {
                Right_Line[y] = x;
                break;
            }
        }
        // ����Ϊ ǰ�������ұ߽�û���ҵ�����
        if((Left_Line[y] == IMG_W) && (Right_Line[y] == 0))     //���߶�û�ҵ�
        {
            Lost_Line = 1;   //���߶�û���ҵ������д������²���
            return;     
        }
        else if((Left_Line[y] == IMG_W) && (Right_Line[y] != 0))//���û���ҵ�
        {
            Left_Line[y] = (int16)(Right_Line[y] - WIDTH(y) + 0.5);//��10 + 0.6 * y��Ϊ���������������仯���仯
        }
        else if((Right_Line[y] == 0) && (Left_Line[y] != IMG_W))
        {
            Right_Line[y] = (int16)(Left_Line[y] + WIDTH(y) + 0.5);//(80 - )
        } 
        
        if(l_side)
        Middle_Line[y] = (int16)( Right_Line[y] - WIDTH_HALF(y) + 0.5);
        else if(r_side)
        Middle_Line[y] = (int16)( Left_Line[y] - WIDTH_HALF(y) + 0.5);  
        else
        Middle_Line[y] = (int16)((Left_Line[y] + Right_Line[y])/2.0 + 0.5);
    }
    /************************ ����ı��ߣ���2�е���ֹ�У� *******************************/
    //���� ��5�е����߽�ֹ��
    for(y = IMG_H - 3; y > STOP_Line; y--)
    {   
        Left_Line[y] = IMG_W;
        Right_Line[y] = 0; 
        
        //���������
        L = Left_Line[y + 1] - 5;
        R = Left_Line[y + 1] + 5;
        if(L < 1)	//��ֹ����Խ��
            L = 1;
        if(R < 1)	//��ֹ����Խ��
            R = 1;
        for(x = R; x >= L; x--)
        {
            if((IMG[y][x] == Black) && (IMG[y][x + 1] == White) && (IMG[y][x + 2] == White))
            {
                Left_Line[y] = x;
                break;
            }
        }
        //�����ұ���
        L = Right_Line[y + 1] - 5;
        R = Right_Line[y + 1] + 5;
        if(R > IMG_W - 1)	//��ֹ�ұ�����Խ��
            R = IMG_W - 1; 
        if(L > IMG_W - 1)	//��ֹ�ұ�����Խ��
            L = IMG_W - 1; 
        
        for(x = L; x <= R; x++)
        {
            if((IMG[y][x] == Black) && (IMG[y][x - 1] == White) && (IMG[y][x - 2] == White))
            {
                Right_Line[y] = x;
                break;
            }
        }
        
        for(p = 80; p > 30; p--)
        {   
          if((Right_Line[p] == 0) && (Left_Line[p] == IMG_W))//���Ҷ�û���ҵ��������ã�
          { 
            Lost_sj_Line = 1;
          }
          else if((Right_Line[p] != 0) && (Left_Line[p] == IMG_W))//���û���ҵ�
          {
            Lost_sj_Line = 1;
          }
          else if((Right_Line[p] == 0) && (Left_Line[p] != IMG_W))//�Ҳ�û���ҵ�
          {
            Lost_sj_Line = 1;
          }
        }
        
        if((Right_Line[y] == 0) && (Left_Line[y] == IMG_W))//���Ҷ�û���ҵ�
        {
            Left_Line[y] = (int16)(White_Line_MPos - WIDTH_HALF(y) + 0.5); 
            Right_Line[y] = (int16)(White_Line_MPos  + WIDTH_HALF(y) + 0.5);  
           
        }
        else if((Right_Line[y] != 0) && (Left_Line[y] == IMG_W))//���û���ҵ�
        {
          
            if(Right_Line[y] > Right_Line[y + 1])
            {
                //                Left_Line[y] = (int16)(((White_Line_MPos + Middle_Line[y + 1]) / 2)- WIDTH_HALF(y));       //40 ��������ֵ 35Ϊ��һ���������ȵ�һ�� (100 - y)Ϊ�������ı仯��ƫ��
                //                Right_Line[y] = (int16)(((White_Line_MPos + Middle_Line[y + 1]) / 2)+ WIDTH_HALF(y));      //
                Left_Line[y] = (int16)((Middle_Line[y + 1])- WIDTH_HALF(y) + 0.5);       //40 ��������ֵ 35Ϊ��һ���������ȵ�һ�� (100 - y)Ϊ�������ı仯��ƫ��
                Right_Line[y] = (int16)((Middle_Line[y + 1])+ WIDTH_HALF(y) + 0.5);      //
                
            }
            else if((Right_Line[y] < Right_Line[y + 2]) && STOP_Line > 5) //���������������գ������ֻ��һ����
            {
                Left_Line[y] = (int16)(2*Left_Line[y+1] - Left_Line[y+2]);
                if(Left_Line[y] >= Left_Line[y + 1])
                {
                    Left_Line[y] = Left_Line[y + 1] - 1;
                }
            }
            else if(Left_Line[y + 1] <= 1) // �����һ�� û���ҵ�����  �������ͼ����  ���
            {
                Left_Line[y] = (int16)(Right_Line[y] - WIDTH(y));//(80 - )
            }
            else if (l_side)
            {
              Left_Line[y] = Right_Line[y] - WIDTH(y);
              rb_count ++;
              if(rb_count >= 20)
              {
                l_side = 0;
                rb_count = 0;
              }  
            
            }
            
            
            else        //��ͨ���
            {
                Left_Line[y] = (int16)(Right_Line[y] - WIDTH(y));
             }

            


        }
        else if((Right_Line[y] == 0) && (Left_Line[y] != IMG_W))//�Ҳ�û���ҵ�
        {
           
            if(Left_Line[y] < Left_Line[y + 1])
            {
                //                Left_Line[y] = (int16)(((White_Line_MPos + Middle_Line[y + 1]) / 2)- WIDTH_HALF(y));       //40 ��������ֵ 35Ϊ��һ���������ȵ�һ�� (100 - y)Ϊ�������ı仯��ƫ��
                //                Right_Line[y] = (int16)(((White_Line_MPos + Middle_Line[y + 1]) / 2)+ WIDTH_HALF(y) + 0.5);      //
                //            
                Left_Line[y] = (int16)((Middle_Line[y + 1])- WIDTH_HALF(y) + 0.5);       //40 ��������ֵ 35Ϊ��һ���������ȵ�һ�� (100 - y)Ϊ�������ı仯��ƫ��
                Right_Line[y] = (int16)((Middle_Line[y + 1])+ WIDTH_HALF(y) + 0.5);      //
                
            }
            else if( (Left_Line[y] > Left_Line[y + 2]) && STOP_Line > 5)//�ҹ�������Ҳ�ֻ��һ����
            {
                Right_Line[y] = (int16)(2 * Right_Line[y+1] - Right_Line[y+2] );//(80 - )
                if(Right_Line[y] <= Right_Line[y + 1])
                {
                    Right_Line[y] = Right_Line[y + 1] + 1;
                }
            }
            else if(Right_Line[y + 1] >= (IMG_W - 1))//�����һ��û���ҵ�����
            {
                Right_Line[y] = (int16)(Left_Line[y] + WIDTH(y) + 0.5);//(80 - )
            }
            else if (r_side)
            {
              Right_Line[y]= Left_Line[y] + WIDTH(y);
              rb_count ++;
              if(rb_count >= 20)
              {
                r_side = 0;
                rb_count = 0;
              }
            
            
            }
            else
            {
                Right_Line[y] = (int16)(Left_Line[y] + WIDTH(y) + 0.5);//(80 - )
            }
        }
        Middle_Line[y] = (int16)((Left_Line[y] + Right_Line[y])/2.0 + 0.5);
    }
    /*****************************  ����ƽ������������  ***********************/   
    for(y = IMG_H - 2; y > STOP_Line; y--)
    {   
        //���߷�������
        if(IMG[y][Middle_Line[y]] == Black)
        {
            Middle_Line[y] = White_Line_MPos;
        }
    }
}
/*!
-----------------------------------------------------
*  @brief      ��������
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Annular_Find(void)
{
    Annular_Find3();
}


/*!
-----------------------------------------------------
*  @brief     ����Ԥ����־ 
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Roundabout_Pre()

{
      int16 leftline[IMG_H] = {0};
      int16 rightline[IMG_H] = {0};
    
      int16 x, y;
    
      int16 L, R;
    
   
      if(STOP_Line > 20)
      return ;
    
      for(y = IMG_H - 1; y > IMG_H - 2; y--)
    {
        leftline[y] = IMG_W;
        rightline[y] = 0;
        //���������
        for(x = White_Line_MPos; x > 0; x--)        //  -3 
        {
            if((Black == IMG[y][x]) && (White == IMG[y][x + 1]))
            {
                leftline[y] = x;
                break;
            }
        }
        //�����ұ���
        for(x = White_Line_MPos; x < IMG_W; x++)// 
        {
            if((Black == IMG[y][x]) && (White == IMG[y][x - 1]))
            {
                rightline[y] = x;
                break;
            }
        }
        
         // ��߽綪ʧ �ұ߽��ҵ�
        if((leftline[y] == IMG_W) && (rightline[y] != 0) )                      
   {
            
          leftline[y] == (int16)( rightline[y] - WIDTH(y) + 0.5 );
            
          for(y = IMG_H - 2; y > IMG_H - 41 ; y--)
    {   
        leftline[y] = IMG_W;
        rightline[y] = 0; 
        
        //���������
        L = leftline[y + 1] - 10;
        R = leftline[y + 1] + 10;
        if(L < 1)	//��ֹ����Խ��
            L = 1;
        if(R < 1)	//��ֹ����Խ��
            R = 1;
        for(x = R; x >= L; x--)
        {
            if((IMG[y][x] == Black) && (IMG[y][x + 1] == White) && (IMG[y][x + 2] == White))
            {
                leftline[y] = x;
                
                break;
            }
        }
        //�����ұ���
        L = rightline[y + 1] - 10;
        R = rightline[y + 1] + 10;
        if(R > IMG_W - 1)	//��ֹ�ұ�����Խ��
            R = IMG_W - 1; 
        if(L > IMG_W - 1)	//��ֹ�ұ�����Խ��
            L = IMG_W - 1; 
        
        for(x = L; x <= R; x++)
        {
            if((IMG[y][x] == Black) && (IMG[y][x - 1] == White) && (IMG[y][x - 2] == White))
            {
                rightline[y] = x;
                
                break;
            }
          
        }
        
         if((rightline[y] != 0) && (leftline[y] == IMG_W))//���û���ҵ�
        {
            
                leftline[y] = (int16)(rightline[y] - WIDTH(y) + 0.5);
                lcount ++;
                
        }
        
        if (rightline[y] == 0)
          return ;

    }
    
    if(lcount <36)
    {
        lcount = 0;
        return ;
    
    }
     
   for(y = IMG_H - 5; y > IMG_H - 35 ; y--)
   {
    if((rightline[y] > rightline[y - 3] && rightline[y] > rightline[y + 3])||(rightline[y] < rightline[y - 3] && rightline[y] < rightline[y + 3])
       || (rightline[y] - rightline[y - 6] > 4)  )
        return ;
   
   }
     
     
     for(y = IMG_H - 41; y > STOP_Line ; y--)
    {   
        leftline[y] = IMG_W;
        rightline[y] = 0; 
        
        //���������
        L = leftline[y + 1] - 10;
        R = leftline[y + 1] + 10;
        if(L < 1)	//��ֹ����Խ��
            L = 1;
        if(R < 1)	//��ֹ����Խ��
            R = 1;
        for(x = R; x >= L; x--)
        {
            if((IMG[y][x] == Black) && (IMG[y][x + 1] == White) && (IMG[y][x + 2] == White))
            {
                leftline[y] = x;
                
                break;
            }
        }
        //�����ұ���
        L = rightline[y + 1] - 10;
        R = rightline[y + 1] + 10;
        if(R > IMG_W - 1)	//��ֹ�ұ�����Խ��
            R = IMG_W - 1; 
        if(L > IMG_W - 1)	//��ֹ�ұ�����Խ��
            L = IMG_W - 1; 
        
        for(x = L; x <= R; x++)
        {
            if((IMG[y][x] == Black) && (IMG[y][x - 1] == White) && (IMG[y][x - 2] == White))
            {
                rightline[y] = x;
                
                break;
            }
          
        }
        
         if((rightline[y] != 0) && (leftline[y] == IMG_W))//���û���ҵ�
        {
            
                leftline[y] = (int16)(rightline[y] - WIDTH(y) + 0.5);
                
                
        }
        
        

    }
    
    
    
    
    
    
    
    
    
    
      
            for(y = IMG_H-3; y > STOP_Line ; y -= 3 )                                //  
              
                {
                  
                  
                  
                  if(leftline[y] > leftline[y + 3] && leftline[y] > leftline[y - 3] && leftline[y - 3] > leftline[y - 6]) 
                  {
                        left_inflection_point = y ;
                       // left_inflection_point_col = rightline[y];
                      //  Roundaboutle = 1;
                      //  PTA6_OUT = 1; 
                      //  DELAY_MS(100);
                      //   PTA6_OUT = 0;
                        
                        
                         break;
                        
                  }
    
                }
       
      
      
          if (left_inflection_point != 0)                       //  Ѱ�ҵ��Ϸ�ͻ���  ������־λ��λ  ׼������  ��Բ��
          {
            for(y = left_inflection_point ; y > STOP_Line; y --  )
              
            
              {
                  leftline[y] = IMG_W;
                  rightline[y] = 0; 
        
                        //���������
                  L = leftline[y + 1] - 10;
                  R = leftline[y + 1] + 10;
                  if(L < 1)	//��ֹ����Խ��
                    L = 1;
                  if(R < 1)	//��ֹ����Խ��
                    R = 1;
                  for(x = R; x >= L; x--)
            {
                  if( (IMG[y][x - 4] == White)&& (IMG[y][x - 3] == White) && 
                     (IMG[y][x - 2] == Black) && (IMG[y][x - 1] == Black)&& (IMG[y][x] == Black) && (IMG[y][x + 1] == White) 
                       )
                {
                   
                  //  left_inflection_point2_col = leftline[y];
                    Roundabout_Set1 = 1 ;
                    
                    rcount = 0;
                    lcount = 0;
                    break;                    
                }
            }
                        //�����ұ���
                  L = rightline[y + 1] - 10;
                  R = rightline[y + 1] + 10;
                  if(R > IMG_W - 1)	//��ֹ�ұ�����Խ��
                    R = IMG_W - 1; 
                  if(L > IMG_W - 1)	//��ֹ�ұ�����Խ��
                    L = IMG_W - 1; 
        
            for(x = L; x <= R; x++)
          {
            if((IMG[y][x] == Black) && (IMG[y][x - 1] == White) && (IMG[y][x - 2] == White))
            {
                rightline[y] = x;
                break;
            }
              
          }
              if(Roundabout_Set1)
                break;
          
            }
          
        }
        
   }  
          
          else if((leftline[y] != IMG_W) && (rightline[y] == 0))                  //��߽��ҵ� �ұ߽綪ʧ     ����Ϊ���ֽ����������
        
        {
           rightline[y] = (int16)( leftline[y] + WIDTH(y) + 0.5 );
            
           for(y = IMG_H - 2; y > IMG_H - 41 ; y--)
    {   
        leftline[y] = IMG_W;
        rightline[y] = 0; 
        
        //���������
        L = leftline[y + 1] - 10;
        R = leftline[y + 1] + 10;
        if(L < 1)	//��ֹ����Խ��
            L = 1;
        if(R < 1)	//��ֹ����Խ��
            R = 1;
        for(x = R; x >= L; x--)
        {
            if((IMG[y][x] == Black) && (IMG[y][x + 1] == White) && (IMG[y][x + 2] == White))
            {
                leftline[y] = x;
                
                break;
            }
        }
        //�����ұ���
        L = rightline[y + 1] - 10;
        R = rightline[y + 1] + 10;
        if(R > IMG_W - 1)	//��ֹ�ұ�����Խ��
            R = IMG_W - 1; 
        if(L > IMG_W - 1)	//��ֹ�ұ�����Խ��
            L = IMG_W - 1; 
        
        for(x = L; x <= R; x++)
        {
            if((IMG[y][x] == Black) && (IMG[y][x - 1] == White) && (IMG[y][x - 2] == White))
            {
                rightline[y] = x;
                
                break;
            }
          
        }
        
         if((rightline[y] == 0) && (leftline[y] != IMG_W))//�Ҳ�û���ҵ�
        {
            
                rightline[y] = (int16)(leftline[y] + WIDTH(y) + 0.5);
                rcount ++;
                
        }
        
        if (leftline[y] == IMG_W)
          return ;

    }
    
    if(rcount <36)
    {
        rcount = 0;
        return ;
    
    }
     
   for(y = IMG_H - 5; y > IMG_H - 35 ; y--)
   {
    if((leftline[y] > leftline[y - 3] && leftline[y] > leftline[y + 3])||(leftline[y] < leftline[y - 3] && leftline[y] < leftline[y + 3])
       || (leftline[y - 6] - leftline[y] > 4)  )
        return ;
   
   }
     
     
     for(y = IMG_H - 41; y > STOP_Line ; y--)
    {   
        leftline[y] = IMG_W;
        rightline[y] = 0; 
        
        //���������
        L = leftline[y + 1] - 10;
        R = leftline[y + 1] + 10;
        if(L < 1)	//��ֹ����Խ��
            L = 1;
        if(R < 1)	//��ֹ����Խ��
            R = 1;
        for(x = R; x >= L; x--)
        {
            if((IMG[y][x] == Black) && (IMG[y][x + 1] == White) && (IMG[y][x + 2] == White))
            {
                leftline[y] = x;
                
                break;
            }
        }
        //�����ұ���
        L = rightline[y + 1] - 10;
        R = rightline[y + 1] + 10;
        if(R > IMG_W - 1)	//��ֹ�ұ�����Խ��
            R = IMG_W - 1; 
        if(L > IMG_W - 1)	//��ֹ�ұ�����Խ��
            L = IMG_W - 1; 
        
        for(x = L; x <= R; x++)
        {
            if((IMG[y][x] == Black) && (IMG[y][x - 1] == White) && (IMG[y][x - 2] == White))
            {
                rightline[y] = x;
                
                break;
            }
          
        }
        
         if((rightline[y] == 0) && (leftline[y] != IMG_W))//�Ҳ�û���ҵ�
        {
            
                rightline[y] = (int16)(leftline[y] + WIDTH(y) + 0.5);
                
                
        }
        
        

    }
    
    
    
    
    
    
    
    
    
    
      
            for(y = IMG_H-3; y > STOP_Line ; y -= 3 )                                //  
              
                {
                  
                  
                  
                  if(rightline[y] <  rightline[y + 3] && rightline[y] < rightline[y - 3] && rightline[y - 3] < rightline[y - 6]) 
                  {
                        right_inflection_point = y ;
                       // left_inflection_point_col = rightline[y];
                      //  Roundaboutle = 1;
                       //  PTA6_OUT = 1; 
                      //  DELAY_MS(100);
                       //  PTA6_OUT = 0;
                        
                        
                         break;
                        
                  }
    
                }
       
      
      
          if (right_inflection_point != 0)                       //  Ѱ�ҵ��Ϸ�ͻ���  ������־λ��λ  ׼������  ��Բ��
          {
            for(y = right_inflection_point ; y > STOP_Line; y --  )
              
            
              {
                  leftline[y] = IMG_W;
                  rightline[y] = 0; 
        
                        //���������
                  L = leftline[y + 1] - 10;
                  R = leftline[y + 1] + 10;
                  if(L < 1)	//��ֹ����Խ��
                    L = 1;
                  if(R < 1)	//��ֹ����Խ��
                    R = 1;
                  for(x = R; x >= L; x--)
            {
      
                  if((IMG[y][x] == Black) && (IMG[y][x + 1] == White) && (IMG[y][x + 2] == White))
            {
                leftline[y] = x;
                break;
            }
              
              
            }
                        //�����ұ���
                  L = rightline[y + 1] - 10;
                  R = rightline[y + 1] + 10;
                  if(R > IMG_W - 1)	//��ֹ�ұ�����Խ��
                    R = IMG_W - 1; 
                  if(L > IMG_W - 1)	//��ֹ�ұ�����Խ��
                    L = IMG_W - 1; 
        
            for(x = L; x <= R; x++)
          {
            if( (IMG[y][x + 4] == White)&& (IMG[y][x + 3] == White) && 
                     (IMG[y][x + 2] == Black) && (IMG[y][x + 1] == Black)&& (IMG[y][x] == Black) && (IMG[y][x - 1] == White) 
                       )
                {
                   
                  //  left_inflection_point2_col = leftline[y];
                    Roundabout_Set2 = 1 ;
                   
                    rcount = 0;
                    lcount = 0;
                    break;                    
                }
            
            
           
              
          }
              if(Roundabout_Set2)
                break;
          
            }
          
        }
          
          
          
        }
    
        
        
        else                                                                    //������� ����
              return ;

        
    }
 
  
  
  
  
  
  
  
  
  
}
        
       
        
  
  
  
    

  



  











/*!
-----------------------------------------------------
*  @brief     �������� 
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Roundabout_Find2()
{
    int16 leftline[IMG_H] = {0};
    int16 rightline[IMG_H] = {0};
    
    int16 x, y;
    
    int16 L, R;
    
                                                    //                     ����Ԥ�Ʊ�־λ
    
    
  
    
    
    for(y = IMG_H - 1; y > IMG_H - 2; y--)
    {
        leftline[y] = IMG_W;
        rightline[y] = 0;
        //���������
        for(x = White_Line_MPos; x > 0; x--)        //  -3 
        {
            if((Black == IMG[y][x]) && (White == IMG[y][x + 1]))
            {
                leftline[y] = x;
                break;
            }
        }
        //�����ұ���
        for(x = White_Line_MPos; x < IMG_W; x++)// 
        {
            if((Black == IMG[y][x]) && (White == IMG[y][x - 1]))
            {
                rightline[y] = x;
                break;
            }
        }
        
        
        
        
        
       if(((leftline[y] != IMG_W) && (rightline[y] != 0))  && (rightline[y] - leftline[y] >= WIDTH(y) + 15 ) && Roundabout_Set1)
       {   
          
          
                    for(y = IMG_H - 2; y > STOP_Line ; y--)
              {   
                  leftline[y] = IMG_W;
                  rightline[y] = 0; 
                  
                  //���������
                  L = leftline[y + 1] - 10;
                  R = leftline[y + 1] + 10;
                  if(L < 1)	//��ֹ����Խ��
                      L = 1;
                  if(R < 1)	//��ֹ����Խ��
                      R = 1;
                  for(x = R; x >= L; x--)
                  {
                      if((IMG[y][x] == Black) && (IMG[y][x + 1] == White) && (IMG[y][x + 2] == White))
                      {
                          leftline[y] = x;
                          
                          break;
                      }
                  }
                  //�����ұ���
                  L = rightline[y + 1] - 10;
                  R = rightline[y + 1] + 10;
                  if(R > IMG_W - 1)	//��ֹ�ұ�����Խ��
                      R = IMG_W - 1; 
                  if(L > IMG_W - 1)	//��ֹ�ұ�����Խ��
                      L = IMG_W - 1; 
                  
                  for(x = L; x <= R; x++)
                  {
                      if((IMG[y][x] == Black) && (IMG[y][x - 1] == White) && (IMG[y][x - 2] == White))
                      {
                          rightline[y] = x;
                          break;
                      }
                  }
                   if((rightline[y] != 0) && (leftline[y] == IMG_W))//���û���ҵ�
                  {
                      
                          leftline[y] = (int16)(rightline[y] - WIDTH(y) + 0.5);
                      
                  }
                  
                 

              }
              
              for(y = IMG_H-5; y > STOP_Line ; y-- )                                //  
              
                {
                  if(leftline[y] > leftline[y + 2] && leftline[y] > leftline[y - 2] && leftline[y - 2] > leftline[y - 4]) 
                  {
                          
                          
                      
                          Roundaboutle = 1 ;
                          Roundabout_Set1  = 0;
                        
                          
                         
                          break;
                        
                  }
    
                }
                
                
                
              
       }  
      
       else if (((leftline[y] != IMG_W) && (rightline[y] != 0))  && (rightline[y] - leftline[y] >= WIDTH(y) + 15 ) && Roundabout_Set2)
       
       
       {
       
              for(y = IMG_H - 2; y > STOP_Line ; y--)
              {   
                  leftline[y] = IMG_W;
                  rightline[y] = 0; 
                  
                  //���������
                  L = leftline[y + 1] - 10;
                  R = leftline[y + 1] + 10;
                  if(L < 1)	//��ֹ����Խ��
                      L = 1;
                  if(R < 1)	//��ֹ����Խ��
                      R = 1;
                  for(x = R; x >= L; x--)
                  {
                      if((IMG[y][x] == Black) && (IMG[y][x + 1] == White) && (IMG[y][x + 2] == White))
                      {
                          leftline[y] = x;
                          
                          break;
                      }
                  }
                  //�����ұ���
                  L = rightline[y + 1] - 10;
                  R = rightline[y + 1] + 10;
                  if(R > IMG_W - 1)	//��ֹ�ұ�����Խ��
                      R = IMG_W - 1; 
                  if(L > IMG_W - 1)	//��ֹ�ұ�����Խ��
                      L = IMG_W - 1; 
                  
                  for(x = L; x <= R; x++)
                  {
                      if((IMG[y][x] == Black) && (IMG[y][x - 1] == White) && (IMG[y][x - 2] == White))
                      {
                          rightline[y] = x;
                          break;
                      }
                  }
                   if((rightline[y] == 0) && (leftline[y] != IMG_W))//�Ҳ��û���ҵ�
                  {
                      
                          rightline[y] = (int16)(leftline[y] + WIDTH(y) + 0.5);
                      
                  }
                  
                 

              }
              
              for(y = IMG_H-5; y > STOP_Line ; y-- )                                //  
              
                {
                  if(rightline[y] < rightline[y + 2] && rightline[y] < rightline[y - 2] && rightline[y - 2] < rightline[y - 4]) 
                  {
                          
                          
                      
                          Roundaboutri = 1 ;
                          Roundabout_Set2   = 0;
                        
                          
                         
                        
                          break;
                        
                  }
    
                }
       
       
       
       
       }
         
         
         
         
         
       else
         return;
  
  
  
}





}


/*!
-----------------------------------------------------
*  @brief      �������� (��)
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/

void Roundabout_Handle_Left2(void)
{
   White_Line_Max = 0;  //����е�ֵ
    White_Line_MPos = 40;	//����е�λ��
    
   // uint32 time_temp = 0;
   // uint32 distance_temp = 0;
    int16 x, y, i, j, temp;
    int16 L = 0, R = 0;  //������߲��ҷ�Χ
    
    int16 leftline[IMG_H] = {0};
    int16 rightline[IMG_H] = {0};
    
   
    
                                              //                     ����Ԥ�Ʊ�־λ
   
    
    
    
  
    
   // int16 left_inflection_point = 0;
    
    
  // time_temp = ALL_TIME - Annular_Time;
  //  distance_temp = Distance_All - Annular_Distance;
    
    /***************�Ȳ��ֹ��  ���������  ���¶�Ϊ�ף��϶�Ϊ�������Ϊ���߽�ֹ��*************/
    uint16 White_Line[10] = {0}; //ֻ���м�Ϊ׼���м�40���е�10��
    uint16 White_Line_Pos[10] = {0};//��¼���е�λ�� ��������
    j = 0;
    
    for(x = 40; x < 120; x += 8, j++)
    {
        White_Line_Pos[j] = x;
        for(y = IMG_H - 1; y > 0; y--)
        {
            White_Line[j] = y; //��¼������  yֵԽС˵��  ����Խ��
            if(IMG[y][x] == Black)
            {
                break;
            }
        }
    }
    
    /********************  �����н�������   *************************************/
    //���Ϊ  �����һ��Ϊ�����
    for(i = 0; i < 10; i++)
    {
        for(j = i + 1; j < 10; j++)
        {
            if(White_Line[i] > White_Line[j])
            {
                temp = White_Line[j];
                White_Line[j] = White_Line[i];
                White_Line[i] = temp;
                
                temp = White_Line_Pos[j];
                White_Line_Pos[j] = White_Line_Pos[i];
                White_Line_Pos[i] = temp;
            }
        }
    }
    
    White_Line_Max = White_Line[0]; //������е�ֵ����������ֵ��
    White_Line_MPos = White_Line_Pos[0]; //������е�λ�ø�ֵ  ��������λ��
    //������С���������� �� Ѱ�ұ���������80��
    
    
    STOP_Line = White_Line_Max;
    
                                                     //                     ����Ԥ�Ʊ�־λ
   
    for(y = IMG_H - 1; y > IMG_H - 2; y--)
    {
        leftline[y] = IMG_W;
        rightline[y] = 0;
        //���������
        for(x = White_Line_MPos; x > 0; x--)        //  -3 
        {
            if((Black == IMG[y][x]) && (White == IMG[y][x + 1]))
            {
                leftline[y] = x;
                break;
            }
        }
        //�����ұ���
        for(x = White_Line_MPos; x < IMG_W; x++)// 
        {
            if((Black == IMG[y][x]) && (White == IMG[y][x - 1]))
            {
                rightline[y] = x;
                break;
                
            }
        }
    
         
        
    } 
        
     count ++;   
     
      if(count > 50 &&  STOP_Line<15 )
      {
      
       Roundaboutle = 0; 
       
       count = 0;
       return ;
     
      }
        
        
     y = IMG_H - 1;
    Left_Line[y] = IMG_W;
    for(x = White_Line_MPos - 1; x > 2; x--)//
    {
        if((Black == IMG[y][x]) && (White == IMG[y][x + 1]))
        {
            Left_Line[y] = x;
            break;
        }
    }
    if(Left_Line[y] == IMG_W)
    {
        Left_Line[y] = 0;
    }
    
    
    
    Right_Line[y] = 0;
    for(x = White_Line_MPos + 1; x < IMG_W - 1; x++)//
    {
        if((Black == IMG[y][x]) && (White == IMG[y][x - 1]))
        {
            Right_Line[y] = x;
            break;
        }
    }
    if(Right_Line[y] == 0)
    {
        Right_Line[y] =  Left_Line[y] + WIDTH(y);
        
        
        
        
    }
   // if(Right_Line[y] - Left_Line[y] < WIDTH(y) + 5  )
   // {
   //     Roundaboutle = 0;
   //     PTA6_OUT = 1; 
   //     DELAY_MS(100);
   //     PTA6_OUT = 0;    
        
   // }
    
    
    Middle_Line[y] = (int16)(Left_Line[y] + WIDTH_HALF(y) + 6);
    for(y = IMG_H - 2; y > STOP_Line; y--)
    {   
        Left_Line[y] = IMG_W;
        //���������
        L = Left_Line[y + 1] - 10;
        R = Left_Line[y + 1] + 10;
        if(L < 1)	//��ֹ����Խ��
            L = 1;
        if(R < 1)	//��ֹ����Խ��
            R = 1;
        for(x = R; x >= L; x--)
        {
            if((IMG[y][x] == Black) && (IMG[y][x + 1] == White))
            {
                Left_Line[y] = x;
                break;
            }
        }
        
        if(Left_Line[y] == IMG_W) //���Ҷ�û���ҵ�
        {
            Left_Line[y] = 0;  
        }  
        
    }
    for(y = IMG_H - 2; y > STOP_Line; y--)
    {   
        Right_Line[y] = 0; 
        
        //�����ұ���
        L = Left_Line[y] + WIDTH_HALF(y);
        R = IMG_W - 1;
        if(L < 1)	//��ֹ����Խ��
            L = 1;
        if(L > 80)	//��ֹ����Խ��
            L = 80;
        for(x = L; x <= R; x++)
        {
            if((IMG[y][x] == Black) && (IMG[y][x - 1] == White))
            {
                Right_Line[y] = x;
                break;
            }
        }
        
        if(Right_Line[y] == 0) //���Ҷ�û���ҵ�
        {
            Right_Line[y] = Left_Line[y] + WIDTH(y);
            
             
        }  
        
        if(Right_Line[y] - Left_Line[y] >  WIDTH(y))
        {
            Right_Line[y] = Left_Line[y] +  WIDTH(y);
        }
        Middle_Line[y] = (int16)(Left_Line[y] + WIDTH_HALF(y) + 4);          
    }





}

/*!
-----------------------------------------------------
*  @brief      �������� (��)
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Roundabout_Handle_Right2(void)
{
    White_Line_Max = 0;  //����е�ֵ
    White_Line_MPos = 40;	//����е�λ��
    
   // uint32 time_temp = 0;
   // uint32 distance_temp = 0;
    int16 x, y, i, j, temp;
    int16 L = 0, R = 0;  //������߲��ҷ�Χ
    
    int16 leftline[IMG_H] = {0};
    int16 rightline[IMG_H] = {0};
    
   
    
                                              //                     ����Ԥ�Ʊ�־λ
   
    
    
    
  
    
   // int16 left_inflection_point = 0;
    
    
  // time_temp = ALL_TIME - Annular_Time;
  //  distance_temp = Distance_All - Annular_Distance;
    
    /***************�Ȳ��ֹ��  ���������  ���¶�Ϊ�ף��϶�Ϊ�������Ϊ���߽�ֹ��*************/
    uint16 White_Line[10] = {0}; //ֻ���м�Ϊ׼���м�40���е�10��
    uint16 White_Line_Pos[10] = {0};//��¼���е�λ�� ��������
    j = 0;
    
    for(x = 40; x < 120; x += 8, j++)
    {
        White_Line_Pos[j] = x;
        for(y = IMG_H - 1; y > 0; y--)
        {
            White_Line[j] = y; //��¼������  yֵԽС˵��  ����Խ��
            if(IMG[y][x] == Black)
            {
                break;
            }
        }
    }
    
    /********************  �����н�������   *************************************/
    //���Ϊ  �����һ��Ϊ�����
    for(i = 0; i < 10; i++)
    {
        for(j = i + 1; j < 10; j++)
        {
            if(White_Line[i] > White_Line[j])
            {
                temp = White_Line[j];
                White_Line[j] = White_Line[i];
                White_Line[i] = temp;
                
                temp = White_Line_Pos[j];
                White_Line_Pos[j] = White_Line_Pos[i];
                White_Line_Pos[i] = temp;
            }
        }
    }
    
    White_Line_Max = White_Line[0]; //������е�ֵ����������ֵ��
    White_Line_MPos = White_Line_Pos[0]; //������е�λ�ø�ֵ  ��������λ��
    //������С���������� �� Ѱ�ұ���������80��
    
    
    STOP_Line = White_Line_Max;
    
                                                     //                     ����Ԥ�Ʊ�־λ
   
    for(y = IMG_H - 1; y > IMG_H - 2; y--)
    {
        leftline[y] = IMG_W;
        rightline[y] = 0;
        //���������
        for(x = White_Line_MPos; x > 0; x--)        //  -3 
        {
            if((Black == IMG[y][x]) && (White == IMG[y][x + 1]))
            {
                leftline[y] = x;
                break;
            }
        }
        //�����ұ���
        for(x = White_Line_MPos; x < IMG_W; x++)// 
        {
            if((Black == IMG[y][x]) && (White == IMG[y][x - 1]))
            {
                rightline[y] = x;
                break;
                
            }
        }
    
         
        
    } 
        
     count ++;   
     
      if(count > 50 &&  STOP_Line< 13 )
      {
      
       Roundaboutri = 0; 
       
       count = 0;
       return ;
     
      }
        
    y = IMG_H - 1;
      
    Right_Line[y] = 0;
    for(x = White_Line_MPos + 1; x < IMG_W - 1; x++)
    {
        if((Black == IMG[y][x]) && (White == IMG[y][x - 1]))
        {
            Right_Line[y] = x;
            break;
        }
    }
    if(Right_Line[y] == 0)
    {
        Right_Line[y] =  IMG_W;
        
        
        
        
    }
      
       Left_Line[y] = IMG_W;
    for(x = White_Line_MPos - 1; x > 2; x--)//
    {
        if((Black == IMG[y][x]) && (White == IMG[y][x + 1]))
        {
            Left_Line[y] = x;
            break;
        }
    }
    if(Left_Line[y] == IMG_W)
    {
        Left_Line[y] = Right_Line[y] - WIDTH(y) ;
    }
    
    
    
    
   // if(Right_Line[y] - Left_Line[y] < WIDTH(y) + 5  )
   // {
   //     Roundaboutle = 0;
   //     PTA6_OUT = 1; 
   //     DELAY_MS(100);
   //     PTA6_OUT = 0;    
        
   // }
    
    
    Middle_Line[y] = (int16)(Right_Line[y] - WIDTH_HALF(y) - 7  );
   
     for(y = IMG_H - 2; y > STOP_Line; y--)
    {   
        Right_Line[y] = 0; 
        
        //�����ұ���
        L = Left_Line[y] + WIDTH_HALF(y);
        R = IMG_W - 1;
        if(L < 1)	//��ֹ����Խ��
            L = 1;
        if(L > 80)	//��ֹ����Խ��
            L = 80;
        for(x = L; x <= R; x++)
        {
            if((IMG[y][x] == Black) && (IMG[y][x - 1] == White))
            {
                Right_Line[y] = x;
                break;
            }
        }
        
        if(Right_Line[y] == 0) //���Ҷ�û���ҵ�
        {
            Right_Line[y] = IMG_W;
            
             
        }  
        
     
                 
    }
    
    
    for(y = IMG_H - 2; y > STOP_Line; y--)
    {   
        Left_Line[y] = IMG_W;
        //���������
        L = Left_Line[y + 1] - 10;
        R = Left_Line[y + 1] + 10;
        if(L < 1)	//��ֹ����Խ��
            L = 1;
        if(R < 1)	//��ֹ����Խ��
            R = 1;
        for(x = R; x >= L; x--)
        {
            if((IMG[y][x] == Black) && (IMG[y][x + 1] == White))
            {
                Left_Line[y] = x;
                break;
            }
        }
        
        if(Left_Line[y] == IMG_W) //���Ҷ�û���ҵ�
        {
            Left_Line[y] = Right_Line[y] - WIDTH(y);  
        }  
        
        
        Middle_Line[y] = (int16)(Right_Line[y] - WIDTH_HALF(y) -5 );
    }
   

 



}





/*!
-----------------------------------------------------
*  @brief      ���⴦�� -> ������ұ��� 
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Find_Lines_Oppose(void)
{
    int16 x, y;
    int16 L = 0, R = 0;  //������߲��ҷ�Χ
    
    int temp1 = 0;
    int temp2 = 0;
    int temp3 = 0;
    //�޸������У�����һ��
    STOP_Line = STOP_Line + 10;
    if(STOP_Line > IMG_H - 2)
    {
        Shut_Down = 1; 
//        Error[0] = 1;
        return;
        
    }
    y = STOP_Line;
    Left_Line[y] = IMG_W;
    Right_Line[y] = 0; 
    //���������
    for(x = White_Line_MPos + 1; x >= 0; x--)
    {
        if((Black == IMG[y][x]) && (White == IMG[y][x + 1]))
        {
            Left_Line[y] = x;
            break;
        }
    }
    //�����ұ���
    for(x = White_Line_MPos - 1; x < IMG_W; x++)//
    {
        if((Black == IMG[y][x]) && (White == IMG[y][x - 1]))
        {
            Right_Line[y] = x;
            break;
        }
    }
    if((Right_Line[y] != 0) && (Left_Line[y] != IMG_W))
    {
        temp1 = White_Line_MPos -Left_Line[y] ;
        temp2 = Right_Line[y] - White_Line_MPos;
        
        temp3 = 1.2 * WIDTH(y);
        if((temp1 < temp3) && (temp2 > temp3))
            Right_Line[y] = (int16)(Left_Line[y] + WIDTH(y));//
        if((temp2 < temp3) && (temp1 > temp3))
            Left_Line[y] = (int16)(Right_Line[y] - WIDTH(y));//
    }
    if((Right_Line[y] == 0))
        Right_Line[y] = (int16)(Left_Line[y] + WIDTH(y));//
    if((Left_Line[y] == IMG_W))
        Left_Line[y] = (int16)(Right_Line[y] - WIDTH(y) + 0.5);//
    Middle_Line[y] = (int16)((Left_Line[y] + Right_Line[y])/2.0 + 0.5);  
    
    
    //�������£�Ѱ�ұ���
    for(y = STOP_Line + 1; y < IMG_H; y++)
    {   
        Left_Line[y] = IMG_W;
        Right_Line[y] = 0; 
        
        //���������
        L = Left_Line[y - 1] - 15;
        R = Left_Line[y - 1] + 15;
        if(L < 0)	//��ֹ����Խ��
            L = 0;
        if(R < 0)	//��ֹ����Խ��
            R = 0;
        
        for(x = R; x >= L; x--)
        {
            if((IMG[y][x] == Black) && (IMG[y][x + 1] == White) && (IMG[y][x + 2] == White))
            {
                Left_Line[y] = x;
                break;
            }
        }
        
        //�����ұ���
        L = Right_Line[y - 1] - 15;
        R = Right_Line[y - 1] + 15;
        if(R > IMG_W - 1)	//��ֹ�ұ�����Խ��
            R = IMG_W - 1; 
        if(L > IMG_W - 1)	//��ֹ�ұ�����Խ��
            L = IMG_W - 1; 
        
        for(x = L; x <=R; x++)
        {
            if((IMG[y][x] == Black) && (IMG[y][x - 1] == White) && (IMG[y][x - 2] == White))
            {
                Right_Line[y] = x;
                break;
            }
        }
        if((Right_Line[y] == 0) && (Left_Line[y] == IMG_W))//���Ҷ�û���ҵ�
        {
            Left_Line[y] = (int16)(White_Line_MPos - WIDTH_HALF(y) + 0.5); 
            Right_Line[y] = (int16)(White_Line_MPos + WIDTH_HALF(y) + 0.5);  
        }
        else if((Right_Line[y] != 0) && (Left_Line[y] == IMG_W))//���û���ҵ�
        {
            Left_Line[y] = (int16)(Right_Line[y - 1] - WIDTH(y - 1));
        }
        else if((Right_Line[y] == 0) && (Left_Line[y] != IMG_W))//�Ҳ�û���ҵ�
        {
            Right_Line[y] = (int16)(Left_Line[y - 1] + WIDTH(y - 1) + 0.5);//(80 
        }
        Middle_Line[y] = (int16)((Left_Line[y] + Right_Line[y])/2.0 + 0.5);     
    }
    
    /*****************************  ����ƽ������������  ***********************/   
    for(y = IMG_H - 2; y > STOP_Line; y--)
    {   
        //���߷�������
        if(IMG[y][Middle_Line[y]] == Black)
        {
            Middle_Line[y] = White_Line_MPos;
        }
    }
}

/*!
-----------------------------------------------------
*  @brief       Ѱ���ϰ�
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Find_Obstacle(void)
{
    int  x, y;
    
    uint8 find_stop = 45;//�ϰ� ��Զ������
    
    Right_Obstacle = 0;
    Left_Obstacle = 0;
    Obstacle = 0;
    
    uint8 left_line[IMG_H] = {160};
    uint8 right_line[IMG_H] ={0};
    uint8 middle_line[IMG_H];
    uint8 width[IMG_H];
    
    
    uint8 left_TiaoBian = 0;
    uint8 right_TiaoBian = 0;
    uint8 left_TiaoBian_y = 120;
    uint8 right_TiaoBian_y = 120;
    
    for(y = IMG_H - 1; y > find_stop; y -= 3)
    {
        left_line[y] = 160;
        right_line[y] = 0;
        for(x = White_Line_MPos; x > 3; x--)
        {
            
            if(IMG[y][x] == Black && (IMG[y][x + 1] == White) )
            {
                left_line[y] = x;
                break;
            }
        }
        for(x = White_Line_MPos; x < IMG_W - 4; x++)
        {
            
            if(IMG[y][x - 1] == White && (IMG[y][x] == Black) )
            {
                right_line[y] = x;
                break;
            }
        }
        
        if(right_line[y] == 0 || (left_line[y] == 160))
            return;
        middle_line[y] = (uint8)((right_line[y] + left_line[y]) / 2 + 0.5);
        width[y] = right_line[y] - left_line[y];
    }
    
    uint8 left_nei_tiaobian = 0;
    uint8 right_nei_tiaobian = 0;
    uint8 tiaobian_y = 0;
    
    for(y = IMG_H - 13; y > find_stop + 13; y -= 3)
    { 
        if((left_line[y] - left_line[y + 6] > 10)
           && (left_line[y - 6] - left_line[y] < 6)
               && (left_line[y - 12] - left_line[y - 6] < 6)
                   && (left_line[y + 6] - left_line[y + 12] < 6))
        {
            left_nei_tiaobian = 1;
            tiaobian_y = y;
            break;
        }
    }
    for(y = IMG_H - 10; y > find_stop + 10; y -= 3)
    { 
        if((right_line[y + 3] - right_line[y] > 10)
           && (right_line[y] - right_line[y - 3] < 6)
               && (right_line[y - 3] - right_line[y - 6] < 6)
                   && (right_line[y + 6] - right_line[y + 3] < 6))
        {
            right_nei_tiaobian = 1;
            tiaobian_y = y;
            break;
        }
    }
    if(right_nei_tiaobian + left_nei_tiaobian != 1)
    {
        return;
    }
    
    for(y = IMG_H - 4; y > tiaobian_y - 4; y -= 3)
    {
        if((left_line[y] < left_line[y + 3]) && (right_line[y] > right_line[y + 3]))
        {
            return;
        }
    }
    
    if(width[tiaobian_y] < 25)
        return;
    

       if(left_nei_tiaobian == 1)
        {
            Left_Obstacle = 1;
        }
        else if(right_nei_tiaobian == 1)
        {
            Right_Obstacle = 1;
        }
}
/*!
-----------------------------------------------------
*  @brief        �ϰ�����
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Obstacle_Handle(void)
{
    uint8 y = 0;
    
    if(Right_Obstacle == 1)
    {
        for(y = IMG_H - 1; y > STOP_Line; y--)
        {   
            Middle_Line[y] = (int16)(Left_Line[y] + WIDTH(y) * 0.18 + 0.5);  //
        }
    }
    else if(Left_Obstacle == 1)
    {
        for(y = IMG_H - 1; y > STOP_Line; y--)
        {   
            Middle_Line[y] = (int16)(Right_Line[y] - WIDTH(y) * 0.18 + 0.5);  //
        }
    }
}

/*!
-----------------------------------------------------
*  @brief       ͣ���� - ������
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Find_StopLine(void)
{
    uint8 i; 
    uint8 left_line = 160;
    uint8 right_line = 0;
    uint8 middle = 80;
    int16 width = 0;
    
    if(Distance_All < 2000)
        return;
    
    for(i = 70; i < 90; i++)
    {
        if(IMG[90][i] == White)
        {
            middle = i;
            break;
        }
    }
    if(i == 90)
        return;
    
    for(i = middle; i > 60; i--)
    {
        if((IMG[90][i]) == Black)
        {
            left_line = i;
            break;
        }
    }
    for(i = middle; i < IMG_W - 60; i++)
    {
        if((IMG[90][i]) == Black)
        {
            right_line = i;
            break;
        }
    }
    width = (right_line - left_line);
    if(right_line > left_line)
    {
        if((width < 30))
        {
            DianJi_STOP = 1;
//            PTA6_OUT =1;
        }
    }   
}





/*!

-----------------------------------------------------
*  @brief       ���� ����
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Annular_Handle(void)
{
   if(Annular_Direction[Annular_Find_Num] == 2)
        Annular_Handle_Right();
   // else if(Annular_Direction[Annular_Find_Num] == 1)
    //    Annular_Handle_Left();
    //else
   //     Annular_Handle_Left();
}

/*!
-----------------------------------------------------
*  @brief      ƫ�����----û���õ�
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Variance_Calculate(void)
{
    int y = 0;
    int sum = 0;
    int number = 0;
    float average = 0;
    for(y = IMG_H - 2; y > STOP_Line + 1; y--)
    {
        sum += 80 - Middle_Line[y];
        number++;
    }
    
    average = sum / ((float)number);
    
    int v_sum = 0;
    int variance = 0;
    for(y = IMG_H - 2; y > STOP_Line + 1; y--)
    {
        v_sum += ((Middle_Line[y] - average) * (Middle_Line[y] - average));
    }
    variance = v_sum / number;
    
    
}
/*!
-----------------------------------------------------
*  @brief      ������
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Side_Run(void)
{
    uint8 left_line[IMG_H] = {160};
    uint8 right_line[IMG_H] ={0};

    if(STOP_Line < 50)
    {
      STOP_Line = 50;
    }
    int x = 0, y = 0;
    for(y = IMG_H - 1; y > STOP_Line; y --)
    {
        left_line[y] = 160;
        right_line[y] = 0;
        for(x = White_Line_MPos; x > 3; x--)
        {
            
            if(IMG[y][x] == Black && (IMG[y][x + 1] == White) )
            {
                left_line[y] = x;
                break;
            }
        }
        for(x = White_Line_MPos; x < IMG_W - 4; x++)
        {
            
            if(IMG[y][x - 1] == White && (IMG[y][x] == Black) )
            {
                right_line[y] = x;
                break;
            }
        }
    }
    
    
    if(Side_Run_Mode == 2)
    {
        for(y = IMG_H - 1; y > STOP_Line; y--)
        {   
            Middle_Line[y] = (int16)(right_line[y] - WIDTH(y) * 0.25 + 0.5);  //
        }
    }
    else if(Side_Run_Mode == 1)
    {
        for(y = IMG_H - 1; y > STOP_Line; y--)
        {   
            Middle_Line[y] = (int16)(left_line[y] + WIDTH(y) * 0.29 + 0.5);  //
        }
    }
}

/*!
-----------------------------------------------------
*  @brief      ·������
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Road_Identity(void)
{
  int straight,turn,i;
  
  /************************·��:ֱ������*******************/
        for(i=90;i>40;i--)
        {
          if( Middle_Line[i]- Middle_Line[i+1]==0)
            straight++;
//          else
//            turn++;
        }
        if(straight>30&&Lost_sj_Line == 0) 
        {
          straight=0;
          straight_Flag=1;
          turn_Flag=0; 
          sharpturn_Flag=0;
        }
        else if(straight<1)
        {
          straight=0;
          sharpturn_Flag=1;
          turn_Flag=0;
          straight_Flag=0;
        }
        else 
        {
          straight=0;
          turn_Flag=1;
          straight_Flag=0;
          sharpturn_Flag=0;
        }
        
          
}

///*!
//-----------------------------------------------------
//*  @brief      �ٶ�ѡ��
//*  @param      
//*  @since      v1.0
//-----------------------------------------------------
//*/
//void Speed_select(void)
//{
////  if(PTB21_IN == 0)
////  {
//    speed_s=55;
//    speed_t=47;
//    speed_st=47;
//    steer_p=0.08;
//    prospect=8;
////  }
//}

/*!
-----------------------------------------------------
*  @brief       ����ƫ�� ����
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
int16 g_iTurn_Set_Last = 0;
int16 g_iTurn_Set = 0;

void Middle_Line_Find(void)
{
    int y;
    int sum = 0;  //��ƫ��ֵ
    int sum_ratio = 0;       //ƫ����ϵ��
    int ratio = 8;    //ƫ��Ȩֵ

    if(STOP_Line < 30)
    {
        STOP_Line = 30;
    if(Start_Line > 90)
        Start_Line = 90;
    else
        Start_Line = 105;
    }

//    if(Speed_LL>15)
//    {
//      prospect=10;
//    }
//    else
//    {
//      prospect=13;
//    }
    for(y = 115;y > STOP_Line + 15; y--)            //������ǰհ
    {
        sum += (73 - Middle_Line[y]) * ratio;
        sum_ratio += ratio;
        ratio++;
    }
    g_iTurn_Set_Last = g_iTurn_Set;
    g_iTurn_Set = (int16)(sum/sum_ratio);
    if(g_iTurn_Set > 35)
    {
        g_iTurn_Set = 35;
    }
    if(g_iTurn_Set < -35)
    {
        g_iTurn_Set = -35;
    }
    //g_iTurn_Set = (int16)(g_iTurn_Set/2.0 + 0.5);
}

/****************���PD����*******************/
void MySteering_PID_Adjust(void)
{

	float A = 0.03,B=A*0.7;

        float D_Steering = 0.02;
	float steering_a;
        static float Pre1_Error[4]; 
        volatile signed char angle; 

        if(Speed_LL>45)steering_a = B;
	else steering_a = A;
        Pre1_Error[3]=Pre1_Error[2];
        Pre1_Error[2]=Pre1_Error[1];
        Pre1_Error[1]=Pre1_Error[0];
        Pre1_Error[0]=steering_a*((g_iTurn_Set*abs(g_iTurn_Set))+g_iTurn_Set*8.75)+D_Steering*(g_iTurn_Set-g_iTurn_Set_Last);
	angle=Pre1_Error[0];//*0.4+Pre1_Error[1]*0.3+Pre1_Error[2]*0.2+ Pre1_Error[1]*0.1;		

			if(angle>35)		//����ת�Ƿ��ȣ�������
			{
				angle = 35;
			}
			else if(angle<-35)
			{
				angle = -35;
			} 
			
		SHEER_duty(angle);
}

/**************���PID����***************/
void 	MyMotor_PID_Adjust(void)
{ 
        float P_Motor_L;		//����PID
        float I_Motor_L ;
        float D_Motor_L ;
        float ahpha_L;
        float Speed_set;
        static bool stop=0;
/*********************�����ٶ����*********************************/
float SpeedLL_set,stop_cnt=0;		//�ٶ��趨ֵ
static float g_fCarSpeed,ControlSpeed,Offset_Err;
static float SpeedLL_Measure[5];		//��ǰ�ٶȺ���һ���ٶȲ���ֵ
static float SpeedLL_Offset[2];		//�ٶ����趨ƫ��
static float SpeedLL_DutyCycle[2];		//����������ٶ�ռ�ձ�
//static signed int d_uk_L[2];		//��������ȫ΢��PID����ʽ�ı仯
//static signed int d_uk_vice_L;		//΢����������ʽ�仯��

	 /**********************ײ����ͣ��***********************/
	if(Speed_LL<1&&SpeedLL_DutyCycle[0]>30&&Distance_All>10000)
	{
		stop=1;                
	}
        
	/***********************Ԥ���ٶ�*************************/
        if(stop==1)
	{
		SpeedLL_set = 0;
                PTE6_OUT=0;
                PTE7_OUT=1;
//                straight_Flag=0;
//                turn_Flag=0;
	}
        else
        {
          if(straight_Flag==1)
          {
                SpeedLL_set = 48;
                PTE7_OUT=0;
          }
          if(turn_Flag==1)
          {
        	SpeedLL_set = 42;
                PTE7_OUT=1;
          }
          if(sharpturn_Flag==1)
          {
                SpeedLL_set = 42;
                
          }
        }
//        SpeedLL_set = 20;
//        if(PTB23_IN == 0) 
//        {
//           SpeedLL_set = 30;
//        }
	if(DianJi_STOP)		//�����ߣ�ͣ��
	{
		SpeedLL_set = 0;		//ֹͣ
	}
	/************************************�����ٶ����***********************************/
        SpeedLL_Measure[4] = SpeedLL_Measure[3];
	SpeedLL_Measure[3] = SpeedLL_Measure[2];
	SpeedLL_Measure[2] = SpeedLL_Measure[1];
	SpeedLL_Measure[1] = SpeedLL_Measure[0];		//��ǰ�ٶȸ��ϴ�
	SpeedLL_Measure[0] = Speed_LL;	
        
        /************************************�����˲�***********************************/
        if(((Speed_LL-SpeedLL_Measure[4])> 25)||((Speed_LL-SpeedLL_Measure[4])<-25)) 
          Speed_LL=SpeedLL_Measure[4];
  
        g_fCarSpeed=g_fCarSpeed*0.1+0.9*Speed_LL;
  
        ControlSpeed=ControlSpeed*0.95+g_fCarSpeed*0.05;
	
        /************************************ƫ����***********************************/
        SpeedLL_Offset[1] = SpeedLL_Offset[0];
	SpeedLL_Offset[0] = SpeedLL_set-ControlSpeed;
        Offset_Err=SpeedLL_Offset[0]-SpeedLL_Offset[1];
	/******�趨����PID����***/
	P_Motor_L = 1.1;
	I_Motor_L = 0;
	
	/********************�����ٶ�����ʽPID����****************************************/

	SpeedLL_DutyCycle[1] = SpeedLL_DutyCycle[0];
	SpeedLL_DutyCycle[0] += P_Motor_L*Offset_Err+I_Motor_L*SpeedLL_Offset[0];
	SpeedLL_DutyCycle[0] = (SpeedLL_DutyCycle[0]*0.9+SpeedLL_DutyCycle[1]*0.1);
	//����ռ�ձ��޷�
	if(SpeedLL_DutyCycle[0]>60||Speed_LL>50)
	{
		SpeedLL_DutyCycle[0] = 30;
	}
        else if(SpeedLL_DutyCycle[0]<-12||Speed_LL<-12)
	{

		SpeedLL_DutyCycle[0] = 0;

	}
       if(DianJi_STOP)		//�����ߣ�ͣ��
	{
		SpeedLL_DutyCycle[0] = 0;		//ֹͣ              
	}
	/***********************���ռ�ձȵ����***************************/
	MOTOR_duty(SpeedLL_DutyCycle[0]);
}

////�ϵ��λ��ʱһ��ʱ��ȴ�ϵͳ�ȶ�������������ͷ����ʼ����
//void Delay_Until_statue(void)
//{
//	volatile uint32_t i;
//	for(i=0; i<800000; i++)
//	{
//		__asm("NOP");
//	}
//}
//
////������ʱ
//void Delay_Start_Mycar(void)
//{
//	volatile uint32_t i;
//	for(i=0; i<2500000; i++)
//	{
//		__asm("NOP");
//	}
//}
//
////������ʱ2
//void Delay_Start_Mycar2(void)
//{
//	volatile uint32_t i;
//	for(i=0; i<3000000; i++)
//	{
//		__asm("NOP");
//	}
//}

/*****�������ã����������ϰ���*****/
//void StartMy_car()
//{
//	Over_Stop_Flag = false;			//����ͣ����־λ
//	/*******************ʱ��************************/
//	if(Runtime_cnt<St_over_cnt)
//	{
////		if(F_car)				//����ֱ�� ���ǰ������
////		{
//			Default_LL_Boundary = 57;		
//			Default_MiddleLine = 74;		//...�м���...
//			Default_RR_Boundary = 91;		//...�ұ߽�...
//			if(PTB23_IN==0)
//			{
//				Default_LL_Boundary = 55;		
//				Default_MiddleLine = 75;		//...�м���...
//				Default_RR_Boundary = 95;		//...�ұ߽�...
//			}
////		}
////		else				//����ֱ�� ��κ󳵿���
////		{
////				Default_LL_Boundary = 37;		
////				Default_MiddleLine = 54;		//...�м���...
////				Default_RR_Boundary = 71;		//...�ұ߽�...
////				if(S23_key==0)
////				{
////					Default_LL_Boundary = 33;		
////					Default_MiddleLine = 53;		//...�м���...
////					Default_RR_Boundary = 73;		//...�ұ߽�...
////				}
////		}
//	}
//	else		//������ɽ�������
//	{
//			Default_LL_Boundary = 47;		
//			Default_MiddleLine = 64;		//...�м���...
//			Default_RR_Boundary = 81;		//...�ұ߽�...
//			if(PTB23_IN==0)
//			{
//				Default_LL_Boundary = 44;		
//				Default_MiddleLine = 64;		//...�м���...
//				Default_RR_Boundary = 84;		//...�ұ߽�...
//			}
//	}
////	if(SD6_key==0&&SD7_key!=0)
////	{
////		if(!F_car&&Runtime_cnt>St_over_start&&Runtime_cnt<(St_over_start+St_over_stop+40))
////		{
////			Over_Stop_Flag = true;
////		}
////	}
////	else
////	{
////		if(!F_car&&Runtime_cnt>St_over_start&&Runtime_cnt<(St_over_start+St_over_stop))
////		{
//			Over_Stop_Flag = true;
////		}
////	}
//}


/*****�������ã�������ǰ���ϰ���*****/
//void StartMy_car1()
//{
//	Over_ObsLL_Flag = false;
//	/*******************ʱ��************************/
//	if(Runtime_cnt<St_obst_cnt1)
//	{
//		Default_LL_Boundary = 42;		
//		Default_MiddleLine = 59;		//...�м���...
//		Default_RR_Boundary = 76;		//...�ұ߽�...
//		if(PTB23_IN==0)
//		{
//			Default_LL_Boundary = 39;		
//			Default_MiddleLine = 59;		//...�м���...
//			Default_RR_Boundary = 79;		//...�ұ߽�...
//		}
//	}
////	else if(!F_car&&Runtime_cnt<St_obst_cnt2)		
////	{
////		Default_LL_Boundary = 42;		
////		Default_MiddleLine = 59;		//...�м���...
////		Default_RR_Boundary = 76;		//...�ұ߽�...
////		if(PTB23_IN==0)
////		{
////			Default_LL_Boundary = 39;		
////			Default_MiddleLine = 59;		//...�м���...
////			Default_RR_Boundary = 79;		//...�ұ߽�...
////		}
////	}
//	else		//������ɽ�������
//	{
//		Default_LL_Boundary = 47;		
//		Default_MiddleLine = 64;		//...�м���...
//		Default_RR_Boundary = 81;		//...�ұ߽�...
//		if(PTB23_IN==0)
//		{
//			Default_LL_Boundary = 44;		
//			Default_MiddleLine = 64;		//...�м���...
//			Default_RR_Boundary = 84;		//...�ұ߽�...
//		}
//	}
	
//	if(!F_car&&Runtime_cnt>St_obst_go_cnt&&Runtime_cnt<St_obstStop_cnt)
//	{
//		Over_ObsLL_Flag = true;
//	}
//}

///*****�������ã�������ǰ���ϰ���*****/
//void StartMy_car2()
//{
//	Over_ObsRR_Flag = false;
//	/*******************ʱ��************************/
//	if(Runtime_cnt<St_obst_cnt1)
//	{
//		Default_LL_Boundary = 52;		
//		Default_MiddleLine = 69;		//...�м���...
//		Default_RR_Boundary = 86;		//...�ұ߽�...
//		if(PTB23_IN==0)
//		{
//			Default_LL_Boundary = 49;		
//			Default_MiddleLine = 69;		//...�м���...
//			Default_RR_Boundary = 89;		//...�ұ߽�...
//		}
//	}
////	else if(!F_car&&Runtime_cnt<St_obst_cnt2)		
////	{
////		Default_LL_Boundary = 52;		
////		Default_MiddleLine = 69;		//...�м���...
////		Default_RR_Boundary = 86;		//...�ұ߽�...
////		if(PTB23_IN==0)
////		{
////			Default_LL_Boundary = 49;		
////			Default_MiddleLine = 69;		//...�м���...
////			Default_RR_Boundary = 89;		//...�ұ߽�...
////		}
////	}
//	
//	else		//��������
//	{
//			Default_LL_Boundary = 47;		
//			Default_MiddleLine = 64;		//...�м���...
//			Default_RR_Boundary = 81;		//...�ұ߽�...
//			if(PTB23_IN==0)
//			{
//				Default_LL_Boundary = 44;		
//				Default_MiddleLine = 64;		//...�м���...
//				Default_RR_Boundary = 84;		//...�ұ߽�...
//			}
//	}
//	
////	if(!F_car&&Runtime_cnt>St_obst_go_cnt&&Runtime_cnt<St_obstStop_cnt)
////	{
////		Over_ObsRR_Flag = true;
////	}
//}
//
///*****���ϰ���������******************/
//void StartMy_car3()
//{
//	Over_Obsnothing_Flag = false;
//	if(Runtime_cnt>St_obst_go_cnt&&Runtime_cnt<St_obstStop_cnt)
//	{
//		Over_Obsnothing_Flag = true;
//	}
//}
//
//void Start_Mycar_Mode()
//{
////	if(SD2_key!=0&&SD4_key!=0)		//��������ģʽ
////	{
////		StartMy_car();
////	}
////	else if(SD2_key==0&&SD4_key!=0)		//���ϰ�����ģʽ
////	{
////		StartMy_car1();
////	}
////	else if(SD2_key!=0&&SD4_key==0)		//���ϰ�����ģʽ
////	{
////		StartMy_car2();
////	}
////	else	//�����������޳�����ģʽ
////	{
//		StartMy_car3();
////	}
//}
/*!
-----------------------------------------------------
*  @brief      �������� ����
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Annular_Handle_Right(void)
{
  /**************************        �� �� �� ��   **********************************/
    White_Line_Max = 0;  //����е�ֵ
    White_Line_MPos = 120;	//����е�λ��
    
    uint32 time_temp = 0;
    uint32 distance_temp = 0;
    int16 x, y, i, j, temp;
    int16 L = 0, R = 0;  //������߲��ҷ�Χ
    
    int16 right_inflection_point = 0;
    
    
    time_temp = ALL_TIME - Annular_Time;
    distance_temp = Distance_All - Annular_Distance;
    
    /***************�Ȳ��ֹ��  ���������  ���¶�Ϊ�ף��϶�Ϊ�������Ϊ���߽�ֹ��*************/
    uint16 White_Line[10] = {0}; //ֻ���м�Ϊ׼���м�40���е�10��
    uint16 White_Line_Pos[10] = {0};//��¼���е�λ�� ��������
    j = 0;
    for(x = 60; x < 140; x += 8, j++)
    {
        White_Line_Pos[j] = x;
        for(y = IMG_H - 1; y > 0; y--)
        {
            White_Line[j] = y; //��¼������  yֵԽС˵��  ����Խ��
            if(IMG[y][x] == Black)
            {
                break;
            }
        }
    }
    
    /********************  �����н�������   *************************************/
    //���Ϊ  �����һ��Ϊ�����
    for(i = 0; i < 10; i++)
    {
        for(j = i + 1; j < 10; j++)
        {
            if(White_Line[i] > White_Line[j])
            {
                temp = White_Line[j];
                White_Line[j] = White_Line[i];
                White_Line[i] = temp;
                
                temp = White_Line_Pos[j];
                White_Line_Pos[j] = White_Line_Pos[i];
                White_Line_Pos[i] = temp;
            }
        }
    }
    
    White_Line_Max = White_Line[0]; //������е�ֵ����������ֵ��
    White_Line_MPos = White_Line_Pos[0]; //������е�λ�ø�ֵ  ��������λ��
    //������С���������� �� Ѱ�ұ���������80��
    
    
    STOP_Line = White_Line_Max;
    
    
    y = IMG_H - 1;
    Right_Line[y] = 0;
    for(x = White_Line_MPos - 1; x < IMG_W - 3; x++)//
    {
        if((Black == IMG[y][x]) && (White == IMG[y][x - 1]))
        {
            Right_Line[y] = x;
            break;
        }
    }
    if(Right_Line[y] == 0)
    {
        Right_Line[y] = IMG_W - 1;
    }
    
    Left_Line[y] = 0;
    for(x = White_Line_MPos + 1; x > 1; x--)//
    {
        if((Black == IMG[y][x]) && (White == IMG[y][x + 1]))
        {
            Left_Line[y] = x;
            break;
        }
    }
    if(Left_Line[y] == 0)
    {
        Left_Line[y] = Right_Line[y] - WIDTH(y);
    }
    Middle_Line[y] = (int16)((Right_Line[y] + Left_Line[y]) / 2.0 + 0.5);
    for(y = IMG_H - 2; y > STOP_Line; y--)
    {   
        Right_Line[y] = 0;
        //���������
        L = Right_Line[y + 1] - 10;
        R = Right_Line[y + 1] + 10;
        if(L < 1)	//��ֹ����Խ��
            L = 1;
        if(R > IMG_H - 2)	//��ֹ����Խ��
            R > IMG_H - 2;
        for(x = L; x <= R; x++)
        {
            if((IMG[y][x] == Black) && (IMG[y][x - 1] == White))
            {
                Right_Line[y] = x;
                break;
            }
        }
        
        if(Right_Line[y] == 0) //���Ҷ�û���ҵ�
        {
            Right_Line[y] = IMG_W;  
        }  
        
    }
    for(y = IMG_H - 1; y > STOP_Line; y--)
    {   
        Left_Line[y] = 0; 
        
        //�����ұ���
        R = Right_Line[y] - WIDTH_HALF(y);
        L = 0;
        if(R < 1)	//��ֹ����Խ��
            R = 1;
        if(R > 80)	//��ֹ����Խ��
            R = 80;
        for(x = R; x >= L; x--)
        {
            if((IMG[y][x] == Black) && (IMG[y][x + 1] == White))
            {
                Left_Line[y] = x;
                break;
            }
        }
        
        if(Left_Line[y] == 0) //���Ҷ�û���ҵ�
        {
            Left_Line[y] = Right_Line[y] -  WIDTH(y);//  
        }  
        
        if(Right_Line[y] - Left_Line[y] >  WIDTH(y))
        {
            Left_Line[y] = Right_Line[y] -  WIDTH(y);
        }
        Middle_Line[y] = (int16)((Left_Line[y] + Right_Line[y])/2.0);          
    }
    
    
    if(Annular_Out == 0)
    {
        if(distance_temp > 1800)
        {
            for(y = IMG_H - 4; y > STOP_Line + 3; y -= 3)
            {
                if((Right_Line[y] < Right_Line[y + 3]) && (Right_Line[y - 3] < Right_Line[y]))
                {
                    right_inflection_point = y;
                    break;
                }
            }
            
            if((right_inflection_point != 0) && (right_inflection_point > 60)&& (right_inflection_point < 100))
            {
                Annular_Out = 1;
                Annular_Out_Distance = Distance_All;
            }
        }
    }
    else
    {
        distance_temp = Distance_All - Annular_Out_Distance;
        
        if(distance_temp > 2000)
        {
            Annular = 0;
            Annular_Out = 0;
        }
    }
    if(STOP_Line < 50)
        STOP_Line = 50;
}
