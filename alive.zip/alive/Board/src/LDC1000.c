#include "common.h"
#include "MK60_port.h"
#include "MK60_gpio.h"
#include "LDC1000.H"
#include "MK60_spi.h"


#define uchar uint8 
#define NN  10

uint8 orgVal[12]={0},orgVal1[12]={0};

uint8 RPMAX =0x07; 
uint8 RPMIN =0x2f;  
uint8 FREQ  =0xA9;
uint8 LDCCONFIG=0x13;

uint8 RPMAX1 =0x08; 
uint8 RPMIN1 =0x2f;  
uint8 FREQ1  =0xA9;
uint8 LDCCONFIG1=0x13;


uint8 rpi_max=40,rpi_max1=40;
uint8 proximtyData[2]={0},proximtyData1[2]={0};
unsigned long proximtyDataTEMP=0,proximtyDataMAX,proximtyDataMIN,proximtyDataSUM,proximtyDataAVE,proximtyDataAVE_LAS;
unsigned long proximtyDataTEMP1=0,proximtyDataMAX1,proximtyDataMIN1,proximtyDataSUM1,proximtyDataAVE1,proximtyDataAVE_LAS1;

int LDC_val=0,LDC_val1=0,LDC_val_pre=0,LDC_val1_pre=0;

uint8 s1=0,s2=0,s3=0,s4=0,s5=0,s6=0,s7=0,s8=0,s9=0,s10=0,s11=0,s12=0;

unsigned long value_buf[NN],new_value_buf[NN];
unsigned long value_buf1[NN],new_value_buf1[NN];


void ysz_delay(unsigned int ms)//Ϊ��ֹtime_delay_ms();��lpt��ͻ��д����ʱ
{
    unsigned int j1,k_1;int i1;
    i1=ms;
    for(j1=0;j1<i1;j1++)   
        for(k_1=0;k_1<14120;k_1++);
}

void ysz_delay_us(int ms)//Ϊ��ֹtime_delay_ms();��lpt��ͻ��д����ʱ
{
    int j1,k_1;int i1;
    i1=ms;
    for(j1=0;j1<i1;j1++)   
        for(k_1=0;k_1<8;k_1++);
}

void ysz_delay_ms(uint16 ms)//Ϊ��ֹtime_delay_ms();��lpt��ͻ��д����ʱ
{
    uint16 j1,k_1;uint32 i1;
    i1=ms;
    for(j1=0;j1<i1;j1++)   
        for(k_1=0;k_1<14120;k_1++);
}
/*!
 *  @brief      ��ʼ��LDC��촫����ģ��
 *  @param      LDCn    ģ��ţ�FTM0��  FTM1��  FTM2��
 *  @param      freq    Ƶ�ʣ���λΪHz��
 *  @param      duty    ռ�ձȷ��ӣ�ռ�ձ� = duty / FTMn_PRECISON
 *  @since      v5.0
 *  @note       ͬһ��FTM��PWMƵ���Ǳ���һ���ģ���ռ�ձȿɲ�һ������3��FTM�����������3����ͬƵ��PWM
 *  Sample usage:       FTM_PWM_init(FTM0, FTM_CH6,200, 10);    //��ʼ�� FTM0_CH6 Ϊ Ƶ�� 200Hz ��PWM��ռ�ձ�Ϊ 10/FTM0_PRECISON
 */

void LDC_init(LDCn ldcn)
{
  switch(ldcn)                        // ��ֵ CNTIN ��Ϊ0 ��������ȣ�CnV - CNTIN ���� CnV ���� ��������ˡ�
    {
        // EPWM������ �� MOD - CNTIN + 0x0001 == MOD - 0 + 1
        // �� CnV = (MOD - 0 + 1) * ռ�ձ� = (MOD - 0 + 1) * duty/ FTM_PRECISON
    case LDC0:
        
         while(orgVal[1]!=RPMAX||orgVal[2]!=RPMIN||orgVal[3]!=FREQ||orgVal[4]!=LDCCONFIG)
         { 
         ysz_SPI_init(LDC_SPI0);
         ysz_delay_ms(1000);
         ysz_Singal_SPI_Write(LDC1000_CMD_RPMAX, RPMAX);
         ysz_Singal_SPI_Write(LDC1000_CMD_RPMIN, RPMIN);//0x14
         ysz_Singal_SPI_Write(LDC1000_CMD_SENSORFREQ,  FREQ);  //г��Ƶ�ʼ��㷽����������Ƽ���촫���������ֲᡷ
         ysz_Singal_SPI_Write(LDC1000_CMD_LDCCONFIG,   LDCCONFIG);  //0x1B
         ysz_Singal_SPI_Write(LDC1000_CMD_CLKCONFIG,   0x00);  //0x01        
         ysz_Singal_SPI_Write(LDC1000_CMD_THRESHILSB,  0x50);
	 ysz_Singal_SPI_Write(LDC1000_CMD_THRESHIMSB,  0x14);
	 ysz_Singal_SPI_Write(LDC1000_CMD_THRESLOLSB,  0xC0);
	 ysz_Singal_SPI_Write(LDC1000_CMD_THRESLOMSB,  0x12);
         ysz_Singal_SPI_Write(LDC1000_CMD_INTCONFIG,   0x02);
         ysz_Singal_SPI_Write(LDC1000_CMD_PWRCONFIG,   0x01);
         ysz_SPI_Read_Buf(LDC1000_CMD_REVID,&orgVal[0],12);//orgVal[]��Ӧ����д���ֵ˵����ʼ������
         }
        break;

    case LDC1:
       while(orgVal1[1]!=RPMAX1||orgVal1[2]!=RPMIN1||orgVal1[3]!=FREQ1||orgVal1[4]!=LDCCONFIG1)
         { 
         ysz_SPI_init(LDC_SPI1);  
         ysz_delay_ms(1000);
         ysz_Singal_SPI_Write1(LDC1000_CMD_RPMAX, RPMAX1);
         ysz_Singal_SPI_Write1(LDC1000_CMD_RPMIN, RPMIN1);//0x14
         ysz_Singal_SPI_Write1(LDC1000_CMD_SENSORFREQ,  FREQ1);  //г��Ƶ�ʼ��㷽����������Ƽ���촫���������ֲᡷ
         ysz_Singal_SPI_Write1(LDC1000_CMD_LDCCONFIG,   LDCCONFIG1);  //0x1B
         ysz_Singal_SPI_Write1(LDC1000_CMD_CLKCONFIG,   0x00);  //0x01        
         ysz_Singal_SPI_Write1(LDC1000_CMD_THRESHILSB,  0x50);
	 ysz_Singal_SPI_Write1(LDC1000_CMD_THRESHIMSB,  0x14);
	 ysz_Singal_SPI_Write1(LDC1000_CMD_THRESLOLSB,  0xC0);
	 ysz_Singal_SPI_Write1(LDC1000_CMD_THRESLOMSB,  0x12);
         ysz_Singal_SPI_Write1(LDC1000_CMD_INTCONFIG,   0x02);
         ysz_Singal_SPI_Write1(LDC1000_CMD_PWRCONFIG,   0x01);
         ysz_SPI_Read_Buf1(LDC1000_CMD_REVID,&orgVal1[0],12);//orgVal[]��Ӧ����д���ֵ˵����ʼ������
         }
        break;

    case LDC2:
        
        break;

    default:
        break;
    }
  
  
  
        
                 
} 

int ldc_read_avr(LDC_SPIn ldc_spin)
{

    char rpi=0;  //ȡrpi��ƽ��ֵ    
    for (rpi=0;rpi<rpi_max;rpi++)
    {

      ysz_SPI_Read_Buf(LDC1000_CMD_PROXLSB,&proximtyData[0],2);  
      proximtyDataTEMP = ((unsigned char)proximtyData[1]<<8) + proximtyData [0]; 
      proximtyDataSUM += proximtyDataTEMP;
      if (proximtyDataTEMP < proximtyDataMIN)   //��100��proximtyDataTEMP��ȡ�����С
        proximtyDataMIN = proximtyDataTEMP;
      if (proximtyDataTEMP > proximtyDataMAX)
        proximtyDataMAX = proximtyDataTEMP;
    }
     proximtyDataAVE = proximtyDataSUM /rpi_max;
     proximtyDataSUM=0;
     proximtyDataAVE_LAS=proximtyDataAVE;
  
    return   proximtyDataAVE; 

}
long int filter(LDC_SPIn ldc_spin)
{
   char count,i,j,count1;
   char count2=0;
 
   long int temp;
   long int sum=0;
   for(count=0;count<NN;count++)
   {
      value_buf[count] = ldc_read_avr(ldc_spin);
   }
   
   for(count1=0;count1<NN;count1++)
   {  
   if(value_buf[count1]<28000)
   {
   new_value_buf[count2]=value_buf[count1];
   count2++;
   }  
   }
   
   
   for (j=0;j<count2-1;j++)
   {
      for (i=0;i<count2-j;i++)
      {
        if ( new_value_buf[i]>new_value_buf[i+1] )
         {
            temp = new_value_buf[i];
            new_value_buf[i] = new_value_buf[i+1];
            new_value_buf[i+1] = temp;
         }
      }
   }

   for(count=1;count<count2-1;count++)
   {
      sum += new_value_buf[count];
   }
  
     
   return (long int)(sum/(count2-2));


}
int ldc_read_avr1(LDC_SPIn ldc_spin)
{

    char rpi1=0;  //ȡrpi��ƽ��ֵ    
    for (rpi1=0;rpi1<rpi_max1;rpi1++)
    {

      ysz_SPI_Read_Buf1(LDC1000_CMD_PROXLSB,&proximtyData1[0],2);  
      proximtyDataTEMP1 = ((unsigned char)proximtyData1[1]<<8) + proximtyData1[0]; 
      proximtyDataSUM1 += proximtyDataTEMP1;
      if (proximtyDataTEMP1 < proximtyDataMIN1)   //��100��proximtyDataTEMP��ȡ�����С
        proximtyDataMIN1 = proximtyDataTEMP1;
      if (proximtyDataTEMP1 > proximtyDataMAX1)
        proximtyDataMAX1 = proximtyDataTEMP1;
    }
     proximtyDataAVE1 = proximtyDataSUM1 /rpi_max1;
     proximtyDataSUM1=0;
     proximtyDataAVE_LAS1=proximtyDataAVE1;
  
    return   proximtyDataAVE1; 

}
long int filter1(LDC_SPIn ldc_spin)
{
   char count1,i1,j1,count11;
   char count21=0;
 
   long int temp1;
   long int sum1=0;
   for(count1=0;count1<NN;count1++)
   {
      value_buf1[count1] = ldc_read_avr1(ldc_spin);
   }
   
   for(count11=0;count11<NN;count11++)
   {  
   if(value_buf1[count11]<28000)
   {
   new_value_buf1[count21]=value_buf1[count11];
   count21++;
   }  
   }
   
   
   for (j1=0;j1<count21-1;j1++)
   {
      for (i1=0;i1<count21-j1;i1++)
      {
        if ( new_value_buf1[i1]>new_value_buf1[i1+1] )
         {
            temp1 = new_value_buf1[i1];
            new_value_buf1[i1] = new_value_buf1[i1+1];
            new_value_buf1[i1+1] = temp1;
         }
      }
   }

   for(count1=1;count1<count21-1;count1++)
   {
      sum1 += new_value_buf1[count1];
   }
  
     
   return (long int)(sum1/(count21-2));


}



void ysz_SPI_init(LDC_SPIn ldc_spin)
{  
  switch(ldc_spin)                      
    {
        
      
    case LDC_SPI0:
        
         gpio_init (PTD0, GPI,1);//MISO
         gpio_init (PTD1 ,GPO,1);//MOSI
         gpio_init (PTD2, GPO,1);// CSN
         gpio_init (PTD3, GPO,0);//SCK
         
         CSN_H;
         SCK_L;
         MOSI_H;
        
        break;

    case LDC_SPI1:
         gpio_init (PTD8, GPI,1);//MISO1
         gpio_init (PTD9 ,GPO,1);//MOSI1
         gpio_init (PTD5, GPO,1);// CSN1
         gpio_init (PTD7, GPO,0);//SCK1
         
         CSN_H1;
         SCK_L1;
         MOSI_H1;
        break;

    case LDC_SPI2:
        
        break;

    default:
        break;
    }
  
  
  
  
}
/****************************************************************************************************
* Function Name: uchar ysz_SPI_RW(uchar wdata)
* Description  : read and write of SPI.
* Arguments    : wdata
* Return Value : rdata
***************************************************************************************************/
uchar ysz_SPI_RW(uchar rwdata)
{  
    
	uchar spi_rw_i=0;	
        uchar temp=0;

        for(spi_rw_i=0;spi_rw_i<8;spi_rw_i++)   	// output 8-bit
   	{
   	        /*** prepare the write data of read before the coming of rising up******/
	          if(rwdata & 0x80)
                    MOSI_H;
   		  else 
                    MOSI_L;
   		  rwdata<<=1;           		// shift next bit to MSB
                  temp<<=1;
		SCK_H;             //Set SCK high    Rising up 
               
   		if(MISO) 
                  temp|=1;
   		SCK_L;            //set  SCK low     Falling down
                
   	}
    return(temp);           		  		// return read byte
    
 
}
/****************************************************************************************************
* Function Name: uchar ysz_Singal_SPI(uchar reg,uchar wdata)
* Description  : registers read and write of device.
* Arguments    : commond,wdata
* Return Value : rdata
***************************************************************************************************/
uchar ysz_Singal_SPI_Read(uchar reg)
{
	uchar rdata;
	
	CSN_L;                // CSN low, initialize SPI communication...
       
        ysz_delay_us(2);
         
         reg=reg|0x80;//read
	ysz_SPI_RW(reg);            // Select register to read from..
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         
	rdata = ysz_SPI_RW(0);    // ..then read registervalue
       
        ysz_delay_us(1700);
	CSN_H;                // CSN high, terminate SPI communication
	
	return rdata;        // return register value
}
/****************************************************************************************************
* Function Name: void ysz_Singal_SPI_Write(uchar reg,uchar wdata)
* Description  : registers read and write of device.
* Arguments    : commond,wdata
* Return Value : rdata
****************************************************************************************************/
void ysz_Singal_SPI_Write(uchar reg,uchar wdata)
{
	//CE=0;
	CSN_L;                // CSN low, initialize SPI communication...
      
        ysz_delay_us(2);//2us
        reg=reg&~0x80;
	ysz_SPI_RW(reg);            // Select register to read from..
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
       
	ysz_SPI_RW(wdata);    // ..then read registervalue
        ysz_delay_us(1700);//875us
	CSN_H;              // CSN high, terminate SPI communication
        
	
}

/****************************************************************************************************
*o����y��ouint SPI_Read_Buf(uchar reg, uchar *pBuf, uchar uchars)
*1|?��: ��?����?����y?Y��?reg��o?a??��??�¦�??����?pBuf��o?a��y?��3?��y?Y��??����?uchars��o?��3?��y?Y��???��y
****************************************************************************************************/
void ysz_SPI_Read_Buf(uchar reg, uchar *pBuf, uchar len)
{
	uchar spi_rw_i;
	//CE=0;
	CSN_L;                   		// Set CSN low, init SPI tranaction
      
        reg=reg|0x80;//read
	ysz_SPI_RW(reg);       		// Select register to write to and read status uchar
	
	for(spi_rw_i=0;spi_rw_i<len;spi_rw_i++)
        {  
	pBuf[spi_rw_i] = ysz_SPI_RW(NULL);    // 
	 }
	CSN_H;     
      

}








/****************************************************************************************************
* Function Name: uchar ysz_SPI_RW(uchar wdata)
* Description  : read and write of SPI.
* Arguments    : wdata
* Return Value : rdata
****************************************************************************************************/
uchar ysz_SPI_RW1(uchar rwdata)
{  
    
	uchar spi_rw_i=0;
        uchar temp=0;

         for(spi_rw_i=0;spi_rw_i<8;spi_rw_i++)   	// output 8-bit
   	{
   	        /*** prepare the write data of read before the coming of rising up******/
	          if(rwdata & 0x80)
                    MOSI_H1;
   		  else 
                    MOSI_L1;
   		  rwdata<<=1;           		// shift next bit to MSB
                  temp<<=1;
		SCK_L1;             //Set SCK high    Rising up 
               
   		if(MISO1) 
                  temp|=1;
   		SCK_H1;            //set  SCK low     Falling down
                
   	}

    return(temp);           		  		// return read byte
    
 
}
/****************************************************************************************************
* Function Name: uchar ysz_Singal_SPI(uchar reg,uchar wdata)
* Description  : registers read and write of device.
* Arguments    : commond,wdata
* Return Value : rdata
****************************************************************************************************/
uchar ysz_Singal_SPI_Read1(uchar reg)
{
	uchar rdata;
	
	
        CSN_L1;
        ysz_delay_us(2);
         
         reg=reg|0x80;//read
	ysz_SPI_RW1(reg);            // Select register to read from..
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         
	rdata = ysz_SPI_RW1(0);    // ..then read registervalue
       
        ysz_delay_us(1700);
	
	CSN_H1;
	return rdata;        // return register value
}
/****************************************************************************************************
* Function Name: void ysz_Singal_SPI_Write(uchar reg,uchar wdata)
* Description  : registers read and write of device.
* Arguments    : commond,wdata
* Return Value : rdata
****************************************************************************************************/
void ysz_Singal_SPI_Write1(uchar reg,uchar wdata)
{
	
	
        CSN_L1;
        ysz_delay_us(2);//2us
        reg=reg&~0x80;
	ysz_SPI_RW1(reg);            // Select register to read from..
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         asm("nop");
         //500ns
	ysz_SPI_RW1(wdata);    // ..then read registervalue
        ysz_delay_us(1700);//875us
	
        CSN_H1;
	
}

/****************************************************************************************************
*o����y��ouint SPI_Read_Buf(uchar reg, uchar *pBuf, uchar uchars)
*1|?��: ��?����?����y?Y��?reg��o?a??��??�¦�??����?pBuf��o?a��y?��3?��y?Y��??����?uchars��o?��3?��y?Y��???��y
****************************************************************************************************/
void ysz_SPI_Read_Buf1(uchar reg, uchar *pBuf, uchar len)
{
	uchar spi_rw_i;
	//CE=0;
	
        CSN_L1;
        reg=reg|0x80;//read
	ysz_SPI_RW1(reg);       		// Select register to write to and read status uchar
	
	for(spi_rw_i=0;spi_rw_i<len;spi_rw_i++)
        {  
	pBuf[spi_rw_i] = ysz_SPI_RW1(NULL);    // 
	 }
	
        CSN_H1; 

}





