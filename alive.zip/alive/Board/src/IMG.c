/*!
-----------------------------------------------------
图像处理部分

OV7725  
140°广角镜  
160*120分辨率  
摄像头高度  30cm
直立时前瞻最近处 距车  5cm

by Chen.W.B
-----------------------------------------------------
*/

#include "common.h"
#include "include.h"

#include "IMG.h"

//宏定义赛道宽度  变化率
# define WIDTH(y) (1 * (y)  - 10)
# define WIDTH_HALF(y) (0.5 * (y) - 6)
# define WIDTH_Annular(y) (0.7 * (y) - 6)

int16 Right_Line[IMG_H] = {0};
int16 Left_Line[IMG_H] = {160};
int16 Middle_Line[IMG_H] = {60};
uint16 White_Line_Max = 0;  //最大列的值
uint16 White_Line_MPos = 80;	//最大列的位置
uint8 IMG[IMG_H][IMG_W];

int8 width_50 = 0;
int8 width_100 = 0;

uint8 Annular_Num = 0;
uint8 Annular_Find_Num = 0;
uint8 Annular_Direction[10] = {0, 1, 1, 1, 1, 1, 1, 1, 1, 1};

uint8 Start_Line = IMG_H - 10;

uint32 Annular_Time = 0;
uint32 Annular_Distance = 0;

uint8 Side_Run_Mode = 0;

uint32 Annular_Out_Distance = 0;

uint8 Curve = 0;

uint8 Right_Obstacle = 0;
uint8 Left_Obstacle = 0;

uint8 Annular = 0;  //环形进标志
uint8 Annular_Out = 0;  //环形出标志

uint16 STOP_Line = 0;

uint8 Lost_Line = 0;
uint8 Obstacle = 0;
/*!  图像说明
第一行
第二行
******************************
------------------------------
最大白列是最重要的，找出了最大白列，就基本找出了边线。，，最大化利用最大白列。。。
------------------------------
******************************

*/


/*!
-----------------------------------------------------
*  @brief      图像处理
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void IMG_Handle(void)
{
    Curve = 0;
    Lost_Line = 0;
    int16 y;
    //图像解压 解压后图像大小 160*120
    img_extract((uint8*)(IMG[0]), imgbuff, CAMERA_SIZE);
    
    
    Start_Line = IMG_H - 10;
    if(Annular == 1)
    {
        Start_Line = IMG_H - 20;
        Annular_Handle();
        PTE6_OUT = 0;
        Find_StopLine();
    }
    else
    {
        Find_StopLine();
        
        Find_END_Line();
//        
        PTE6_OUT = 1;
        
        //开机5000距离以内屏蔽 环  防止起跑线。障碍干扰
        if(Distance_All > 5000)
            Annular_Find();     //环形弯道查找
        
        if(Annular == 0)
        {
            IMG_Find_Lines();
            
            if(Lost_Line == 1)
            {
                Find_Lines_Oppose();//反向查找
            }
            else
            {
                
                if(STOP_Line < 45)
                {
                   Find_Obstacle();//寻找障碍
                    
                    if(Right_Obstacle == 1 || Left_Obstacle == 1)
                    {
                        Obstacle_Handle();
                        PTE7_OUT = 0;
                        Obstacle = 1;
                    }
                    else
                    {
                        PTE7_OUT = 1;
                    }
                }
            }
            //Find_StopLine();
            if(STOP_Line > 50)
            {
                Curve = 1;
            }
            
        }
    }
    //开机贴边跑，躲障碍
    if(Distance_All < 4000 && (Side_Run_Mode != 0))
    {
        Side_Run();
    }
    //中线汇总，求偏差
    Middle_Line_Find();
    for(y = IMG_H - 1; y > STOP_Line; y--)
    {
      IMG[y][Middle_Line[y]] = Black;
    }
    //宽度为计算赛道宽度变化
    width_50 = Right_Line[50] - Left_Line[50];
    width_100 = Right_Line[99] - Left_Line[99];
    
} 


/*!
-----------------------------------------------------
*  @brief      解压缩
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void img_extract(uint8 *dst, uint8 *src, uint32 srclen)
{
    uint8 colour[2] = {White, Black}; //0 和 1 分别对应的颜色
    //注：山外的摄像头 0 表示 白色，1表示 黑色
    uint8 tmpsrc;
    while(srclen --)
    {
        tmpsrc = *src++;
        *dst++ = colour[ (tmpsrc >> 7 ) & 0x01 ];
        *dst++ = colour[ (tmpsrc >> 6 ) & 0x01 ];
        *dst++ = colour[ (tmpsrc >> 5 ) & 0x01 ];
        *dst++ = colour[ (tmpsrc >> 4 ) & 0x01 ];
        *dst++ = colour[ (tmpsrc >> 3 ) & 0x01 ];
        *dst++ = colour[ (tmpsrc >> 2 ) & 0x01 ];
        *dst++ = colour[ (tmpsrc >> 1 ) & 0x01 ];
        *dst++ = colour[ (tmpsrc >> 0 ) & 0x01 ];
    }
}
/*!
-----------------------------------------------------
*  @brief      寻找截止行、最大白列
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Find_END_Line(void)
{
    int16 x, y, i, j = 0,temp;
    White_Line_Max = 0;  //最大列的值
    White_Line_MPos = 80;	//最大列的位置
    uint16 White_Line[10] = {0}; //只以中间为准找中间40列中的10列
    uint16 White_Line_Pos[10] = {0};//记录白列的位置 即横坐标
    for(x = 40; x < IMG_W - 40; x += 8, j++)
    {
        White_Line_Pos[j] = x;
        for(y = IMG_H - 1; y > 0; y--)
        {
            White_Line[j] = y; //记录纵坐标  y值越小说明  白列越长
            if(IMG[y][x] == Black)
            {
                break;
            }
        }
    }
    
    /********************  将白列进行排序   *************************************/
    //可优化变量定义为结构体类型
    uint16 White_Line_Sec = 0;      //第二大
    uint16 White_Line_SPos = 0;
    //结果为  数组第一个为最长白列
    for(i = 0; i < 10; i++)
    {
        for(j = i + 1; j < 10; j++)
        {
            if(White_Line[i] > White_Line[j])
            {
                temp = White_Line[j];
                White_Line[j] = White_Line[i];
                White_Line[i] = temp;
                
                temp = White_Line_Pos[j];
                White_Line_Pos[j] = White_Line_Pos[i];
                White_Line_Pos[i] = temp;
            }
        }
    }
    
    White_Line_Max = White_Line[0]; //将最大列的值（即行数赋值）
    White_Line_MPos = White_Line_Pos[0]; //将最大列的位置赋值  即横坐标位置
    White_Line_Sec = White_Line[1]; //将最大列的值（即行数赋值）
    White_Line_SPos = White_Line_Pos[1]; //将最大列的位置赋值  即横坐标位置
    
    //把靠近中间40的白列当做最大白列
    if((White_Line_Sec - White_Line_Max < 4) && \
        ((ABS(White_Line_MPos - 80) > ABS(White_Line_SPos - 80))))
    {
        White_Line_Max = White_Line_Sec; //将最大列的值（即行数赋值）
        White_Line_MPos = White_Line_SPos; //将最大列的位置赋值  即横坐标位置
    }
    
    //限制最小遍历的行数 即 寻找边线至少找80行
    STOP_Line = White_Line_Max;
    
    
}

/*!
-----------------------------------------------------
*  @brief      图像处理 ->寻找边线 并计算出中线
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void IMG_Find_Lines(void)
{
    /**************************        定 义 变 量   **********************************/

    
    int16 x, y, i, j, temp;
    int16 L = 0, R = 0;  //定义边线查找范围

    
    /************************ 先查找 前两行 *******************************/
    for(y = IMG_H - 1; y > IMG_H - 3; y--)
    {
        Left_Line[y] = IMG_W;
        Right_Line[y] = 0;
        //先找左边线
        for(x = White_Line_MPos; x > 0; x--)        //  -3 
        {
            if((Black == IMG[y][x]) && (White == IMG[y][x + 1]))
            {
                Left_Line[y] = x;
                break;
            }
        }
        //再找右边线
        for(x = White_Line_MPos; x < IMG_W; x++)// 
        {
            if((Black == IMG[y][x]) && (White == IMG[y][x - 1]))
            {
                Right_Line[y] = x;
                break;
            }
        }
        // 以下为 前五行左右边界没有找到处理
        if((Left_Line[y] == IMG_W) && (Right_Line[y] == 0))     //两边都没找到
        {
            Lost_Line = 1;   //两边都没有找到，进行从上往下查找
            return;     
        }
        else if((Left_Line[y] == IMG_W) && (Right_Line[y] != 0))//左边没有找到
        {
            Left_Line[y] = (int16)(Right_Line[y] - WIDTH(y) + 0.5);//（10 + 0.6 * y）为赛道宽度随行数变化而变化
        }
        else if((Right_Line[y] == 0) && (Left_Line[y] != IMG_W))
        {
            Right_Line[y] = (int16)(Left_Line[y] + WIDTH(y) + 0.5);//(80 - )
        } 
        
        Middle_Line[y] = (int16)((Left_Line[y] + Right_Line[y])/2.0 + 0.5);
    }
    /************************ 后面的边线（第2行到截止行） *******************************/
    //搜索 第5行到白线截止行
    for(y = IMG_H - 3; y > STOP_Line; y--)
    {   
        Left_Line[y] = IMG_W;
        Right_Line[y] = 0; 
        
        //查找左边线
        L = Left_Line[y + 1] - 5;
        R = Left_Line[y + 1] + 5;
        if(L < 1)	//防止数组越界
            L = 1;
        if(R < 1)	//防止数组越界
            R = 1;
        for(x = R; x >= L; x--)
        {
            if((IMG[y][x] == Black) && (IMG[y][x + 1] == White) && (IMG[y][x + 2] == White))
            {
                Left_Line[y] = x;
                break;
            }
        }
        //查找右边线
        L = Right_Line[y + 1] - 5;
        R = Right_Line[y + 1] + 5;
        if(R > IMG_W - 1)	//防止右边数组越界
            R = IMG_W - 1; 
        if(L > IMG_W - 1)	//防止右边数组越界
            L = IMG_W - 1; 
        
        for(x = L; x <= R; x++)
        {
            if((IMG[y][x] == Black) && (IMG[y][x - 1] == White) && (IMG[y][x - 2] == White))
            {
                Right_Line[y] = x;
                break;
            }
        }
        
        if((Right_Line[y] == 0) && (Left_Line[y] == IMG_W))//左右都没有找到
        {
            Left_Line[y] = (int16)(White_Line_MPos  - WIDTH_HALF(y) + 0.5); 
            Right_Line[y] = (int16)(White_Line_MPos  + WIDTH_HALF(y) + 0.5);  
        }
        else if((Right_Line[y] != 0) && (Left_Line[y] == IMG_W))//左侧没有找到
        {
            if(Right_Line[y] > Right_Line[y + 1])
            {
                //                Left_Line[y] = (int16)(((White_Line_MPos + Middle_Line[y + 1]) / 2)- WIDTH_HALF(y));       //40 理想中线值 35为第一行赛道宽度的一半 (100 - y)为随行数的变化的偏差
                //                Right_Line[y] = (int16)(((White_Line_MPos + Middle_Line[y + 1]) / 2)+ WIDTH_HALF(y));      //
                Left_Line[y] = (int16)((Middle_Line[y + 1])- WIDTH_HALF(y) + 0.5);       //40 理想中线值 35为第一行赛道宽度的一半 (100 - y)为随行数的变化的偏差
                Right_Line[y] = (int16)((Middle_Line[y + 1])+ WIDTH_HALF(y) + 0.5);      //
                
            }
            else if((Right_Line[y] < Right_Line[y + 2])) //近距离弯道（向左拐），左侧只有一点点黑
            {
                Left_Line[y] = (int16)(2*Left_Line[y+1] - Left_Line[y+2]);
                if(Left_Line[y] >= Left_Line[y + 1])
                {
                    Left_Line[y] = Left_Line[y + 1] - 1;
                }
            }
            else if(Left_Line[y + 1] <= 1) // 如果上一行 没有找到左线  左边线在图像外  左侧
            {
                Left_Line[y] = (int16)(Right_Line[y] - WIDTH(y));//(80 - )
            }
            else        //普通情况
            {
                Left_Line[y] = (int16)(Right_Line[y] - WIDTH(y));
            }
        }
        else if((Right_Line[y] == 0) && (Left_Line[y] != IMG_W))//右侧没有找到
        {
            
            if(Left_Line[y] < Left_Line[y + 1])
            {
                //                Left_Line[y] = (int16)(((White_Line_MPos + Middle_Line[y + 1]) / 2)- WIDTH_HALF(y));       //40 理想中线值 35为第一行赛道宽度的一半 (100 - y)为随行数的变化的偏差
                //                Right_Line[y] = (int16)(((White_Line_MPos + Middle_Line[y + 1]) / 2)+ WIDTH_HALF(y) + 0.5);      //
                //            
                Left_Line[y] = (int16)((Middle_Line[y + 1])- WIDTH_HALF(y) + 0.5);       //40 理想中线值 35为第一行赛道宽度的一半 (100 - y)为随行数的变化的偏差
                Right_Line[y] = (int16)((Middle_Line[y + 1])+ WIDTH_HALF(y) + 0.5);      //
                
            }
            else if( (Left_Line[y] > Left_Line[y + 2]))//右拐弯道，右侧只有一点点黑
            {
                Right_Line[y] = (int16)(2 * Right_Line[y+1] - Right_Line[y+2] );//(80 - )
                if(Right_Line[y] <= Right_Line[y + 1])
                {
                    Right_Line[y] = Right_Line[y + 1] + 1;
                }
            }
            else if(Right_Line[y + 1] >= (IMG_W - 1))//如果上一行没有找到右线
            {
                Right_Line[y] = (int16)(Left_Line[y] + WIDTH(y) + 0.5);//(80 - )
            }
            else
            {
                Right_Line[y] = (int16)(Left_Line[y] + WIDTH(y) + 0.5);//(80 - )
            }
        }
        Middle_Line[y] = (int16)((Left_Line[y] + Right_Line[y])/2.0 + 0.5);
    }
    /*****************************  中线平滑、防错处理  ***********************/   
    for(y = IMG_H - 2; y > STOP_Line; y--)
    {   
        //中线防错处理
        if(IMG[y][Middle_Line[y]] == Black)
        {
            Middle_Line[y] = White_Line_MPos;
        }
    }
    
}
/*!
-----------------------------------------------------
*  @brief      环道查找
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Annular_Find(void)
{
    Annular_Find3();
}
/*!
-----------------------------------------------------
*  @brief      环道查找 ->方案3
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Annular_Find3(void)
{
    int16 leftline[IMG_H] = {0};
    int16 rightline[IMG_H] = {0};
    
    int16 left_inflection_point = 0;
    int16 right_inflection_point = 0;
    
    int16 nearest_middle = 0;
    
    int16 far_middle = 0;
    
    int16 endline = 50;
    
    int16 x, y;
    
    int16 L, R;
    
    uint32 distance_temp = 0;
    distance_temp = Distance_All - Annular_Out_Distance;
    if(distance_temp < 1000)
        return;
    for(y = IMG_H - 1; y > IMG_H - 2; y--)
    {
        leftline[y] = IMG_W;
        rightline[y] = 0;
        //先找左边线
        for(x = White_Line_MPos; x > 0; x--)        //  -3 
        {
            if((Black == IMG[y][x]) && (White == IMG[y][x + 1]))
            {
                leftline[y] = x;
                break;
            }
        }
        //再找右边线
        for(x = White_Line_MPos; x < IMG_W; x++)// 
        {
            if((Black == IMG[y][x]) && (White == IMG[y][x - 1]))
            {
                rightline[y] = x;
                break;
            }
        }
        // 以下为 前五行左右边界没有找到处理
        if((leftline[y] == IMG_W) || (rightline[y] == 0))     //两边都没找到
        {
            return;     
        }
    }
    
    nearest_middle = (int16)((leftline[y] + rightline[y]) / 2.0);
    
    
    for(y = IMG_H - 2; y > STOP_Line; y--)
    {   
        leftline[y] = IMG_W;
        rightline[y] = 0; 
        
        //查找左边线
        L = leftline[y + 1] - 25;
        R = leftline[y + 1] + 10;
        if(L < 1)	//防止数组越界
            L = 1;
        if(R < 1)	//防止数组越界
            R = 1;
        for(x = R; x >= L; x--)
        {
            if((IMG[y][x] == Black) && (IMG[y][x + 1] == White) && (IMG[y][x + 2] == White))
            {
                leftline[y] = x;
                break;
            }
        }
        //查找右边线
        L = rightline[y + 1] - 10;
        R = rightline[y + 1] + 25;
        if(R > IMG_W - 1)	//防止右边数组越界
            R = IMG_W - 1; 
        if(L > IMG_W - 1)	//防止右边数组越界
            L = IMG_W - 1; 
        
        for(x = L; x <= R; x++)
        {
            if((IMG[y][x] == Black) && (IMG[y][x - 1] == White) && (IMG[y][x - 2] == White))
            {
                rightline[y] = x;
                break;
            }
        }
        
        if((leftline[y] == IMG_W) || (rightline[y] == 0))     //两边都没找到
        {
            endline = y;
            break;     
        }

    }
    if(endline > 100)
        return;
    for(y = IMG_H - 5; y > endline + 5; y -= 4)
    {
        if((leftline[y] > leftline[y + 4]) && (leftline[y - 4] < leftline[y]) && (leftline[y - 8] < leftline[y - 4]))
        {
            left_inflection_point = y;
            break;
        }
    }
    if(y <= endline + 5)
        return;
    for(y = IMG_H - 5; y > endline + 5; y -= 4)
    {
        if((rightline[y] < rightline[y + 4]) && (rightline[y - 4] > rightline[y])&& (rightline[y - 8] > rightline[y - 4]))
        {
            right_inflection_point = y;
            break;
        }
    }
    if(y <= endline + 5)
        return;
    
    if((right_inflection_point == 0) || (left_inflection_point == 0))
        return;
    
    //高低拐点
    uint8 low, high;
    low = 0;
    high = 0;
    if(right_inflection_point > left_inflection_point)
    {
        high = left_inflection_point;
        low = right_inflection_point;
    }
    else
    {
        high = right_inflection_point;
        low = left_inflection_point;
    }
    //低拐点一下变化一致
    for(y = IMG_H - 1; y > low + 10; y-=6)
    {
        if((leftline[y - 6] < leftline[y]) || (rightline[y - 6] > rightline[y]))
            return;
    }
    //高拐点变化一致。
        if((leftline[high - 6] > leftline[high]) || (rightline[high - 6] < rightline[high]))
            return;
    
    if(high - endline < 10)
        return;
    



    for(y = IMG_H - 1; y > STOP_Line + 1; y--)
    {
        if((IMG[y][nearest_middle] == White) && (IMG[y - 1][nearest_middle] == Black))
        {
            far_middle = y;
            break;
        }
    }
    if((far_middle == 0) || (far_middle < 30))
        return;
//    
//    if(ABS(far_middle - STOP_Line) < 10)
//        return;
//    
    if((right_inflection_point < 50) || (left_inflection_point < 50))
        return;
    
    int16 inflection_point_middle = (rightline[right_inflection_point] + leftline[left_inflection_point])/2;
    int16 M_num = 0;
    int16 L_num = 0;
    int16 R_num = 0;
    
    //中间黑列长度
    for(y = right_inflection_point; y > 10; y--)
    {
        M_num++;
        if((IMG[y][inflection_point_middle] == White) && (IMG[y - 1][inflection_point_middle] == Black))
            break;
    }
    if(M_num > 66 || (M_num < 10))
        return;

    //左边黑线长度
    x = leftline[left_inflection_point];
    for(y = left_inflection_point; y > 10; y--)
    {
        L_num++;
        if((IMG[y][x] == White) && (IMG[y - 1][x] == Black))
            break;
    }    
    //右边黑线长度
    x = rightline[right_inflection_point];
    for(y = right_inflection_point; y > 10; y--)
    {
        R_num++;
        if((IMG[y][x] == White) && (IMG[y - 1][x] == Black))
            break;
    }
        if(L_num > M_num && (R_num > M_num))
        { 
            Annular = 1;
            Annular_Time = ALL_TIME;
            Annular_Distance = Distance_All;
            
            Annular_Find_Num++;
        }
    

}
/*!
-----------------------------------------------------
*  @brief      环道查找 ->方案4
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Annular_Find4(void)
{
    int16 leftline[IMG_H] = {0};
    int16 rightline[IMG_H] = {0};
    
    int16 left_inflection_point = 0;
    int16 right_inflection_point = 0;
    
    int16 nearest_middle = 0;
    
    int16 far_middle = 0;
    
    int16 endline = 50;
    
    int16 x, y;
    
    int16 L, R;
    
    uint32 distance_temp = 0;
    distance_temp = Distance_All - Annular_Out_Distance;
    if(distance_temp < 1000)
        return;
    for(y = IMG_H - 1; y > IMG_H - 2; y--)
    {
        leftline[y] = IMG_W;
        rightline[y] = 0;
        //先找左边线
        for(x = White_Line_MPos; x > 0; x--)        //  -3 
        {
            if((Black == IMG[y][x]) && (White == IMG[y][x + 1]))
            {
                leftline[y] = x;
                break;
            }
        }
        //再找右边线
        for(x = White_Line_MPos; x < IMG_W; x++)// 
        {
            if((Black == IMG[y][x]) && (White == IMG[y][x - 1]))
            {
                rightline[y] = x;
                break;
            }
        }
        // 以下为 前五行左右边界没有找到处理
        if((leftline[y] == IMG_W) || (rightline[y] == 0))     //两边都没找到
        {
            return;     
        }
    }
    
    nearest_middle = (int16)((leftline[y] + rightline[y]) / 2.0);
    
    
    for(y = IMG_H - 2; y > STOP_Line; y--)
    {   
        leftline[y] = IMG_W;
        rightline[y] = 0; 
        
        //查找左边线
        L = leftline[y + 1] - 25;
        R = leftline[y + 1] + 10;
        if(L < 1)	//防止数组越界
            L = 1;
        if(R < 1)	//防止数组越界
            R = 1;
        for(x = R; x >= L; x--)
        {
            if((IMG[y][x] == Black) && (IMG[y][x + 1] == White) && (IMG[y][x + 2] == White))
            {
                leftline[y] = x;
                break;
            }
        }
        //查找右边线
        L = rightline[y + 1] - 10;
        R = rightline[y + 1] + 25;
        if(R > IMG_W - 1)	//防止右边数组越界
            R = IMG_W - 1; 
        if(L > IMG_W - 1)	//防止右边数组越界
            L = IMG_W - 1; 
        
        for(x = L; x <= R; x++)
        {
            if((IMG[y][x] == Black) && (IMG[y][x - 1] == White) && (IMG[y][x - 2] == White))
            {
                rightline[y] = x;
                break;
            }
        }
        
        if((leftline[y] == IMG_W) || (rightline[y] == 0))     //两边都没找到
        {
            endline = y;
            break;     
        }

    }
    if(endline > 100)
        return;
    for(y = IMG_H - 5; y > endline + 5; y -= 4)
    {
        if((leftline[y] > leftline[y + 4]) && (leftline[y - 4] < leftline[y]) && (leftline[y - 8] < leftline[y - 4]))
        {
            left_inflection_point = y;
            break;
        }
    }
    if(y <= endline + 5)
        return;
    for(y = IMG_H - 5; y > endline + 5; y -= 4)
    {
        if((rightline[y] < rightline[y + 4]) && (rightline[y - 4] > rightline[y])&& (rightline[y - 8] > rightline[y - 4]))
        {
            right_inflection_point = y;
            break;
        }
    }
    if(y <= endline + 5)
        return;
    
    if((right_inflection_point == 0) || (left_inflection_point == 0))
        return;
    
    //高低拐点
    uint8 low, high;
    low = 0;
    high = 0;
    if(right_inflection_point > left_inflection_point)
    {
        high = left_inflection_point;
        low = right_inflection_point;
    }
    else
    {
        high = right_inflection_point;
        low = left_inflection_point;
    }
    //低拐点一下变化一致
    for(y = IMG_H - 1; y > low + 10; y-=6)
    {
        if((leftline[y - 6] < leftline[y]) || (rightline[y - 6] > rightline[y]))
            return;
    }
    //高拐点变化一致。
        if((leftline[high - 6] > leftline[high]) || (rightline[high - 6] < rightline[high]))
            return;
    
    if(high - endline < 10)
        return;
    
    if((right_inflection_point < 50) || (left_inflection_point < 50))
        return;
    
    if(ABS(right_inflection_point - left_inflection_point) > 20)
        return;
    int16 inflection_point_middle = (rightline[right_inflection_point] + leftline[left_inflection_point])/2;
    int16 M_num = 0;
    int16 L_num = 0;
    int16 R_num = 0;
    
    //中间黑列长度
    for(y = right_inflection_point; y > 10; y--)
    {
        M_num++;
        if((IMG[y][inflection_point_middle] == White) && (IMG[y - 1][inflection_point_middle] == Black))
            break;
    }
    if(M_num > 66 || (M_num < 10))
        return;

    //左边黑线长度
    x = leftline[left_inflection_point];
    for(y = left_inflection_point; y > 10; y--)
    {
        L_num++;
        if((IMG[y][x] == White) && (IMG[y - 1][x] == Black))
            break;
    }    
    //右边黑线长度
    x = rightline[right_inflection_point];
    for(y = right_inflection_point; y > 10; y--)
    {
        L_num++;
        if((IMG[y][x] == White) && (IMG[y - 1][x] == Black))
            break;
    }
        if(L_num > M_num && (R_num > M_num))
        { 
            Annular = 1;
            Annular_Time = ALL_TIME;
            Annular_Distance = Distance_All;
            
            Annular_Find_Num++;
        }
    
    

}



/*!
-----------------------------------------------------
*  @brief      特殊处理 -> 反向查找边线 
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Find_Lines_Oppose(void)
{
    int16 x, y;
    int16 L = 0, R = 0;  //定义边线查找范围
    
    int temp1 = 0;
    int temp2 = 0;
    int temp3 = 0;
    //修改最大白列，降低一行
    STOP_Line = STOP_Line + 10;
    if(STOP_Line > IMG_H - 2)
    {
        Shut_Down = 1; 
        Error[0] = 1;
        return;
        
    }
    y = STOP_Line;
    Left_Line[y] = IMG_W;
    Right_Line[y] = 0; 
    //先找左边线
    for(x = White_Line_MPos + 1; x >= 0; x--)
    {
        if((Black == IMG[y][x]) && (White == IMG[y][x + 1]))
        {
            Left_Line[y] = x;
            break;
        }
    }
    //再找右边线
    for(x = White_Line_MPos - 1; x < IMG_W; x++)//
    {
        if((Black == IMG[y][x]) && (White == IMG[y][x - 1]))
        {
            Right_Line[y] = x;
            break;
        }
    }
    if((Right_Line[y] != 0) && (Left_Line[y] != IMG_W))
    {
        temp1 = White_Line_MPos -Left_Line[y] ;
        temp2 = Right_Line[y] - White_Line_MPos;
        
        temp3 = 1.2 * WIDTH(y);
        if((temp1 < temp3) && (temp2 > temp3))
            Right_Line[y] = (int16)(Left_Line[y] + WIDTH(y));//
        if((temp2 < temp3) && (temp1 > temp3))
            Left_Line[y] = (int16)(Right_Line[y] - WIDTH(y));//
    }
    if((Right_Line[y] == 0))
        Right_Line[y] = (int16)(Left_Line[y] + WIDTH(y));//
    if((Left_Line[y] == IMG_W))
        Left_Line[y] = (int16)(Right_Line[y] - WIDTH(y) + 0.5);//
    Middle_Line[y] = (int16)((Left_Line[y] + Right_Line[y])/2.0 + 0.5);  
    
    
    //从上向下，寻找边线
    for(y = STOP_Line + 1; y < IMG_H; y++)
    {   
        Left_Line[y] = IMG_W;
        Right_Line[y] = 0; 
        
        //查找左边线
        L = Left_Line[y - 1] - 5;
        R = Left_Line[y - 1] + 5;
        if(L < 0)	//防止数组越界
            L = 0;
        if(R < 0)	//防止数组越界
            R = 0;
        
        for(x = R; x >= L; x--)
        {
            if((IMG[y][x] == Black) && (IMG[y][x + 1] == White) && (IMG[y][x + 2] == White))
            {
                Left_Line[y] = x;
                break;
            }
        }
        
        //查找右边线
        L = Right_Line[y - 1] - 5;
        R = Right_Line[y - 1] + 5;
        if(R > IMG_W - 1)	//防止右边数组越界
            R = IMG_W - 1; 
        if(L > IMG_W - 1)	//防止右边数组越界
            L = IMG_W - 1; 
        
        for(x = L; x <=R; x++)
        {
            if((IMG[y][x] == Black) && (IMG[y][x - 1] == White) && (IMG[y][x - 2] == White))
            {
                Right_Line[y] = x;
                break;
            }
        }
        if((Right_Line[y] == 0) && (Left_Line[y] == IMG_W))//左右都没有找到
        {
            Left_Line[y] = (int16)(White_Line_MPos - WIDTH_HALF(y) + 0.5); 
            Right_Line[y] = (int16)(White_Line_MPos + WIDTH_HALF(y) + 0.5);  
        }
        else if((Right_Line[y] != 0) && (Left_Line[y] == IMG_W))//左侧没有找到
        {
            Left_Line[y] = (int16)(Right_Line[y - 1] - WIDTH(y - 1));
        }
        else if((Right_Line[y] == 0) && (Left_Line[y] != IMG_W))//右侧没有找到
        {
            Right_Line[y] = (int16)(Left_Line[y - 1] + WIDTH(y - 1) + 0.5);//(80 
        }
        Middle_Line[y] = (int16)((Left_Line[y] + Right_Line[y])/2.0 + 0.5);     
    }
    
    /*****************************  中线平滑、防错处理  ***********************/   
    for(y = IMG_H - 2; y > STOP_Line; y--)
    {   
        //中线防错处理
        if(IMG[y][Middle_Line[y]] == Black)
        {
            Middle_Line[y] = White_Line_MPos;
        }
    }
}

/*!
-----------------------------------------------------
*  @brief       寻找障碍
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Find_Obstacle(void)
{
    int  x, y;
    
    uint8 find_stop = 45;//障碍 最远查找行
    
    Right_Obstacle = 0;
    Left_Obstacle = 0;
    Obstacle = 0;
    
    uint8 left_line[IMG_H] = {160};
    uint8 right_line[IMG_H] ={0};
    uint8 middle_line[IMG_H];
    uint8 width[IMG_H];
    
    
    uint8 left_TiaoBian = 0;
    uint8 right_TiaoBian = 0;
    uint8 left_TiaoBian_y = 120;
    uint8 right_TiaoBian_y = 120;
    
    for(y = IMG_H - 1; y > find_stop; y -= 3)
    {
        left_line[y] = 160;
        right_line[y] = 0;
        for(x = White_Line_MPos; x > 3; x--)
        {
            
            if(IMG[y][x] == Black && (IMG[y][x + 1] == White) )
            {
                left_line[y] = x;
                break;
            }
        }
        for(x = White_Line_MPos; x < IMG_W - 4; x++)
        {
            
            if(IMG[y][x - 1] == White && (IMG[y][x] == Black) )
            {
                right_line[y] = x;
                break;
            }
        }
        
        if(right_line[y] == 0 || (left_line[y] == 160))
            return;
        middle_line[y] = (uint8)((right_line[y] + left_line[y]) / 2 + 0.5);
        width[y] = right_line[y] - left_line[y];
    }
    
    uint8 left_nei_tiaobian = 0;
    uint8 right_nei_tiaobian = 0;
    uint8 tiaobian_y = 0;
    
    for(y = IMG_H - 13; y > find_stop + 13; y -= 3)
    { 
        if((left_line[y] - left_line[y + 6] > 10)
           && (left_line[y - 6] - left_line[y] < 6)
               && (left_line[y - 12] - left_line[y - 6] < 6)
                   && (left_line[y + 6] - left_line[y + 12] < 6))
        {
            left_nei_tiaobian = 1;
            tiaobian_y = y;
            break;
        }
    }
    for(y = IMG_H - 10; y > find_stop + 10; y -= 3)
    { 
        if((right_line[y + 3] - right_line[y] > 10)
           && (right_line[y] - right_line[y - 3] < 6)
               && (right_line[y - 3] - right_line[y - 6] < 6)
                   && (right_line[y + 6] - right_line[y + 3] < 6))
        {
            right_nei_tiaobian = 1;
            tiaobian_y = y;
            break;
        }
    }
    if(right_nei_tiaobian + left_nei_tiaobian != 1)
    {
        return;
    }
    
    for(y = IMG_H - 4; y > tiaobian_y - 4; y -= 3)
    {
        if((left_line[y] < left_line[y + 3]) && (right_line[y] > right_line[y + 3]))
        {
            return;
        }
    }
    
    if(width[tiaobian_y] < 25)
        return;
    

       if(left_nei_tiaobian == 1)
        {
            Left_Obstacle = 1;
        }
        else if(right_nei_tiaobian == 1)
        {
            Right_Obstacle = 1;
        }
}
/*!
-----------------------------------------------------
*  @brief        障碍处理
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Obstacle_Handle(void)
{
    uint8 y = 0;
    
    if(Right_Obstacle == 1)
    {
        for(y = IMG_H - 1; y > STOP_Line; y--)
        {   
            Middle_Line[y] = (int16)(Left_Line[y] + WIDTH(y) * 0.18 + 0.5);  //
        }
    }
    else if(Left_Obstacle == 1)
    {
        for(y = IMG_H - 1; y > STOP_Line; y--)
        {   
            Middle_Line[y] = (int16)(Right_Line[y] - WIDTH(y) * 0.18 + 0.5);  //
        }
    }
}

/*!
-----------------------------------------------------
*  @brief       停车线 - 斑马线
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Find_StopLine(void)
{
    uint8 i; 
    uint8 left_line = 160;
    uint8 right_line = 0;
    uint8 middle = 80;
    int16 width = 0;
    
    if(Distance_All < 2000)
        return;
    
    for(i = 70; i < 90; i++)
    {
        if(IMG[90][i] == White)
        {
            middle = i;
            break;
        }
    }
    if(i == 90)
        return;
    
    for(i = middle; i > 60; i--)
    {
        if((IMG[90][i]) == Black)
        {
            left_line = i;
            break;
        }
    }
    for(i = middle; i < IMG_W - 60; i++)
    {
        if((IMG[90][i]) == Black)
        {
            right_line = i;
            break;
        }
    }
    width = (right_line - left_line);
    if(right_line > left_line)
    {
        if((width < 30) && (ALL_TIME > 40))
        {
            DianJi_STOP = 1;
        }
    }   
}
/*!
-----------------------------------------------------
*  @brief       环道 处理
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Annular_Handle(void)
{
   if(Annular_Direction[Annular_Find_Num] == 2)
        Annular_Handle_Right();
    else if(Annular_Direction[Annular_Find_Num] == 1)
        Annular_Handle_Left();
    else
        Annular_Handle_Left();
}
/*!
-----------------------------------------------------
*  @brief      环道处理 向右
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Annular_Handle_Right(void)
{
  /**************************        定 义 变 量   **********************************/
    White_Line_Max = 0;  //最大列的值
    White_Line_MPos = 120;	//最大列的位置
    
    uint32 time_temp = 0;
    uint32 distance_temp = 0;
    int16 x, y, i, j, temp;
    int16 L = 0, R = 0;  //定义边线查找范围
    
    int16 right_inflection_point = 0;
    
    
    time_temp = ALL_TIME - Annular_Time;
    distance_temp = Distance_All - Annular_Distance;
    
    /***************先查截止行  即纵向遍历  若下端为白，上端为黑则此线为黑线截止行*************/
    uint16 White_Line[10] = {0}; //只以中间为准找中间40列中的10列
    uint16 White_Line_Pos[10] = {0};//记录白列的位置 即横坐标
    j = 0;
    for(x = 60; x < 140; x += 8, j++)
    {
        White_Line_Pos[j] = x;
        for(y = IMG_H - 1; y > 0; y--)
        {
            White_Line[j] = y; //记录纵坐标  y值越小说明  白列越长
            if(IMG[y][x] == Black)
            {
                break;
            }
        }
    }
    
    /********************  将白列进行排序   *************************************/
    //结果为  数组第一个为最长白列
    for(i = 0; i < 10; i++)
    {
        for(j = i + 1; j < 10; j++)
        {
            if(White_Line[i] > White_Line[j])
            {
                temp = White_Line[j];
                White_Line[j] = White_Line[i];
                White_Line[i] = temp;
                
                temp = White_Line_Pos[j];
                White_Line_Pos[j] = White_Line_Pos[i];
                White_Line_Pos[i] = temp;
            }
        }
    }
    
    White_Line_Max = White_Line[0]; //将最大列的值（即行数赋值）
    White_Line_MPos = White_Line_Pos[0]; //将最大列的位置赋值  即横坐标位置
    //限制最小遍历的行数 即 寻找边线至少找80行
    
    
    STOP_Line = White_Line_Max;
    
    
    y = IMG_H - 1;
    Right_Line[y] = 0;
    for(x = White_Line_MPos - 1; x < IMG_W - 3; x++)//
    {
        if((Black == IMG[y][x]) && (White == IMG[y][x - 1]))
        {
            Right_Line[y] = x;
            break;
        }
    }
    if(Right_Line[y] == 0)
    {
        Right_Line[y] = IMG_W - 1;
    }
    
    Left_Line[y] = 0;
    for(x = White_Line_MPos + 1; x > 1; x--)//
    {
        if((Black == IMG[y][x]) && (White == IMG[y][x + 1]))
        {
            Left_Line[y] = x;
            break;
        }
    }
    if(Left_Line[y] == 0)
    {
        Left_Line[y] = Right_Line[y] - WIDTH(y);
    }
    Middle_Line[y] = (int16)((Right_Line[y] + Left_Line[y]) / 2.0 + 0.5);
    for(y = IMG_H - 2; y > STOP_Line; y--)
    {   
        Right_Line[y] = 0;
        //查找左边线
        L = Right_Line[y + 1] - 10;
        R = Right_Line[y + 1] + 10;
        if(L < 1)	//防止数组越界
            L = 1;
        if(R > IMG_H - 2)	//防止数组越界
            R > IMG_H - 2;
        for(x = L; x <= R; x++)
        {
            if((IMG[y][x] == Black) && (IMG[y][x - 1] == White))
            {
                Right_Line[y] = x;
                break;
            }
        }
        
        if(Right_Line[y] == 0) //左右都没有找到
        {
            Right_Line[y] = IMG_W;  
        }  
        
    }
    for(y = IMG_H - 1; y > STOP_Line; y--)
    {   
        Left_Line[y] = 0; 
        
        //查找右边线
        R = Right_Line[y] - WIDTH_HALF(y);
        L = 0;
        if(R < 1)	//防止数组越界
            R = 1;
        if(R > 80)	//防止数组越界
            R = 80;
        for(x = R; x >= L; x--)
        {
            if((IMG[y][x] == Black) && (IMG[y][x + 1] == White))
            {
                Left_Line[y] = x;
                break;
            }
        }
        
        if(Left_Line[y] == 0) //左右都没有找到
        {
            Left_Line[y] = Right_Line[y] -  WIDTH(y);//  
        }  
        
        if(Right_Line[y] - Left_Line[y] >  WIDTH(y))
        {
            Left_Line[y] = Right_Line[y] -  WIDTH(y);
        }
        Middle_Line[y] = (int16)((Left_Line[y] + Right_Line[y])/2.0);          
    }
    
    
    if(Annular_Out == 0)
    {
        if(distance_temp > 1800)
        {
            for(y = IMG_H - 4; y > STOP_Line + 3; y -= 3)
            {
                if((Right_Line[y] < Right_Line[y + 3]) && (Right_Line[y - 3] < Right_Line[y]))
                {
                    right_inflection_point = y;
                    break;
                }
            }
            
            if((right_inflection_point != 0) && (right_inflection_point > 60)&& (right_inflection_point < 100))
            {
                Annular_Out = 1;
                Annular_Out_Distance = Distance_All;
            }
        }
    }
    else
    {
        distance_temp = Distance_All - Annular_Out_Distance;
        
        if(distance_temp > 2000)
        {
            Annular = 0;
            Annular_Out = 0;
        }
    }
    if(STOP_Line < 50)
        STOP_Line = 50;
}
/*!
-----------------------------------------------------
*  @brief      环道处理 向左
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Annular_Handle_Left(void)
{
    /**************************        定 义 变 量   **********************************/
    White_Line_Max = 0;  //最大列的值
    White_Line_MPos = 40;	//最大列的位置
    
    uint32 time_temp = 0;
    uint32 distance_temp = 0;
    int16 x, y, i, j, temp;
    int16 L = 0, R = 0;  //定义边线查找范围
    
    int16 left_inflection_point = 0;
    
    
    time_temp = ALL_TIME - Annular_Time;
    distance_temp = Distance_All - Annular_Distance;
    
    /***************先查截止行  即纵向遍历  若下端为白，上端为黑则此线为黑线截止行*************/
    uint16 White_Line[10] = {0}; //只以中间为准找中间40列中的10列
    uint16 White_Line_Pos[10] = {0};//记录白列的位置 即横坐标
    j = 0;
    for(x = 20; x < 100; x += 8, j++)
    {
        White_Line_Pos[j] = x;
        for(y = IMG_H - 1; y > 0; y--)
        {
            White_Line[j] = y; //记录纵坐标  y值越小说明  白列越长
            if(IMG[y][x] == Black)
            {
                break;
            }
        }
    }
    
    /********************  将白列进行排序   *************************************/
    //结果为  数组第一个为最长白列
    for(i = 0; i < 10; i++)
    {
        for(j = i + 1; j < 10; j++)
        {
            if(White_Line[i] > White_Line[j])
            {
                temp = White_Line[j];
                White_Line[j] = White_Line[i];
                White_Line[i] = temp;
                
                temp = White_Line_Pos[j];
                White_Line_Pos[j] = White_Line_Pos[i];
                White_Line_Pos[i] = temp;
            }
        }
    }
    
    White_Line_Max = White_Line[0]; //将最大列的值（即行数赋值）
    White_Line_MPos = White_Line_Pos[0]; //将最大列的位置赋值  即横坐标位置
    //限制最小遍历的行数 即 寻找边线至少找80行
    
    
    STOP_Line = White_Line_Max;
    
    y = IMG_H - 1;
    Left_Line[y] = IMG_W;
    for(x = White_Line_MPos - 1; x > 2; x--)//
    {
        if((Black == IMG[y][x]) && (White == IMG[y][x + 1]))
        {
            Left_Line[y] = x;
            break;
        }
    }
    if(Left_Line[y] == IMG_W)
    {
        Left_Line[y] = 0;
    }
    
    Right_Line[y] = 0;
    for(x = White_Line_MPos + 1; x < IMG_W - 1; x++)//
    {
        if((Black == IMG[y][x]) && (White == IMG[y][x - 1]))
        {
            Right_Line[y] = x;
            break;
        }
    }
    if(Right_Line[y] == 0)
    {
        Right_Line[y] = Left_Line[y] +  WIDTH(y);
    }
    Middle_Line[y] = (int16)((Right_Line[y] + Left_Line[y]) / 2.0 + 0.5);
    for(y = IMG_H - 2; y > STOP_Line; y--)
    {   
        Left_Line[y] = IMG_W;
        //查找左边线
        L = Left_Line[y + 1] - 10;
        R = Left_Line[y + 1] + 10;
        if(L < 1)	//防止数组越界
            L = 1;
        if(R < 1)	//防止数组越界
            R = 1;
        for(x = R; x >= L; x--)
        {
            if((IMG[y][x] == Black) && (IMG[y][x + 1] == White))
            {
                Left_Line[y] = x;
                break;
            }
        }
        
        if(Left_Line[y] == IMG_W) //左右都没有找到
        {
            Left_Line[y] = 0;  
        }  
        
    }
    for(y = IMG_H - 1; y > STOP_Line; y--)
    {   
        Right_Line[y] = 0; 
        
        //查找右边线
        L = Left_Line[y] + WIDTH_HALF(y);
        R = IMG_W - 1;
        if(L < 1)	//防止数组越界
            L = 1;
        if(L > 80)	//防止数组越界
            L = 80;
        for(x = L; x <= R; x++)
        {
            if((IMG[y][x] == Black) && (IMG[y][x - 1] == White))
            {
                Right_Line[y] = x;
                break;
            }
        }
        
        if(Right_Line[y] == 0) //左右都没有找到
        {
            Right_Line[y] = Left_Line[y] + WIDTH(y);//  
        }  
        
        if(Right_Line[y] - Left_Line[y] >  WIDTH(y))
        {
            Right_Line[y] = Left_Line[y] +  WIDTH(y);
        }
        Middle_Line[y] = (int16)((Left_Line[y] + Right_Line[y])/2.0);          
    }
    
    
    if(Annular_Out == 0)
    {
        if(distance_temp > 1800)
        {
            for(y = IMG_H - 4; y > STOP_Line + 3; y -= 3)
            {
                if((Left_Line[y] > Left_Line[y + 3]) && (Left_Line[y - 3] < Left_Line[y]))
                {
                    left_inflection_point = y;
                    break;
                }
            }
            
            if((left_inflection_point != 0) && (left_inflection_point > 60) && (left_inflection_point < 100))
            {
                Annular_Out = 1;
                Annular_Out_Distance = Distance_All;
            }
        }
    }
    else
    {
        distance_temp = Distance_All - Annular_Out_Distance;
        
        if(distance_temp > 2000)
        {
            Annular = 0;
            Annular_Out = 0;
        }
    }
    if(STOP_Line < 50)
        STOP_Line = 50;
}
/*!
-----------------------------------------------------
*  @brief      偏差计算----没有用到
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Variance_Calculate(void)
{
    int y = 0;
    int sum = 0;
    int number = 0;
    float average = 0;
    for(y = IMG_H - 2; y > STOP_Line + 1; y--)
    {
        sum += 80 - Middle_Line[y];
        number++;
    }
    
    average = sum / ((float)number);
    
    int v_sum = 0;
    int variance = 0;
    for(y = IMG_H - 2; y > STOP_Line + 1; y--)
    {
        v_sum += ((Middle_Line[y] - average) * (Middle_Line[y] - average));
    }
    variance = v_sum / number;
    
    
}
/*!
-----------------------------------------------------
*  @brief      贴边跑
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
void Side_Run(void)
{
    uint8 left_line[IMG_H] = {160};
    uint8 right_line[IMG_H] ={0};

    if(STOP_Line < 50)
    {
      STOP_Line = 50;
    }
    int x = 0, y = 0;
    for(y = IMG_H - 1; y > STOP_Line; y --)
    {
        left_line[y] = 160;
        right_line[y] = 0;
        for(x = White_Line_MPos; x > 3; x--)
        {
            
            if(IMG[y][x] == Black && (IMG[y][x + 1] == White) )
            {
                left_line[y] = x;
                break;
            }
        }
        for(x = White_Line_MPos; x < IMG_W - 4; x++)
        {
            
            if(IMG[y][x - 1] == White && (IMG[y][x] == Black) )
            {
                right_line[y] = x;
                break;
            }
        }
    }
    
    
    if(Side_Run_Mode == 2)
    {
        for(y = IMG_H - 1; y > STOP_Line; y--)
        {   
            Middle_Line[y] = (int16)(right_line[y] - WIDTH(y) * 0.25 + 0.5);  //
        }
    }
    else if(Side_Run_Mode == 1)
    {
        for(y = IMG_H - 1; y > STOP_Line; y--)
        {   
            Middle_Line[y] = (int16)(left_line[y] + WIDTH(y) * 0.29 + 0.5);  //
        }
    }
}
/*!
-----------------------------------------------------
*  @brief       中线偏差 计算
*  @param      
*  @since      v1.0
-----------------------------------------------------
*/
int16 g_iTurn_Set_Last = 0;

void Middle_Line_Find(void)
{
    int y;
    int sum = 0;  //总偏差值
    int sum_ratio = 0;       //偏差总系数
    int ratio = 8;    //偏差权值
    if(STOP_Line < 30)
    {
        STOP_Line = 30;
    if(Start_Line > 90)
        Start_Line = 90;
    else
        Start_Line = 105;
    }

    for(y = 110;y > STOP_Line + 1; y--)
    {
        sum += (80 - Middle_Line[y]) * ratio;
        sum_ratio += ratio;
        ratio++;
    }
    g_iTurn_Set_Last = g_iTurn_Set;
    g_iTurn_Set = (int16)(sum/sum_ratio);
    if(g_iTurn_Set > 35)
    {
        g_iTurn_Set = 35;
    }
    if(g_iTurn_Set < -35)
    {
        g_iTurn_Set = -35;
    }
    //g_iTurn_Set = (int16)(g_iTurn_Set/2.0 + 0.5);
}


