#include "common.h"
#include "include.h"

extern uint8  LMR[3][CAMERA_H];
extern uint8 imgbuff_process[CAMERA_W*CAMERA_H]; 
extern uint8 img[CAMERA_W*CAMERA_H]; 
     //�����жϸ�λ����
int16 leftspeed,rightspeed,leftsp;
//void PORTC_IRQHandler();
void PORTD_IRQHandler();
void DMA0_IRQHandler();
void PIT_IRQHandler();
void FTM2_IN_IRQHandler();
void FTM_IN_Init();
void UART0_RX_IRQHandler();

float Control_Para[15];

void init()
{  
//   OLED_Init();
//   button_init(); 
//   switch_init();
//   BEEP_ON;
//   DELAY_MS(200);
//   BEEP_OFF;
   //OLED_Draw_Logo();
//   led_init(); 
//   led_flash(); 
//   I2C_Init();
//   adc_init (ADC1_SE6a);// ��ص�ѹ�����ӿ� װ������Ϊ3.3/65535*3.128   (4.7k + 10k )/4.7k
   pit_init_ms(PIT0,2); //2ms��ʱ�ж�
   set_vector_handler(PIT0_VECTORn ,PIT_IRQHandler);
   Para_Init();  //ֱ�ӳ�ʼ������
   EnableInterrupts; //���ж�  
   //EEPROM_init();
    //�����PWM Ƶ��Ϊ10khz ռ�ձȾ���Ϊ10000 
   ftm_pwm_init(FTM1,FTM_CH1,300,sever_middle);   //��� PWM  PTA8�����Ƶ��Ϊ100hz ռ�ձȾ���Ϊ1000  
   
   ftm_pwm_init(FTM0,FTM_CH0,24000,0);   
   ftm_pwm_init(FTM0,FTM_CH1,24000,0); 
   ftm_quad_init(FTM2); 
   //FTM_QUAD_Init(FTM2); //���������ʼ��;  
//   FTM_IN_Init();  //��ʼ��FTM2Ϊ����
//   OLED_CLS(); 
//   camera_init();
//   set_vector_handler(PORTD_VECTORn ,PORTD_IRQHandler);    
//   set_vector_handler(DMA0_VECTORn ,DMA0_IRQHandler); 
//   set_vector_handler(FTM2_VECTORn ,FTM2_IN_IRQHandler); 
//   enable_irq(FTM2_IRQn);  //FTM2�ж�
//   enable_irq(PORTD_IRQn); 
//   OLED_CLS();
     uart_init (UART0, 115200);
//   set_vector_handler(UART0_RX_TX_VECTORn,UART0_RX_IRQHandler);
//   uart_rx_irq_en(UART0);
//   NVIC_SetPriority(UART0_RX_TX_IRQn,0);
//   NVIC_SetPriority(DMA0_VECTORn,1);
//   NVIC_SetPriority(PORTD_VECTORn ,2); 
   enable_irq (PIT0_IRQn); 
}

void Para_Init()
{
  SetSpeed=0.8;//
  Fuzzy_Kp=0.0040;//0.014
  Fuzzy_Kd=0.00;//0
  PID_SPEED.P=0.18;  //0.13
  PID_SPEED.I=0.02;//0.013
  PID_TURN.P=0.0020;  //0.005
  PID_TURN.D=0.00; //0.001
  Set_Angle=50;
  
  Control_Para[0]= SetSpeed;//Set_SPEED
  Control_Para[1]= Fuzzy_Kp;//FUZZY.P
  Control_Para[2]= Fuzzy_Kd;//FUZZY.D
  Control_Para[3]= PID_SPEED.P;//PID_SPEED.P
  Control_Para[4]= PID_SPEED.I;//PID_SPEED.I
  Control_Para[5]= PID_TURN.P;//PID_DIREC.P
  Control_Para[6]= PID_TURN.D;//PID_DIREC.D

}

//void FTM_IN_Init()
//{  SIM_SCGC3 |= SIM_SCGC3_FTM2_MASK;
//   SIM_SCGC5 |= SIM_SCGC5_PORTA_MASK;
//   PORTB_PCR18 = PORT_PCR_MUX(3) | PORT_PCR_DSE_MASK;   //PB18
//   FTM2_C0SC |= (FTM_CnSC_ELSA_MASK | FTM_CnSC_CHIE_MASK);  //�����ش���
//   FTM2_C0SC &= ~(FTM_CnSC_ELSB_MASK | FTM_CnSC_MSB_MASK | FTM_CnSC_MSA_MASK);
//   
////   PORTA_PCR11 = PORT_PCR_MUX(3) | PORT_PCR_DSE_MASK;   //PA11
////   FTM2_C1SC |= (FTM_CnSC_ELSA_MASK | FTM_CnSC_CHIE_MASK);  //�����ش���
////   FTM2_C1SC &= ~(FTM_CnSC_ELSB_MASK | FTM_CnSC_MSB_MASK | FTM_CnSC_MSA_MASK);
//   gpio_init(PTB19,GPI,0);  //����
//   
//   FTM2_SC = FTM_SC_CLKS(1);
//   FTM2_MODE |= FTM_MODE_WPDIS_MASK;
//   FTM2_COMBINE = 0;
//   FTM2_MODE &= ~FTM_MODE_FTMEN_MASK;
//   FTM2_CNTIN = 0;
//   FTM2_STATUS = 0x00; //���жϱ�־λ
//   //enable_irq(64);  //FTM2�ж�
//}


float Slope_Calculate(uint8 begin,uint8 end,float *p)    //��С���˷����б��
{
  float xsum=0,ysum=0,xysum=0,x2sum=0;
   uint8 i=0;
   float result=0;
   static float resultlast;
   p=p+begin;
   for(i=begin;i<end;i++)
   {
	   xsum+=i;
	   ysum+=*p;
	   xysum+=i*(*p);
	   x2sum+=i*i;
	   p=p+1;
   }
  if((end-begin)*x2sum-xsum*xsum) //�жϳ����Ƿ�Ϊ�� 
  {
    result=((end-begin)*xysum-xsum*ysum)/((end-begin)*x2sum-xsum*xsum);
    resultlast=result;
  }
  else
  {
   result=resultlast;
  }
  return result;
}

//void FTM2_IN_IRQHandler()
//{  unsigned char curstatus = FTM2_STATUS;
//   FTM2_STATUS = 0x00;  //���ж�
//   if(curstatus&(1<<0))  //CH0�ж�,�����
//   {  if(gpio_get(PTA11)==0) 
//      {leftspeed++;
//       leftsp++;
//      }
//      else   leftspeed--;
//   }
////   if(curstatus&(1<<1))  //CH1�жϣ��Ҳ���
////   { rightspeed++;
////   }
//}

//void  OLED_Draw_camera()
//{
//  int i;
//  uint8 x,y,temp,imgdrawbuff[4800]=255;
////    for(i=0;i<4800;i++)
////  {
////    imgdrawbuff[i]=img[i];         
////  }
//  
//  for(x=0;x<59;x++)
//  {
//             
//        if(LMR[0][x]!=0)
//       {
//         imgdrawbuff[x*80+LMR[0][x]+1]=0;
//         
//        }
//        if(LMR[1][x]!=0) 
//       {
//         imgdrawbuff[x*80+LMR[1][x]]=0;
//         
//        }
//          if(LMR[2][x]!=80)
//       {
//         imgdrawbuff[x*80+LMR[2][x]-2]=0;
//         
//        }
//
//  }
//  vcan_sendimg(imgdrawbuff, CAMERA_W * CAMERA_H);
//}