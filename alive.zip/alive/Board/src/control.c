#include "include.h"

//�ٶ������
float SpeedControlOutNew;
float SpeedControlOutOld;
float SpeedControlIntegral=0,Hill_Slow_Ratio;
uint8  Set_Angle;   //����ǰ��Ƕ�
int   SpeedCount;
int   Speed_Filter_Times=25;    //�ٶ�ƽ�����
float CarSpeed=0,ControlSpeed=0,AverageSpeed,SetSpeed=0,Distance=0;
//���������
float DirectionControlOutNew;
float DirectionControlOutOld;
float Turn_Speed=0;
int   DirectionCount;
float P_Slope,B_Slope,Middle_Err,Delt_error;
float Turn_Out;
float Turn_Angle_Integral;

/**������**/
int sever_middle=157;//150
int sever_range=24;  //28

//ģ����ϵ��
float  Delta_P;
float  Delta_D;
float  Fuzzy_Kp;
float  Fuzzy_Kd;
float  Fuzzy_Sp;
//PID���������
PID PID_SPEED,PID_TURN;

float  MotorOut;   //��������          
uint8   Starting,Stop;
uint8 Encoder_Disable=0;
uint8 Slow_Down=0;

extern int16 GYRO_OFFSET_Z;
extern int16 disspeed;
extern uint8 lost_line;

void Get_Speed()                     //5msִ��һ��
{  
  int qd1_result;
  //qd1_result =- FTM_QUAD_get(FTM2); 
  //FTM_QUAD_clean(FTM2);
  //disspeed = leftspeed; //+ rightspeed;
  qd1_result = leftspeed;// + rightspeed;
  leftspeed=0;
  //rightspeed=0;
  
  Distance+=qd1_result/2500.0;  //ת��Ϊ4ms���ܹ��ľ��� 500�ߣ�һȦ20cm
  //CarSpeed=CarSpeed*0.1+0.9*qd1_result*250.0/3100;    //�������ת��ΪM/S 4msһ��
  CarSpeed=CarSpeed*0.1+0.9*qd1_result*0.01; //*250/2500;    //�������ת��ΪM/S
  disspeed= CarSpeed;
  if(CarSpeed>4)CarSpeed=4;
}
//�ٶȿ���������
void Speed_Control(void)
{
  static float PreError[20]={0},I_flag,end_line;
  float  SpeedError,Speed_0,Speed_1,Speed_2;
  uint8 i;
  Speed_0=Control_Para[0];
  Speed_1=1.2;
  Speed_2=1.2;
//  SetSpeed=Fuzzy_Sp;
/******************************************************************************************/
//   if(RoadStyle==1)
//   {
//      SetSpeed=Speed_1;
//   }
//   if(RoadStyle==2)
//   {
//      SetSpeed=Speed_2;
//   }
//   if(RoadStyle==0)
//   {
//      SetSpeed=Speed_0;//Control_Para[0]
//   }
///******************************************************************************************/
//   if(RoadStyle==2&&SpCunt>43)//С��
//   {
//      SetSpeed=-1;
//   }
//   else
//   {
//      if(RoadStyle==1)
//      {
//         SetSpeed=Speed_1;
//      }
//      if(RoadStyle==2)
//      {
//         SetSpeed=Speed_2;
//      }
//      if(RoadStyle==0)
//      {
//         SetSpeed=Speed_0;//Control_Para[0]
//      }
//   }
///******************************************************************************************/ 
//   if((RoadStyle==1&&SpCunt>43))//����
//   {
//     SetSpeed=-1;
//     //BEEP_ON;
//   }
//   else
//   {
//      if(RoadStyle==1)
//      {
//         SetSpeed=Speed_1;
//      }
//      if(RoadStyle==2)
//      {
//         SetSpeed=Speed_2;
//      }
//      if(RoadStyle==0)
//      {
//         SetSpeed=Speed_0;//Control_Para[0]
//      }
//   }
//    if(Search_Endline>30)
//    {
//       SetSpeed=-1;
//       end_line=1;
//    }
//    if(end_line==1&&SpCunt<38)//40
//    {
//       if(RoadStyle==1)
//       {
//          SetSpeed=Speed_1;
//       }
//       if(RoadStyle==2)
//       {
//          SetSpeed=Speed_2;
//       }
//       if(RoadStyle==0)
//       {
//          SetSpeed=Speed_0;//Control_Para[0]
//       }
//       end_line=0;
//    }

   
///******************************************************************************************/
//    if(RoadStyle==1&&Slow_Down_Flag==1)
//    {
//       I_flag=1;
//       SetSpeed=-1;
//    }
//    if(I_flag==1&&SpCunt<40)//25
//    {
//       I_flag=0;
//       Slow_Down_Flag=0;
//       if(RoadStyle==1)
//        {
//           SetSpeed=Speed_1;
//        }
//        if(RoadStyle==2)
//        {
//           SetSpeed=Speed_2;
//        }
//        if(RoadStyle==0)
//        {
//           SetSpeed=Speed_0;//Control_Para[0]
//        }
//    }
/******************************************************************************************/
  SpeedError=SetSpeed-CarSpeed; 
  //������20��ƫ����ܺ���Ϊ������
  SpeedControlIntegral=0;
  for(i=0;i<19;i++)
  {
     PreError[i]=PreError[i+1]; 
     SpeedControlIntegral+=PreError[i];
  }
  PreError[19]=SpeedError;
  SpeedControlIntegral+=PreError[19];
  //�ٶȸ���
  SpeedControlOutOld=SpeedControlOutNew;

  SpeedControlOutNew=PID_SPEED.P*SpeedError+PID_SPEED.I*SpeedControlIntegral;   //PI����
}
//�ٶȿ���
void Speed_Control_Output(void) 
{ 
  float fValue; 
  fValue = SpeedControlOutNew - SpeedControlOutOld; 
  PID_SPEED.OUT = fValue * (SpeedCount+1)/Speed_Filter_Times+SpeedControlOutOld;  
}
/********************�������������***************/
void Direction_Control(void)
{
  //static int Calculate_Length=0;
//  Turn_Speed= -0.01*(Get_Z_Gyro() - GYRO_OFFSET_Z);//0.01
//  if(Turn_Speed<10&&Turn_Speed>-10)
//  {
//    Turn_Speed=0;
//  }
  
  
  
    Delta_P=Fuzzy(Middle_Err,Delt_error);
    Delta_D=Delta_P;
    Delta_P=Delta_P*Fuzzy_Kp;
    Delta_D=Delta_D*Fuzzy_Kd;
    
  PID_TURN.pout=(PID_TURN.P+Delta_P)*Middle_Err;//Middle_Err
  PID_TURN.dout=(PID_TURN.D+Delta_D)*Delt_error*0.1;
  Turn_Out= PID_TURN.pout - PID_TURN.dout;
  
  Turn_Out=Turn_Out_Filter(Turn_Out);         //ת������˲� 
  
  PID_TURN.OUT=Turn_Out*100;

  if( PID_TURN.OUT>sever_range) PID_TURN.OUT=sever_range;
   if( PID_TURN.OUT<-sever_range) PID_TURN.OUT=-sever_range;
  if(lost_line==0)
  {
      FTM_PWM_Duty(FTM1,FTM_CH0,sever_middle + PID_TURN.OUT);    //�����ֵ��0-180 �����仯
  }
  else 
  {
    if(lost_line==1)
    {
       FTM_PWM_Duty(FTM1,FTM_CH0,181);    //right
    }
    else if(lost_line==2)
    {
       FTM_PWM_Duty(FTM1,FTM_CH0,133);    //left
    }
  }
//   FTM_PWM_Duty(FTM1,FTM_CH0,sever_middle);
}

//���pwmֵ���
void Moto_Out() 
{
 //�ٶȿ�������޷�
 if(PID_SPEED.OUT>0.8)//�������ǰ�㣬��ģ���ٶȿ������Ϊ������֮Ϊ��
 PID_SPEED.OUT=0.8;
 if(PID_SPEED.OUT<-0.8)
 PID_SPEED.OUT=-0.8;
  MotorOut=PID_SPEED.OUT;
 
 //��ֵ�޷�����ֹ���ٹ���
 
  
  if(MotorOut>0.99)MotorOut=0.99;                     
  if(MotorOut<-0.99)MotorOut=-0.99; 
 

 if(Stop)                                //���ֹͣ���������
 {
    MotorOut=0;
    LED_BLUE_ON;
 }

      if(MotorOut>=0) //��ת
     {
        FTM_PWM_Duty(FTM0,FTM_CH0,MotorOut*10000);//ռ�ձȾ���Ϊ10000 
        FTM_PWM_Duty(FTM0,FTM_CH1,0);
     }
     else   //��ת
     {
        FTM_PWM_Duty(FTM0,FTM_CH0,0);
        FTM_PWM_Duty(FTM0,FTM_CH1,-MotorOut*10000);
     }
}
 

float  Turn_Out_Filter(float turn_out)    //ת���������˲�      
{
  float Turn_Out_Filtered; 
  static float Pre1_Error[4]; 
  Pre1_Error[3]=Pre1_Error[2];
  Pre1_Error[2]=Pre1_Error[1];
  Pre1_Error[1]=Pre1_Error[0];
  Pre1_Error[0]=turn_out;
  Turn_Out_Filtered=Pre1_Error[0]*0.3+Pre1_Error[1]*0.2+Pre1_Error[2]*0.2+Pre1_Error[3]*0.2;
  return Turn_Out_Filtered;
}
float  Middle_Err_Filter(float middle_err)    //����ƫ���˲�      
{
  float Middle_Err_Fltered; 
  static float Pre3_Error[4]; 
  Pre3_Error[3]=Pre3_Error[2];
  Pre3_Error[2]=Pre3_Error[1];
  Pre3_Error[1]=Pre3_Error[0];
  Pre3_Error[0]=middle_err;
  Middle_Err_Fltered=Pre3_Error[0]*0.4+Pre3_Error[1]*0.3+Pre3_Error[2]*0.2+Pre3_Error[3]*0.1;
  return Middle_Err_Fltered;
}