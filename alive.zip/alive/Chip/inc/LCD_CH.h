#ifndef _LCD_CH_H_
#define _LCD_CH_H_

#include "lcd.h"
#include "ff.h"

int GetGBKCode_from_sd(unsigned char *pBuffer, const unsigned char *c);














#endif  //ifndef _LCD_CH_H_