#include "control.h"
#include "pid.h"

#include "control.h"
#define INT_COUNT  0xFFFF


#define S3010_FTM   FTM1
#define S3010_CH    FTM_CH0
#define S3010_HZ    (100 )


#define S3010_Middle  1480  // �м� 88��

#define MOTOR1_IO   PTD15
#define MOTOR2_IO   PTA19
#define MOTOR_FTM   FTM0
#define MOTOR1_PWM  FTM_CH3
#define MOTOR2_PWM  FTM_CH4
#define MOTOR1_PWM_IO  FTM0_CH3
#define MOTOR2_PWM_IO  FTM0_CH4
#define MOTOR_HZ    5000
#define M_duty  0

int16 var08_06=0,var12_09=0,var01_05=0,var04_10=0,var05_12=0,var_z,var_zh,var_y,M;
int16 Pid_Pole_Value=0;
extern uint16 L;

uint16 sum;
uint8 DZ=0;

extern int8 T1,T2;
float  AS=0,BBS=0,DS=0,ES=0;
float  A=2000; 
float norm=2000;
extern uint16 n;
extern int8 W;
extern int16 dd;
extern int16 E;
extern int16 V;
extern uint16 Duty;
extern int16 H;
extern uint16 Set_V;
extern uint16 BS;
extern uint16 A_Set_V;
extern int16 CC;
extern int16 S;
extern int32 ee;
void Init()
{   
   
    adc_init(ADC0_SE8);      //01     
    adc_init(ADC0_SE9);      //02  
    adc_init(ADC0_SE12);     //03
    adc_init(ADC0_SE13);     //04  
    adc_init(ADC1_SE10);     //05
    adc_init(ADC1_SE11);     //06
    adc_init(ADC1_SE12);     //07
    adc_init(ADC1_SE13);     //08
    adc_init(ADC1_SE14);     //09                          
    adc_init(ADC1_SE15);     //10
    adc_init(ADC0_SE14);     //11
    adc_init(ADC0_SE15);     //12
    
    LCD_init(); 
    IncPIDInit();      //PID��ʼ��
    IncPIDInit_V();
   
   
    lptmr_pulse_init(LPT0_ALT1, INT_COUNT, LPT_Rising);   //���������ʼ��
    lptmr_pulse_clean(); 
  
     
   
    
    ftm_pwm_init(S3010_FTM, S3010_CH,S3010_HZ,S3010_Middle);      //��ʼ�� ��� PWM A12   
    ftm_pwm_init(MOTOR_FTM, MOTOR1_PWM,MOTOR_HZ,M_duty);      //��ʼ�� ��� PWM
    ftm_pwm_init(MOTOR_FTM, FTM_CH4,MOTOR_HZ,0);
    gpio_init(MOTOR1_IO,GPO,LOW);         
  
    
    
    int16 qqq=100;
    
    if(qqq>0)
    {
    
   var08_06 = adc_once   (ADC1_SE14, ADC_12bit);//8   //11
   var12_09 = adc_once   (ADC0_SE9, ADC_12bit);//12
   var01_05 = adc_once   (ADC0_SE12, ADC_12bit);//5
   var04_10 = adc_once   (ADC0_SE13, ADC_12bit);//10
   var05_12 = adc_once   (ADC0_SE14, ADC_12bit);//09
   qqq--;
    }
   
    
    float a15,a24,b15,b24;
    a15=var08_06+var05_12;
    b15=a15/2;
    a24=var12_09+var04_10;
    b24=a24/2;
      
   AS=b15/var08_06;
   ES=b15/var05_12;
   BBS=b24/var12_09;
   DS= b24/var04_10;
   
   
   
      
    pit_init_ms(PIT0, 25);                                //��ʼ��PIT0����ʱʱ��Ϊ�� 1000ms
    set_vector_handler(PIT0_VECTORn ,PIT0_IRQHandler);      //����PIT0���жϷ�����Ϊ PIT0_IRQHandler
    enable_irq (PIT0_IRQn);                                 //ʹ��PIT0�ж�
    
    pit_init_ms(PIT3, 10);                                //��ʼ��PIT3����ʱʱ��Ϊ�� 1000ms
    set_vector_handler(PIT3_VECTORn ,PIT3_IRQHandler);       //����PIT3���жϷ�����Ϊ PIT0_IRQHandler
    enable_irq (PIT3_IRQn);              
    
  
  
  
  
 
                    //ʹ��PIT3�ж�  
    
}


float Get_var()
{
  float B=0,C=0;
//// ��2���� 

   var08_06=0,var12_09=0,var01_05=0,var04_10=0,var05_12=0,var_z=0,var_y=0;
////  
   var08_06 = (int16)(adc_once   (ADC1_SE14, ADC_12bit)-130);//8   //11
   var12_09 = (int16)(adc_once   (ADC0_SE9, ADC_12bit)-70);//12
   var01_05 = (int16)(adc_once   (ADC0_SE12, ADC_12bit)-90);//5
   var04_10 = (int16)(adc_once   (ADC0_SE13, ADC_12bit)-150);//10
   var05_12 = (int16)(adc_once   (ADC0_SE14, ADC_12bit)-70);//09
   
   var_z = adc_once   (ADC1_SE11, ADC_12bit)-50; //03
   var_y = adc_once   (ADC1_SE12, ADC_12bit)-50; //06
   var_zh=adc_once   (ADC1_SE13, ADC_12bit)-50;  //07
   

  
   
  
  if(var08_06<0)
    var08_06=0;
  if(var12_09<0)
    var12_09=0;
  if(var01_05<0)
    var01_05=0;
  if(var04_10<0)
    var04_10=0;
   if(var05_12<0)
    var05_12=0;
  if(var_y<0)
    var_y=0;
  if(var_z<0)
    var_z=0;
   if(var_zh<0)
    var_zh=0;
  
  



   A=var08_06+var12_09+var01_05+var04_10+var05_12;
   
   B= var12_09*1000+var01_05*2000+var04_10*3000+var05_12*4000  ;
  
   C=B/A;
   
  
  
  
  
 if(E==0) //����״̬���ߴ���
 {  
   if(A<150)
   { 
             
      if(norm<2000)
       norm=0;
      else if(norm>2000) 
       norm=4000;     
   
   }
  
  else
  { norm = C;}
 }
 
 
 else if(E==1) //����Բ�����ߴ���
 {  
   if(A<50)
   { 
             
//      if(norm<2000)
//       norm=0;
//      else if(norm>2000) 
//       norm=4000;     
   
   }
  
  else
  { norm = C;}
 }
//  
   if (norm>3500)
   {
     float a,b,c;
     a=norm-3500;
     b=a/500;
     c=b*b+1;
     
     norm =a*c+3500;
   }
   
   
    if (norm<500)
   {
     float a,b,c;
     a=500-norm;
     b=a/500;
     c=b*b+1;
     
     norm=500-a*c;
   }
   
     
   if(norm>4000)
   {norm=4000;}
   if(norm<0)
   {norm=0;}
   
   
     
     
  
 
  // printf("\n  --- %d--- %d--- %d --- %d --- %d --- %d  --- %d --- %d --- %d  --- %d  ",(int16)dd,(int16)norm,var08_06,var12_09,var01_05,var04_10,var05_12,var_zh,var_z,var_y);
  // printf("\n %d",var_y);
   //printf("\n %d",var05_12);
   return norm; 
}





void PIT0_IRQHandler(void)

{
     int t=0;              
    
    M=lptmr_pulse_get();        //�����������������ֵ
    
    lptmr_pulse_clean();     //����������������ֵ��������գ��������ܱ�֤����ֵ׼ȷ��
   
    

    if(H==1)
    
    {
     
     t=M-Set_V;
     if(t>15)
     {
     ftm_pwm_duty(MOTOR_FTM, MOTOR1_PWM,0);
     ftm_pwm_duty(MOTOR_FTM, MOTOR2_PWM,25); 
     }
     
    
//     else if((M<20)&&(DZ==1))
//     {
//     ftm_pwm_duty(MOTOR_FTM, MOTOR1_PWM,0);
//     ftm_pwm_duty(MOTOR_FTM, MOTOR2_PWM,0); 
//     
//     }
     else if(Set_V==0)
     {
     ftm_pwm_duty(MOTOR_FTM, MOTOR1_PWM,0);
     ftm_pwm_duty(MOTOR_FTM, MOTOR2_PWM,0); 
     }
     else
     {
        if((T1==1&&T2==1)==0)
        {
       ftm_pwm_duty(MOTOR_FTM, MOTOR2_PWM,0); 
       V=Duty-(int)lineFellowPID_V(M);           //�����ֵ
       if(V<0) V=0;
       else if(V>70) V=70;        
       ftm_pwm_duty(MOTOR_FTM, MOTOR1_PWM,V);
        }
      }
    }
    
//    if(M>=Set_V)
//    {DZ=1;}

    PIT_Flag_Clear(PIT0);       //���жϱ�־λ      
    
   //printf("\n %d",M);
    
}


void PIT3_IRQHandler(void)
{  
  if(E==0)
  {
  
  L=(uint16)Get_var();

   Pid_Pole_Value = (int)lineFellowPID(L);    //10ms�ж϶��PID 
//   if(Pid_Pole_Value>0)
//   {Pid_Pole_Value=(int16)Pid_Pole_Value;}
   n=1480 - Pid_Pole_Value;   //�����ֵ
   if(n>2000)
     n=2000;
   if(n<1000)
     n=1000;
   ftm_pwm_duty(S3010_FTM, S3010_CH,n);
   //show();
   
   
  }
  
  
   if(S==1000)
  {
    
    while(1)
    {
    L=(uint16)Get_var();
    

    Pid_Pole_Value = (int)lineFellowPID(L);    //10ms�ж϶��PID 
    n=1480 - Pid_Pole_Value;   //�����ֵ
    if(n>2000)
     n=2000;
    if(n<1000)
     n=1000;
     ftm_pwm_duty(S3010_FTM, S3010_CH,n);
     show();
     ftm_pwm_duty(MOTOR_FTM, MOTOR1_PWM,0);
     ftm_pwm_duty(MOTOR_FTM, MOTOR2_PWM,0); 
    }
  }
  


 PIT_Flag_Clear(PIT3);       //���жϱ�־λ 



}


void show()

{

  Site_t site = {3,5};    
  LCD_str(site,"01",FCOLOUR,BCOLOUR);   //��һ·������
  site.y += 15;   
  LCD_str(site,"02",FCOLOUR,BCOLOUR);   //�ڶ�·������
  site.y += 15;   
  LCD_str(site,"03",FCOLOUR,BCOLOUR);   //��·������ʵ��ƫ�� 
  site.y += 15;          
  LCD_str(site,"04",FCOLOUR,BCOLOUR);   // pid������ƫ�� 
  site.y += 15;  
  LCD_str(site,"05",FCOLOUR,BCOLOUR);   //���ֵ
   site.y += 15;  
  LCD_str(site," z",FCOLOUR,BCOLOUR);   //���ֵ
   site.y += 15;  
  LCD_str(site," y",FCOLOUR,BCOLOUR);   //���ֵ
   site.y += 15;  
  LCD_str(site,"zh",FCOLOUR,BCOLOUR);   //���ֵ
 
  
  site.x = 30;    
  site.y = 5;  
  LCD_num_C (site, var08_06, FCOLOUR , BCOLOUR);
  site.y += 15;    
  LCD_num_C (site, var12_09, FCOLOUR , BCOLOUR);
  site.y += 15;    
  LCD_num_C (site, var01_05, FCOLOUR , BCOLOUR);
  site.y += 15;    
  LCD_num_C (site, var04_10, FCOLOUR , BCOLOUR);
  site.y += 15;    
  LCD_num_C (site, var05_12, FCOLOUR , BCOLOUR);
  site.y += 15;    
  LCD_num_C (site, var_z, FCOLOUR , BCOLOUR);
  site.y += 15;    
  LCD_num_C (site, var_y, FCOLOUR , BCOLOUR);
  site.y += 15;    
  LCD_num_C (site, var_zh, FCOLOUR , BCOLOUR);
  
  
  site.x = 80;    
  site.y = 5;   
  LCD_num_C (site, (int16)norm, FCOLOUR , BCOLOUR);
   site.y += 15;    
  LCD_num_C (site, ee, FCOLOUR , BCOLOUR);
   site.y += 15;    
  LCD_num_C (site, n, FCOLOUR , BCOLOUR);
  site.y += 15;    
  LCD_num_C (site,  abs(Pid_Pole_Value), FCOLOUR , BCOLOUR);
}





void tingche()  //ͣ��


{

if(T1==1&&T2==1)
     {
     
        disable_irq (PIT0_IRQn); 
        disable_irq (PIT3_IRQn); 
        Set_V=0;
       
        while(1)
        {  
          DELAY_MS(25);
           M=lptmr_pulse_get();        //�����������������ֵ
    
           lptmr_pulse_clean();     //����������������ֵ��������գ��������ܱ�֤����ֵ׼ȷ��
         if(M>100)
         { // H=0;
           ftm_pwm_duty(MOTOR_FTM, MOTOR1_PWM,0);
           ftm_pwm_duty(MOTOR_FTM, MOTOR2_PWM,80); 
         }
         else if(M>20)
         {   ftm_pwm_duty(MOTOR_FTM, MOTOR1_PWM,0);
           ftm_pwm_duty(MOTOR_FTM, MOTOR2_PWM,20); 
         }
         else{
           
          //  H=0;
           while(1)
             {ftm_pwm_duty(MOTOR_FTM, MOTOR1_PWM,0);
              ftm_pwm_duty(MOTOR_FTM, MOTOR2_PWM,0); 
               L=(uint16)Get_var();

                Pid_Pole_Value = (int)lineFellowPID(L);    //10ms�ж϶��PID 
                if(Pid_Pole_Value>0)
                {Pid_Pole_Value=(int16)1*Pid_Pole_Value;}
                 n=1480 - Pid_Pole_Value;   //�����ֵ
                if(n>2000)
                n=2000;
                if(n<1000)
                n=1000;
                ftm_pwm_duty(S3010_FTM, S3010_CH,n);
             }
         
            }
        
         
         
          L=(uint16)Get_var();

         Pid_Pole_Value = (int)lineFellowPID(L);    //10ms�ж϶��PID 
         if(Pid_Pole_Value>0)
         {Pid_Pole_Value=(int16)1*Pid_Pole_Value;}
          n=1480 - Pid_Pole_Value;   //�����ֵ
         if(n>2000)
          n=2000;
         if(n<1000)
         n=1000;
         ftm_pwm_duty(S3010_FTM, S3010_CH,n);
         
        }
        
        
        
        
      }

      

}
