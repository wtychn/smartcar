#ifndef __CONTROL_H
#define __CONTROL_H

#include "common.h"
#include "include.h"

void Init(void);
float Get_var(void);
void PIT0_IRQHandler(void);
void PIT3_IRQHandler(void);
void show(void);
 
void tingche(void);

#endif