#ifndef LDC1000_CMD_H_
#define LDC1000_CMD_H_
#define uchar uint8






// LDC COMMANDS
#define LDC1000_CMD_REVID               0x00
#define LDC1000_CMD_RPMAX 	        0x01
#define LDC1000_CMD_RPMIN 	        0x02
#define LDC1000_CMD_SENSORFREQ 	0x03               //г��Ƶ��
#define LDC1000_CMD_LDCCONFIG 	0x04
#define LDC1000_CMD_CLKCONFIG 	0x05
#define LDC1000_CMD_THRESHILSB 	0x06
#define LDC1000_CMD_THRESHIMSB 	0x07
#define LDC1000_CMD_THRESLOLSB 	0x08
#define LDC1000_CMD_THRESLOMSB 	0x09
#define LDC1000_CMD_INTCONFIG 	0x0A
#define LDC1000_CMD_PWRCONFIG 	0x0B
#define LDC1000_CMD_STATUS	0x20
#define LDC1000_CMD_PROXLSB 	0x21
#define LDC1000_CMD_PROXMSB 	0x22
#define LDC1000_CMD_FREQCTRLSB	0x23
#define LDC1000_CMD_FREQCTRMID	0x24
#define LDC1000_CMD_FREQCTRMSB	0x25

// LDC BITMASKS
#define LDC1000_BIT_AMPLITUDE    0x18
#define LDC1000_BIT_RESPTIME     0x07
#define LDC1000_BIT_CLKSEL       0x02
#define LDC1000_BIT_CLKPD        0x01
#define LDC1000_BIT_INTMODE      0x07
#define LDC1000_BIT_PWRMODE      0x01
#define LDC1000_BIT_STATUSOSC    0x80
#define LDC1000_BIT_STATUSDRDYB  0x40
#define LDC1000_BIT_STATUSWAKEUP 0x20
#define LDC1000_BIT_STATUSCOMP   0x10

#define MISO   gpio_get(PTD0)

#define MOSI_H  gpio_set(PTD1,1)
#define MOSI_L  gpio_set(PTD1,0)

#define CSN_H  gpio_set(PTD2,1)
#define CSN_L  gpio_set(PTD2,0)

#define SCK_H  gpio_set(PTD3,1)
#define SCK_L  gpio_set(PTD3,0)


#define MISO1   gpio_get(PTD8)

#define MOSI_H1  gpio_set(PTD9,1)
#define MOSI_L1 gpio_set(PTD9,0)

#define CSN_H1  gpio_set(PTD5,1)
#define CSN_L1  gpio_set(PTD5,0)

#define SCK_H1  gpio_set(PTD7,1)
#define SCK_L1  gpio_set(PTD7,0)                                      


//����FTMģ���
typedef enum
{
    LDC0,
    LDC1,
    LDC2,

} LDCn;

typedef enum
{
    LDC_SPI0,
    LDC_SPI1,
    LDC_SPI2,

} LDC_SPIn;

void LDC_init(LDCn ldcn);
int ldc_read_avr(LDC_SPIn ldc_spin);
long int filter(LDC_SPIn ldc_spin);
int ldc_read_avr1(LDC_SPIn ldc_spin);
long int filter1(LDC_SPIn ldc_spin);

void ysz_SPI_init(LDC_SPIn ldc_spin);
uchar ysz_SPI_RW(uchar rwdata);
uchar ysz_Singal_SPI_Read(uchar reg);
void ysz_Singal_SPI_Write(uchar reg,uchar wdata);
void ysz_SPI_Read_Buf(uchar reg, uchar *pBuf, uchar len);

uchar ysz_SPI_RW1(uchar rwdata);
uchar ysz_Singal_SPI_Read1(uchar reg);
void ysz_Singal_SPI_Write1(uchar reg,uchar wdata);
void ysz_SPI_Read_Buf1(uchar reg, uchar *pBuf, uchar len);

void ysz_delay_ms(uint16 ms);
void ysz_delay(unsigned int ms);
void ysz_delay_us(int ms);

#endif
