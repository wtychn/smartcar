#include "common.h"
#include "include.h"

////////////////////////////���ת��ռ�ձ�////////////////////////////////   
//zhongjian:145
//            //you:128
//            //zuo:162
#define RIGHT  128
#define LEFT   162
#define Setpoint 30
#define duojimax 17


#define S3010_FTM   FTM1
#define S3010_CH    FTM_CH0
#define S3010_HZ    (100)
#define S3010_Middle  145


#define MOTOR1_IO   PTD15
#define MOTOR2_IO   PTA19
#define MOTOR3_IO   PTA5
#define MOTOR4_IO   PTA24
#define MOTOR_FTM   FTM0
#define MOTOR1_PWM  FTM_CH3
#define MOTOR2_PWM  FTM_CH4
#define MOTOR3_PWM  FTM_CH5
#define MOTOR4_PWM  FTM_CH6
#define MOTOR1_PWM_IO  FTM0_CH3
#define MOTOR2_PWM_IO  FTM0_CH4
#define MOTOR3_PWM_IO  FTM0_CH5
#define MOTOR4_PWM_IO  FTM0_CH6
#define MOTOR_HZ    1000//(20*1000)
#define MOTOR_DUTY  80
#define M_FRQ  20
#define M_SPEED  15

int i;
int16 duoji_error,duojipid;

int16 error=0,error1=0,error2=0;
extern uint8 WhiteNum;


int32 duoji_PWM=0;
float P1=70,D1=320;

extern int LDC_val,LDC_val1,LDC_val_pre,LDC_val1_pre;
int LDC_val_try=0;
extern uint8 proximtyData[2],proximtyData1[2];
int Difference=0;
int adjustment[10]={0,0,0,0,0,0,0,0,0,0};
unsigned char flag=0,flag1=0;
int gyro_sum=0,gyro_set=0,gyro_get=0;

void lcd_dispnum(void);

/*!
*  @brief      main����
*  @since      v5.0
*  @note       FTM PWM ����
*/ 
void main(void)
{       
    DisableInterrupts;
    ftm_pwm_init(S3010_FTM, S3010_CH,S3010_HZ,145);      //��ʼ�� ��� PWM A12   
    ftm_pwm_init(MOTOR_FTM, MOTOR1_PWM,MOTOR_HZ,M_FRQ);      //��ʼ�� ��� PWM
    gpio_init(MOTOR1_IO,GPO,LOW);    
    LCD_init();    
    LDC_init(LDC0);
    LDC_init(LDC1);
    
    while(1)
    {
        
        LDC_val = ldc_read_avr(LDC_SPI0)/100;          
        LDC_val1 = ldc_read_avr1(LDC_SPI1)/100;  
        if(LDC_val1 > LDC_val + Setpoint)   //////////��LDC_val1����ƫ ������ƫ
        {
            duoji_error = LDC_val1 - LDC_val - Setpoint;
            duojipid = lineFellowPID(duoji_error); 
            if(duojipid > duojimax) duojipid = duojimax;            
            i = S3010_Middle - duojipid;
            ftm_pwm_duty(S3010_FTM, S3010_CH,i);            
        }
        if(LDC_val1 < LDC_val + Setpoint)   //////////��LDC_val����ƫ ������ƫ
        {
            duoji_error = LDC_val + Setpoint - LDC_val1;
            duojipid = lineFellowPID(duoji_error); 
            if(duojipid > duojimax) duojipid = duojimax;
            i = S3010_Middle + duojipid;
            ftm_pwm_duty(S3010_FTM, S3010_CH,i);            
        }        
        
        lcd_dispnum();       
        
        //        if(LDC_val - LDC_val1 > 10) // turn to left
        //        {
        //            ftm_pwm_duty(S3010_FTM, S3010_CH,LEFT);          
        //        }
        //        if(LDC_val - LDC_val1 < 10) // turn to right
        //        {
        //            ftm_pwm_duty(S3010_FTM, S3010_CH,RIGHT);         
        //        }   
        
        
        
        
    }
}

void lcd_dispnum(void)
{
    Site_t site = {3,5};    
    LCD_str(site,"val",FCOLOUR,BCOLOUR);   //��ʾ8*16�ַ���
    site.y += 20;   
    LCD_str(site,"val1",FCOLOUR,BCOLOUR);   //��ʾ8*16�ַ���
    site.y += 20;   
    LCD_str(site,"error",FCOLOUR,BCOLOUR);   //��ʾ8*16�ַ���      
    site.y += 20;   
    LCD_str(site,"duoji",FCOLOUR,BCOLOUR);   //��ʾ8*16�ַ���    
    
    site.x = 3 + 6*8;    
    site.y = 5;  
    LCD_num_C (site, LDC_val, FCOLOUR , BCOLOUR);
    site.y += 20;     
    LCD_num_C (site, LDC_val1, FCOLOUR , BCOLOUR);
    site.y += 20;     
    LCD_num_C (site, duoji_error, FCOLOUR , BCOLOUR);       
    site.y += 20;     
    LCD_num_C (site, i, FCOLOUR , BCOLOUR);    
    
}