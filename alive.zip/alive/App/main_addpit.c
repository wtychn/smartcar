#include "common.h"
#include "include.h"
#include "LDC1000.h"
#include "pid.h"
////////////////////////////���ת��ռ�ձ�////////////////////////////////   
//zhongjian:145
//            //you:128
//            //zuo:162
#define S3010_RIGHT  12800
#define S3010_LEFT   16200
#define duojimax 1700


#define S3010_FTM   FTM1
#define S3010_CH    FTM_CH0
#define S3010_HZ    (100)
#define S3010_Middle  14500


#define MOTOR1_IO   PTD15
#define MOTOR2_IO   PTA19
#define MOTOR3_IO   PTA5
#define MOTOR4_IO   PTA24
#define MOTOR_FTM   FTM0
#define MOTOR1_PWM  FTM_CH3
#define MOTOR2_PWM  FTM_CH4
#define MOTOR3_PWM  FTM_CH5
#define MOTOR4_PWM  FTM_CH6
#define MOTOR1_PWM_IO  FTM0_CH3
#define MOTOR2_PWM_IO  FTM0_CH4
#define MOTOR3_PWM_IO  FTM0_CH5
#define MOTOR4_PWM_IO  FTM0_CH6
#define MOTOR_HZ    5000
#define M_duty  30
#define Min_SPEED  15
#define zyuzhi  5
#define yyuzhi  5


int i,i1;
int A=0;
int aa,bb,cc;
int chushicha;
int a,b;
extern int LDC_val,LDC_val1,LDC_val_pre,LDC_val1_pre;
extern uint8 proximtyData[2],proximtyData1[2];
int Difference=0;
int adjustment[10]={0,0,0,0,0,0,0,0,0,0};



int16 duoji_error,duojipid;


void lcd_dispnum1(void);
void lcd_dispnum2(void);
void jiadiuxianshuru(void);
void PIT0_IRQHandler();



void main(void)
{   
  
  LCD_init();   
  ftm_pwm_init(S3010_FTM, S3010_CH,S3010_HZ,14500);      //��ʼ�� ��� PWM A12   
  ftm_pwm_init(MOTOR_FTM, MOTOR1_PWM,MOTOR_HZ,M_duty);      //��ʼ�� ��� PWM
  gpio_init(MOTOR1_IO,GPO,LOW);         
  LDC_init(LDC0);
  LDC_init(LDC1);  
  lcd_dispnum1();  
  pit_init_ms(PIT1,5);          //��ʱ50ms
  set_vector_handler(PIT0_VECTORn, PIT0_IRQHandler);
  enable_irq(PIT0_IRQn);
  
  i1=10;
  while(i1--)
  {
    LDC_val = ldc_read_avr(LDC_SPI0)/100;    
    a= LDC_val;
  }
  i1=10;
  while(i1--)
  {
    LDC_val1 = ldc_read_avr1(LDC_SPI1)/100;  
    b= LDC_val1;
  }
  LDC_val_pre=a;            //�����ڳ�ʼ��LDC_val_pre
  LDC_val1_pre=b;
  
  chushicha= LDC_val1 - LDC_val + 2;
  
  
  
  
  while(1)
  {   LDC_val = ldc_read_avr(LDC_SPI0)/100;     
  LDC_val1 = ldc_read_avr1(LDC_SPI1)/100;   
  
  if ( LDC_val1 > 145)
  {
    LDC_val =a;
    LDC_val1=145;
  }
  
  duoji_error = LDC_val1 - LDC_val ;   
          if( pit_flag > 0 )          //��PIT�ж���=1��              /*   1 ���ж���  */
        {
        
          if(count2 > count1)
          {            
            i = S3010_Middle - duojipid;
          }
  duojipid = lineFellowPID(duoji_error); 
  
  jiadiuxianshuru();
  
  if(duojipid > duojimax) duojipid = duojimax;    
  if(duojipid < -duojimax) duojipid = -duojimax;    
  i = S3010_Middle + duojipid;
  ftm_pwm_duty(S3010_FTM, S3010_CH,i);            
  
  //  LDC_val_pre=LDC_val;
  //  LDC_val1_pre=LDC_val1;
  
  lcd_dispnum2();
  // ysz_delay_ms(10);
  
  }
  
}






void lcd_dispnum1(void)
{
  Site_t site = {3,5};    
  LCD_str(site,"val",FCOLOUR,BCOLOUR);   //��һ·������
  site.y += 20;   
  LCD_str(site,"val1",FCOLOUR,BCOLOUR);   //�ڶ�·������
  site.y += 20;   
  LCD_str(site,"d21",FCOLOUR,BCOLOUR);   //��·������ʵ��ƫ�� 
  site.y += 20;          
  LCD_str(site,"PID",FCOLOUR,BCOLOUR);   // pid������ƫ�� 
  site.y += 20;  
  LCD_str(site,"duoji",FCOLOUR,BCOLOUR);   //���ֵ
  
}





void lcd_dispnum2(void)

{
  Site_t site = {3,5};    
  site.x = 5 + 6*8;    
  site.y = 5;  
  LCD_num_C (site, LDC_val, FCOLOUR , BCOLOUR);
  site.y += 20;     
  LCD_num_C (site, LDC_val1, FCOLOUR , BCOLOUR);
  site.y += 20;         
  LCD_num_C (site, duoji_error, FCOLOUR , BCOLOUR);       
  site.y += 20;     
  LCD_num_C (site, duojipid , FCOLOUR , BCOLOUR);       
  site.y += 20;  
  LCD_num_C (site, i , FCOLOUR , BCOLOUR);    
  
  
  
}

void jiadiuxianshuru(void)

{
  if(A==0)
  {
    bb=  LDC_val - LDC_val1 ;
    if(bb>=chushicha)
    {
      aa=bb-chushicha;
      if(aa>zyuzhi)
      {
        A=1;
        duoji_error = LDC_val1 - LDC_val ; 
        
      }
      else
      {
        A=0;
        duoji_error = LDC_val1 - LDC_val ; 
      }
      
    }
    if(bb<chushicha)
    {
      aa=chushicha-bb;
      if(aa<yyuzhi)
      {
        A=2;
        duoji_error = LDC_val1 - LDC_val ; 
      }
      else
      {
        A=0;
        duoji_error = LDC_val1 - LDC_val ; 
      }
    }
    
  }
  if(A==1)
  { 
    if(LDC_val1>b)
    {
      cc=LDC_val1-b;
    }
    else
    {
      cc=0;
    }
    if(cc>2)
    {
      duoji_error = LDC_val1 - LDC_val ; 
      A=0;
    }
    else
    {
      duoji_error=duoji_error;
    }
  }
  
  if(A==2)
  { 
    if(LDC_val>a)
    {
      cc=LDC_val-a;
    }
    else
    {
      cc=0;
    }
    if(cc>2)
    {
      duoji_error = LDC_val1 - LDC_val ; 
      A=0;
    }
    else
    {
      duoji_error=duoji_error;
    }
  }
  
  
}

