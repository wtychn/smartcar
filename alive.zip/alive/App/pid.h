#ifndef __PID_H
#define __PID_H

#include "common.h"
#include "include.h"

typedef struct PID 
{ 
	float  SetPoint;               //�趨Ŀ�� Desired Value 	 
	float  SumError;               //����ۼ�  	 
	float    Proportion;          //�������� Proportional Const 	 
	float    Integral;            //���ֳ��� Integral Const 	 
	float    Derivative;          //΢�ֳ��� Derivative Const 	  
	float  LastError;               //Error[-1]  
	float  PrevError;               //Error[-2] 
} PID; 

typedef struct PIDV 
{ 
	float  SetPointV;               //�趨Ŀ�� Desired Value 	 
	float  SumErrorV;               //����ۼ�  	 
	float    ProportionV;          //�������� Proportional Const 	 
	float    IntegralV;            //���ֳ��� Integral Const 	 
	float    DerivativeV;          //΢�ֳ��� Derivative Const 	  
	float  LastErrorV;               //Error[-1]  
	float  PrevErrorV;               //Error[-2] 
} PIDV; 

void    IncPIDInit(void) ;
//int16 IncPIDCalc(int16_t NextPoint) ;
float IncPIDCalc(float NextPoint) ;
float lineFellowPID(float value);//int16
//vu16    lineFellowPID(void);
//void    lineFellowPID2(void);
void    IncPIDInit_V(void) ;
float lineFellowPID_V(float value);
#endif
