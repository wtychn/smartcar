#include "pid.h"

#define PID_Mode 'Z'       //'W':��ʾλ��ʽPID�㷨����Z':��ʾ����ʽPID�㷨
#define PID_ModeV 'Z'   
////#define Setpoint 2

static PID  sPID; 
static PID  *sptr = &sPID; 
float last_proportional;
long integral;


static PIDV  sPIDV; 
static PIDV  *sptrV = &sPIDV; 
float last_proportionalV;
long integralV;



extern uint16 Set_D,Set_V;
extern float P,D,P_V,D_V;




/*************************************************************************
 ����: void IncPIDInit(void) 
 ����: PID ������ʼ�� 
 ����: ��
 ����: 
 ��ע: 
 �汾:
*************************************************************************/
void IncPIDInit(void) 
{ 
	  sptr->SumError   = 0;  
		sptr->LastError  = 0;  //Error[-1]
		sptr->PrevError  = 0;  //ror[-2] 
	#if PID_Mode == 'W' 
	/*********λ��ʽPID��������************/		  		 
		sptr->Proportion =0.23;  	  //0.01			 0.0099	//�������� Proportional Const 	
		sptr->Integral   = 0;  	  	//���ֳ��� Integral Const 
		sptr->Derivative =5;  			//΢�ֳ��� Derivative Const 
	#elif PID_Mode == 'Z' 
	/*********����ʽPID��������************/		  		 
		sptr->Proportion = 5;  	  //0			 0.0099	//�������� Proportional Const 	
		sptr->Integral   = 0;  	// 1.4--1.9  	//���ֳ��� Integral Const 
		sptr->Derivative = 0;  
		       
	#else
	    return;//ERROR...doing nothing;
	#endif
//	sptr->SetPoint = 2000;       
}

void IncPIDInit_V(void) 
{ 
	  sptrV->SumErrorV   = 0;  
		sptrV->LastErrorV  = 0;  //Error[-1]
		sptrV->PrevErrorV  = 0;  //ror[-2] 
	#if PID_ModeV == 'W' 
	/*********λ��ʽPID��������************/		  		 
		sptrV->ProportionV =0.23;  	  //0.01			 0.0099	//�������� Proportional Const 	
		sptrV->IntegralV   = 0;  	  	//���ֳ��� Integral Const 
		sptrV->DerivativeV =5;  			//΢�ֳ��� Derivative Const 
	#elif PID_ModeV == 'Z' 
	/*********����ʽPID��������************/		  		 
		sptrV->ProportionV = 5;  	  //0			 0.0099	//�������� Proportional Const 	
		sptrV->IntegralV   = 0;  	// 1.4--1.9  	//���ֳ��� Integral Const 
		sptrV->DerivativeV = 0;  
		       
	#else
	    return;//ERROR...doing nothing;
	#endif
//	sptr->SetPoint = 2000;       
}
/*************************************************************************
 ����: int IncPIDCalc(int NextPoint) 
 ����: PID
 ����: NextPoint 
 ����: iIncpid
 ��ע: 
 �汾:
*************************************************************************/
float IncPIDCalc(float NextPoint) 
{  
	#if PID_Mode == 'W' 
	  /********************λ��ʽPID��ʽ*****************************/  
		float iError,dError,iIncpid; 	//��ǰ��� 
		iError = NextPoint - 2000;   //��������  
		sptr->SumError+=iError;//������
		dError=iError-sptr->LastError;//΢����
		iIncpid = sptr->Proportion * iError + sptr->Integral * sptr->SumError + sptr->Derivative * dError;       
		sptr->LastError = iError; 	 //��������ֵ  
		return(iIncpid);
	
	#elif PID_Mode == 'Z' 
		/********************����ʽPID��ʽ*****************************/  
		float dError,Error,pError;
		float iIncpid; 
		//���������㹫ʽ��
		//Pdt=Kp*[E(t)-E(t-1)]+Ki*E(t)+Kd*[E(t)-2*E(t-1)+E(t-2)]
		Error = NextPoint - 189 ;        // ����������ƫ��E(t) 
		pError= Error - sptr->LastError;         //E(t)-E(t-1)
		dError= Error - 2 * sptr->LastError + sptr->PrevError; //E(t)-2*E(t-1)+E(t-2) 
		sptr->PrevError = sptr->LastError; 
		sptr->LastError = Error; 
		iIncpid = sptr->Proportion * pError + sptr->Integral * Error + sptr->Derivative * dError;
		return (iIncpid);
	#else
	  return;//ERROR...doing nothing
	#endif
}
///*************************************************************************
// ����: void lineFellowPID2(void) 
// ����: PID���߳���2
// ����: �� 
// ����: ��
// ��ע: ʹ�ó���ǰ��ҪPID������ʼ��
// �汾: 
//*************************************************************************/
//void lineFellowPID2(void)
//{
//	  uint16_t position;
//	  uint16_t sensors[5];
//		int16_t SpeedInc;
//		const int max =40;
//	  //PID������ʼ��
//	  IncPIDInit();
//		/**********С�������ߵ�λ�ü��㹫ʽ?****************
//		*
//		*   0*value0 + 1000*value1 + 2000*value2 + ...
//		*   --------------------------------------------
//		*         value0  +  value1  +  value2 + ...	
//		*
//		***************************************************/
//		position = readLine(sensors,false);
//	  //����ʽ����λ��ʽPID������������PID_Mode����ѡ��
//		SpeedInc = IncPIDCalc(position);
//		if(SpeedInc > max)
//		{
//			SpeedInc = max;
//		}
//		else if(SpeedInc < -max)
//		{
//			SpeedInc = -max;
//		}
//		if(SpeedInc < 0)
//		  Speed_Motor(max+SpeedInc , max );
//		else
//		  Speed_Motor(max , max-SpeedInc);
//}
/*************************************************************************
 ����: void lineFellowPID(void) 
 ����: PID���߳���
 ����: �� 
 ����: ��
 ��ע: ������Ҫע��������������ѭ������Ҫ����һ������ʱ��
 �汾: 
*************************************************************************/
float lineFellowPID(float value)//int18
{
    // Compute the actual motor settings.  We never set either motor
		/// to a negative value.
		//const int max = 5;//28//30
	  // Get the position of the line.
//    uint16_t sensors[5];
		//Compute the difference between the two motor power settings
		float power_difference ;  //int8
		
	// Get the position of the line.  Note that we *must* provide
		// the "sensors" argument to read_line() here, even though we
		// are not interested in the individual sensor readings.
		float position = value;//����������

		// The "proportional" term should be 0 when we are on the line.
		float proportional = ((int16)position) - 2000;

		// Compute the derivative (change) and integral (sum) of the
		// position.
		float derivative = proportional - last_proportional;
		integral += proportional;

		// Remember the last position.
		last_proportional = proportional;

		// Compute the difference between the two motor power settings, 
		// m1 - m2.  If this is a positive number the robot will turn
		// to the right.  If it is a negative number, the robot will
		// turn to the left, and the magnitude of the number determines
		// the sharpness of the turn.
		power_difference = proportional*P + integral*0+ derivative*D; 
                return power_difference;
		
//		if(power_difference > max)
//			power_difference = max;
//		if(power_difference < -max)
//			power_difference = -max;
//
//		if(power_difference < 0)
//			Speed_Motor(max+power_difference, max);
//		else
//			Speed_Motor(max, max-power_difference);
		
		//readCalibrated(sensors);//readLine(sensors,false);
	  //delay_us(1120);
//		if(sensors[1] < 100 && sensors[2] < 100 && sensors[3] < 100)
//			return 1;//dead line
//		else if(sensors[0] > 300 || sensors[4] > 300)   //500
//			return 2;//interation line
//		return 0;
}



float lineFellowPID_V(float valueV)//int18
{
    // Compute the actual motor settings.  We never set either motor
		/// to a negative value.
		//const int max = 5;//28//30
	  // Get the position of the line.
//    uint16_t sensors[5];
		//Compute the difference between the two motor power settings
		float power_differenceV ;  //int8
		
	// Get the position of the line.  Note that we *must* provide
		// the "sensors" argument to read_line() here, even though we
		// are not interested in the individual sensor readings.
		float positionV = valueV;//����������

		// The "proportional" term should be 0 when we are on the line.
		float proportionalV = ((int16)positionV) - Set_V;

		// Compute the derivative (change) and integral (sum) of the
		// position.
		float derivativeV = proportionalV - last_proportionalV;
		integralV += proportionalV;

		// Remember the last position.
		last_proportionalV = proportionalV;

		// Compute the difference between the two motor power settings, 
		// m1 - m2.  If this is a positive number the robot will turn
		// to the right.  If it is a negative number, the robot will
		// turn to the left, and the magnitude of the number determines
		// the sharpness of the turn.
		power_differenceV = proportionalV*P_V + integralV*0+ derivativeV*D_V; 
                return power_differenceV;
		
//		if(power_difference > max)
//			power_difference = max;
//		if(power_difference < -max)
//			power_difference = -max;
//
//		if(power_difference < 0)
//			Speed_Motor(max+power_difference, max);
//		else
//			Speed_Motor(max, max-power_difference);
		
		//readCalibrated(sensors);//readLine(sensors,false);
	  //delay_us(1120);
//		if(sensors[1] < 100 && sensors[2] < 100 && sensors[3] < 100)
//			return 1;//dead line
//		else if(sensors[0] > 300 || sensors[4] > 300)   //500
//			return 2;//interation line
//		return 0;
}

